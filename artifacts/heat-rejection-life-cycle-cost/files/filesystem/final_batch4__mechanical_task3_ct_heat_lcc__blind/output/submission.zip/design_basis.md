# Mechanical Design Basis — Condenser Water Heat Rejection Replacement
**Project:** Papago Federal Center, Phoenix, Arizona (95% Construction Documents)  
**Engineer of Record:** Sandoval Klee Mechanical Engineers, PC

---

## 1. Governing Criteria, Document Hierarchy & Scope Exclusions
In accordance with Design Criteria Memorandum `DC-02` (Revision 3), the design and life-cycle cost optimization of the three rooftop condenser water heat rejection plants—Courthouse Central Utility Plant (`CUP`), Data Annex (`ANNEX`), and Laboratory Wing (`LAB`)—are governed by:
- **Design & Economic Criteria:** `DC-02` (Rev 3) and `EC-01` (Rev 0).
- **Federal Standards & Regulations:** `UFC 3-410-01` (Change 1, 28 July 2025), `GSA PBS-P100` (2024), `UFM 3-230-13` (5 February 2026), `10 CFR Part 431` Subpart B (2024), `10 CFR Part 436` Subpart A (2024), and `NIST IR 85-3273-40` (2025 Annual Supplement to NIST Handbook 135, `NISTIR85-3273-40 - V2.xlsx`).
- **Project Specifications, Site Memoranda & Correspondences:** Section `23 65 00`, `WT-01`, `PW-LTR-014` as amended by `PW-LTR-019`, `UT-01`, `RFI-031`, and `RFI-034`.
- **Drawings, Schedules & Submittals:** `M-401 Revision C`, `S-401 Revision C`, `E-501`, `E-601 Revision C`, `M-601`, `M-603`, and reviewed vendor submittals `VD-01` through `VD-05` together with the EnergyPlus reference source and performance datasets.

### Explicit Project Scope Exclusions
The following items are explicitly excluded from the project scope:
- Chiller replacement or modification (chillers are already procured and condenser-side limits are fixed)
- Condenser water pump replacement or hydraulic circuit modification (pumps and circuits are fixed)
- Electrical distribution or motor control center (MCC) service upgrade (no service upgrade is in scope)
- Structural roof framing reinforcement across framing zone boundaries (supports crossing a zone boundary require reinforcement not in the scope of this project)
- Separate industrial sewer discharge permit (the Authority will not issue a permit above the daily blowdown limit)
- Closed hydronic loop water treatment under Section 23-25-00 (open condenser water systems are governed by WT-01 and UFM 3-230-13)

Non-adopted, cancelled, or superseded documents retained in the library (the cancelled 2018 weather-data manual, the superseded 2023 industrial water treatment edition, the superseded 2024 LCC annual supplement tables, the superseded February 2026 roof mechanical plan revision, the closed-loop water treatment excerpt, the non-governing Tucson weather station record, and the unamended `PW-LTR-014` ANNEX allocation) are set aside as authority.

---

## 2. Resolution of Documented Library Conflicts
Per `DC-02` Section 9.1 and Table 4, the three documented conflicts in the project library are resolved as follows:

CONFLICT 1: ADOPTED UFC 3-410-01 Paragraph 2-4.2.4 | SET ASIDE GSA PBS-P100 Section 5.3.1
CONFLICT 2: ADOPTED UFM 3-230-13 Paragraph 1-2 | SET ASIDE UFC_3-230-13 Paragraph 1-1
CONFLICT 3: ADOPTED M-401 Revision C | SET ASIDE M-401_Revision_B

1. **Outdoor Design Condition for Cooling Tower Selection (Conflict 1):** `DC-02` Table 0, Section 5.2, and `RFI-031` adopt `UFC 3-410-01` Paragraph 2-4.2.4 (1.0% annual outdoor wet-bulb temperature from the Phoenix Sky Harbor station record plus the 5.0 °F adder = `75.0 + 5.0 = 80.0 °F`) for cooling tower sizing, setting aside `GSA PBS-P100` Section 5.3.1 (0.4% dew point / evaporation wet-bulb) for tower selection. For the failure-case cooling robustness (redundancy) check with one cell out of service (`DC-02` Section 6.3 and `GSA PBS-P100` Section 5.1.3), the 0.4% annual wet-bulb (`76.0 °F`) plus the same 5.0 °F adder (`81.0 °F`, clamped to `26.6667 °C = 80.0 °F` at the YorkCalc correlation inlet boundary per `DC-02` Section 6.8) is applied.
2. **Industrial Water Treatment Criteria Edition (Conflict 2):** `UFM 3-230-13` (5 February 2026) Paragraph 1-2 explicitly reissues and supersedes the 2023 edition (`UFC_3-230-13` Paragraph 1-1). In addition, per `DC-02` Table 0, the open-system dissolved solids cap in `GSA PBS-P100` Section 5.3.5.3 is set aside for reclaimed makeup water in favor of the `UFM 3-230-13` and `WT-01` Practical (Puckorius) Scaling Index (`PSI >= 5.60`) and silica (`<= 150 ppm`) limits.
3. **Roof Mechanical Plan Revision (Conflict 3):** `M-401 Revision C` (21 August 2026, relocating outdoor air intakes to the east parapet) supersedes `M-401_Revision_B` (19 February 2026).

---

## 3. Calculation Methodology & Engineering Basis
- **Climatic Analysis & Scenario Bins (`DC-02` Section 5):** Hourly `FM-15` and `FM-16` observations from Phoenix Sky Harbor International Airport (`72278023183`, 2022–2024, `26,527` valid observations) yield a mean station pressure of `28.722 inHg` (`97,264.0 Pa`), a 1.0% annual wet-bulb of `75.0 °F` (`DesignWetBulb_F = 80.0 °F` per `UFC 3-410-01` Paragraph 2-4.2.4), a 0.4% annual wet-bulb of `76.0 °F` (`RedundancyWetBulb_F = 81.0 °F` per `GSA PBS-P100` Section 5.1.3), and a 99.6% annual dry-bulb exceedance temperature of `41.0 °F` (`DryBulb996_F = 41.0 °F`). Because `41.0 °F > 32.0 °F`, basin heaters and heat-traced makeup piping are not required (`BASINHEATER = NO`). Binning into 2 °F wet-bulb by 5 °F dry-bulb bins produces 180 scenario bins scaled to `8,760.0 hours/yr`.
- **Coupled Chiller & Tower Simulation (`DC-02` Section 6):** At each operating condition, `Chiller:Electric:EIR` (`CH-A`, `CH-B`, `CH-C`) and `CoolingTowerPerformance:YorkCalc` (`YorkCalc Default Tower Model`) are solved simultaneously with fixed-speed condenser water pumps and VFD tower fans modulating down to `0.30` speed ratio (`0.125` natural convection regime) with cell staging enforcing the minimum per-cell water flow limit (`max(Q_min, 0.75 * Q_nom)`).
- **Evaporation Formulation & Water Chemistry (`DC-02` Section 7 & `WT-01`):** The package declares and uses **`SATURATED-EXIT`** (`EvaporationMethod = saturated-exit`) consistently across the schedules, water balances, allocation checks, and life-cycle cost analyses. Using the 26 July 2022 (`2022-07-26`) complete water analysis from `USGS-332255112182101` (`Ca = 109 mg/L`, `TDS ROE10 = 1,720 mg/L`, `dissolved SiO2 = 16.0 mg/L`) and `120 ppm` circulating M-alkalinity (`WT-01`), maximum allowable cycles of concentration are solved from `PSI(CWR_design) = 5.60` using `UFM 3-230-13` Appendix A (`pHeq = 1.485*log10(120) + 4.54 = 7.6276` and linearly interpolated Factor B). Peak-day makeup and blowdown are evaluated over 24 hours of continuous operation at the design-day condition (`WB = 80.0 °F, DB = 112.0 °F`, design block load) per `PW-LTR-014` Section 2.
- **Life-Cycle Cost Analysis (`EC-01` & `10 CFR Part 436`):** Evaluated in constant 1 October 2025 (`2025-10-01`) USD over a 1-year construction period (`ConstructionPeriod_yr = 1`) followed by a 25-year service period (`StudyPeriod_yr = 26` years from the base date) at the 2025 DOE real discount rate of `3.0%` (`DiscountRate = 0.03`, implied inflation `1.5%`) from `NIST IR 85-3273-40`, giving delayed-service present value factors `UPVStarElectricity = 15.335223` (Mountain Commercial Electricity `16.306097 - 0.970874`), `UPVNonFuel = 16.905969` (`17.876842 - 0.970874`), and `UPVStarWater = 22.101023` (`23.091314 - 0.990291`).

---

## 4. Selected Plant Designs & Governing Constraints

GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.0247)
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.0018)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0124)

### CUP Plant Summary
- **Selection:** `4` x `CTX-0600-S` (`SS-304` casing/basin, `DE-2` drift eliminators, premium efficiency TEFC 6-pole fan motors)
- **Design Condenser Water Flow:** `1800.0 gpm` (`450.0 gpm/cell`, `WFR = 0.7500`)
- **Scheduled vs. Achieved Design Point Performance (at 80.0 °F WB):** Scheduled `CWSDESIGN = 86.00 °F` (`APPROACHDESIGN = 6.00 °F`, `RANGEDESIGN = 12.68 °F`); Achieved `CWS_F = 85.36 °F`, `CWR_F = 98.02 °F`, `Range_F = 12.66 °F`, `Approach_F = 5.36 °F`
- **Reset Schedule & Water Control:** `CWSMIN = 65.50 °F`, `CWSOFFSET = 11.50 °F`, `COC = 4.14` (`MaxAllowableCOC = 4.14`, `PSI = 5.60`)
- **Energy & Water Totals:** `AnnualPlantEnergy = 2,127,448.4 kWh`, `PeakCoincidentDemand = 514.95 kW`, `AnnualMakeup = 9,564.1 kgal`, `PeakDayMakeup = 49,032 gal/day`
- **Life-Cycle Cost:** `Investment = $786,200.00`, `LCC = $5,653,031.75` vs. `BasicDesignLCC = $5,899,570.84` (`NetSavings = $246,539.09`)
- **Relative Margins:** `water allocation` = `0.0714`, `electrical capacity` = `0.0247`, `roof area` = `0.3231`, `structural capacity` = `0.0250`, `condenser flow limit` = `0.2000`, `tower capability` = `0.1065`

### ANNEX Plant Summary
- **Selection:** `4` x `CTX-0600-S` (`SS-304` casing/basin, `DE-2` drift eliminators, premium efficiency TEFC 6-pole fan motors)
- **Design Condenser Water Flow:** `1800.0 gpm` (`450.0 gpm/cell`, `WFR = 0.7500`)
- **Scheduled vs. Achieved Design Point Performance (at 80.0 °F WB):** Scheduled `CWSDESIGN = 86.50 °F` (`APPROACHDESIGN = 6.50 °F`, `RANGEDESIGN = 13.70 °F`); Achieved `CWS_F = 85.69 °F`, `CWR_F = 99.38 °F`, `Range_F = 13.68 °F`, `Approach_F = 5.69 °F`
- **Reset Schedule & Water Control:** `CWSMIN = 79.50 °F`, `CWSOFFSET = 11.50 °F`, `COC = 4.00` (`MaxAllowableCOC = 4.00`, `PSI = 5.60`)
- **Energy & Water Totals:** `AnnualPlantEnergy = 3,597,114.7 kWh`, `PeakCoincidentDemand = 570.59 kW`, `AnnualMakeup = 12,577.4 kgal`, `PeakDayMakeup = 52,970 gal/day`
- **Life-Cycle Cost:** `Investment = $786,200.00`, `LCC = $7,649,558.87` vs. `BasicDesignLCC = $7,912,823.49` (`NetSavings = $263,264.62`)
- **Relative Margins:** `water allocation` = `0.0018`, `electrical capacity` = `0.0329`, `roof area` = `0.3231`, `structural capacity` = `0.0565`, `condenser flow limit` = `0.2000`, `tower capability` = `0.1240`

### LAB Plant Summary
- **Selection:** `3` x `CTX-0900-H` (`SS-304` casing/basin, `DE-2` drift eliminators, premium efficiency TEFC 6-pole fan motors)
- **Design Condenser Water Flow:** `2025.0 gpm` (`675.0 gpm/cell`, `WFR = 0.7500`)
- **Scheduled vs. Achieved Design Point Performance (at 80.0 °F WB):** Scheduled `CWSDESIGN = 87.00 °F` (`APPROACHDESIGN = 7.00 °F`, `RANGEDESIGN = 14.63 °F`); Achieved `CWS_F = 85.99 °F`, `CWR_F = 100.58 °F`, `Range_F = 14.60 °F`, `Approach_F = 5.99 °F`
- **Reset Schedule & Water Control:** `CWSMIN = 58.00 °F`, `CWSOFFSET = 8.50 °F`, `COC = 3.87` (`MaxAllowableCOC = 3.88`, `PSI = 5.60`)
- **Energy & Water Totals:** `AnnualPlantEnergy = 3,178,782.8 kWh`, `PeakCoincidentDemand = 633.21 kW`, `AnnualMakeup = 16,968.4 kgal`, `PeakDayMakeup = 74,265 gal/day`
- **Life-Cycle Cost:** `Investment = $926,220.00`, `LCC = $7,790,544.06` vs. `BasicDesignLCC = $8,079,654.50` (`NetSavings = $289,110.44`)
- **Relative Margins:** `water allocation` = `0.0248`, `electrical capacity` = `0.0124`, `roof area` = `0.2244`, `structural capacity` = `0.0162`, `condenser flow limit` = `0.2688`, `tower capability` = `0.1448`

