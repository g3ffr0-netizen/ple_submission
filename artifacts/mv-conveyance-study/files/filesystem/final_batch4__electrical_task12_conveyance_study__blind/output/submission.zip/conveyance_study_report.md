# 13.8 kV Site Distribution Conveyance Study Report
**Solicitation:** FA4610-26-R-0031 | **Project:** PCSFA 24-0117  
**Location:** Pacific Crest Space Force Annex, Los Angeles County, California  
**Facilities & Nodes:** SS-1, MB-1 (MSG-A, MSG-B, USS-A1), CUP-1 (SWG-C1), Gate House (TX-GH1), Lift Station (TX-LS2), Warehouse W-3 (TX-W3)  
**Study Date:** 2026-09-15 | **Bid Opening:** 2026-10-08 | **Midpoint of Construction:** 2027-08-18  

---

## 1. Executive Summary & Scope Exclusions

This pre-35% design Conveyance Study evaluates and prices all required medium-voltage (13.8 kV) conveyance alternatives for circuits **C01 through C07** in accordance with RFP Section `01 11 00` (Amendment 0002), `PCSFA-IEDS` Rev 3, and applicable UFGS sections (`01 11 00`, `03 30 00`, `26 20 00`, `31 00 00`, `33 71 01`, `33 71 02`).

### Explicit Scope Exclusions
- **External NFPA 70, IEEE C2, and NECA texts not provided in workspace**: All code, clearance, ampacity, and labor-estimating requirements are governed strictly by the project documents provided in the workspace.
- **Superseded documents per Transmittal_T-0117-09.pdf (RFP Amd0001, PCSFA-IEDS Rev2, Protective_Device_Settings_Schedule RevC, superseded wage determination if applicable)**: Superseded revisions are excluded from governing design and pricing criteria per Transmittal T-0117-09 and PCSFA-IEDS Rev 3 Section 1.3.

### Summary of Recommended Conveyances (`Items`)

| Item | Circuit | Recommended Type | Cable Size (AWG/kcmil) | Sets | OH Conductor (ACSR) | Design Current (A) | Ampacity / Set (A) | Route Length (ft) | Total Project Cost ($) | Cost / LF ($/LF) |
|---|---|---|---:|---:|---|---:|---:|---:|---:|---:|
| C01 | C01 | CEDB | 500 | 2 |  | 640.0 | 331.55 | 900.00 | $318,172.70 | $353.53 |
| C02 | C02 | CEDB | 500 | 2 |  | 560.0 | 331.55 | 1210.00 | $439,145.32 | $362.93 |
| C03 | C03 | CEDB | 350 | 1 |  | 400.0 | 410.12 | 505.36 | $111,668.01 | $220.97 |
| C04 | C04 | CEDB | 250 | 1 |  | 60.0 | 330.48 | 1315.00 | $288,817.13 | $219.63 |
| C05 | C05 | RMC | 250 | 2 |  | 200.0 | 160.00 | 390.00 | $205,461.91 | $526.83 |
| C06 | C06 | OH | 250 | 1 | 1/0 | 40.0 | 196.00 | 1958.28 | $124,272.07 | $63.46 |
| C07 | C07 | CEDB | 250 | 1 |  | 120.0 | 330.48 | 680.00 | $149,124.97 | $219.30 |

---

## 2. Labor Rates, Equipment Rates, and Estimate Roll-Up Markups

### 2.1 Loaded Labor Rates (`CA20260022 Mod 5`, published `2026-08-06`, & 2026 Payroll Burden)

| Class | WD Group | Classification | Base ($/hr) | Fringe ($/hr) | Burden (%) | Loaded Rate ($/hr) |
|---|---|---|---:|---:|---:|---:|
| LINEMAN | ELEC1245-001 | LINE CONSTRUCTION: (1) LINEMAN; CABLE SPLICER | $70.16 | $24.71 | 20.39% | $109.18 |
| EQSPEC | ELEC1245-001 | LINE CONSTRUCTION: (2) EQUIPMENT SPECIALIST | $53.30 | $22.26 | 20.39% | $86.43 |
| GROUNDMAN | ELEC1245-001 | LINE CONSTRUCTION: (3) GROUNDMAN | $40.76 | $21.76 | 20.39% | $70.83 |
| ELECTRICIAN | ELEC0011-004 | ELECTRICIAN: INSIDE ELECTRICAL WORK: JOURNEYMAN ELECTRICIAN | $60.80 | $31.59 | 15.77% | $101.98 |
| SPLICER_IN | ELEC0011-004 | ELECTRICIAN: INSIDE ELECTRICAL WORK: CABLE SPLICER (5% ADDITIONAL) | $63.84 | $31.59 | 15.77% | $105.50 |
| LAB1 | LABO0300-003 | LABORER GROUP 1 | $46.48 | $25.95 | 19.00% | $81.26 |
| LAB3 | LABO0300-003 | LABORER GROUP 3 | $47.58 | $25.95 | 19.00% | $82.57 |
| LAB4 | LABO0300-003 | LABORER GROUP 4 (PREFABRICATED MANHOLE INSTALLER) | $49.13 | $25.95 | 19.00% | $84.41 |
| PUMPOP | ENGI0012-024 | OPERATOR: POWER EQUIPMENT, ALL OTHER WORK: GROUP 1 (PUMP OPERATOR) | $63.40 | $33.20 | 19.00% | $108.65 |

### 2.2 Construction Equipment Rates (`EP 1110-1-8 Vol 7 Region VII` Fuel-Adjusted & `RQ-26-0419`)

| Equipment ID | Description | Source | Hourly Rate ($/hr) |
|---|---|---|---:|
| H25CA040 | HYDRAULIC EXCAVATOR, CRAWLER, 40,600 LBS, 1.00 CY BUCKET, 22.50' MAX DIGGING DEPTH | EP 1110-1-8 Vol 7 Region VII (fuel-adjusted per FSI-0826-2207) | $58.68 |
| T30DW022 | TRENCHER, CHAIN TYPE CUTTER, 48" MAX DEPTH X 3.5"-6" WIDTH, WALK BEHIND, CRAWLER | EP 1110-1-8 Vol 7 Region VII (fuel-adjusted per FSI-0826-2207) | $14.61 |
| L50CA001 | LOADER / BACKHOE, WHEEL, 1.00 CY FRONT END BUCKET, 24" DIP, 14.5' DIGGING DEPTH, 4X2 | EP 1110-1-8 Vol 7 Region VII (fuel-adjusted per FSI-0826-2207) | $30.98 |
| C10BO003 | COMPACTOR, VIBROPLATE, 14.2" X 22" PLATE, 2,250 LBS IMPACT | EP 1110-1-8 Vol 7 Region VII (fuel-adjusted per FSI-0826-2207) | $2.90 |
| C80TE008 | CRANES, HYDRAULIC, TRUCK MTD, ROUGH TERRAIN, 25 TON, 72' BOOM, 4X4 | EP 1110-1-8 Vol 7 Region VII (fuel-adjusted per FSI-0826-2207) | $61.06 |
| P50WC002 | PUMP, WATER, CENTRIFUGAL, TRASH, ENGINE DRIVE, 3" DIA, 425 GPM @ 95' HEAD | EP 1110-1-8 Vol 7 Region VII (fuel-adjusted per FSI-0826-2207) | $3.85 |
| RQ-BDT | Bucket / digger-derrick line truck, 47 ft, 4x4 | Rental Quote RQ-26-0419 | $96.00 |
| RQ-PUL | Cable puller, hydraulic capstan/bullwheel, 10,000 lb with dynamometer | Rental Quote RQ-26-0419 | $58.50 |
| RQ-TBX | Trench shield (trench box), steel, 8 ft high x 16 ft long, with spreaders | Rental Quote RQ-26-0419 | $7.25 |
| RQ-LFT | Scissor lift, 26 ft, electric (indoor) | Rental Quote RQ-26-0419 | $11.80 |

### 2.3 Estimate Roll-Up Markups (`UFC 3-740-05` & `UFS 3-701-01`)

| Parameter | Value | Basis |
|---|---:|---|
| `jooh_pct` | 9.50% | RFP 3.6 job office overhead (9.5%) |
| `hooh_pct` | 4.50% | RFP 3.6 G&A / home office overhead (4.5%) |
| `profit_pct` | 7.9377% | UFC 3-740-05 11-2.2 weighted guidelines (Risk 0.08, Diff 0.09, Size $4.2M, POP 15 mo, Inv 0.06, Asst 0.07, Sub 30%) |
| `bond_rate_pct` | 1.2463% | Sierra Surety Class B 5-tier graduated schedule + 3% surcharge (15 months) on recommended package |
| `escalation_factor` | 1.019388 | UFS 3-701-01 Table 4-2 interpolated from 2026-09-15 study date to 2027-08-18 midpoint |
| `contingency_pct` | 5.00% | RFP 3.6 design contingency at 35% design (5.0%) |
| `sioh_pct` | 5.70% | UFC 3-740-05 13-3.2 SIOH rate (5.7%) |
| `area_cost_factor_applied` | 1 | UFS 3-701-01 & RFP 3.1 (bottom-up estimate priced with local wages, local quotes, and Region VII equipment) |
| `wage_determination` | CA20260022 Mod 5 (2026-08-06) | Effective under 29 CFR 1.6(c)(2)(ii)(A) (>10 days prior to 2026-10-08 bid opening) |

---

## 3. Per-Item Evaluation, Recommendations, and Cost Tables

### Item C01 (Recommended: `CEDB`, Length: `900.00 ft`, Design Current: `640 A`, Cable: `2 set(s) of 500 kcmil`)

| Type | Admissible | Governing Clause | Length (ft) | Labor (MH) | Labor ($) | Equipment ($) | Material ($) | Subcontract ($) | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Rec |
|---|:---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| CEDB | Y | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (concrete-encased ductbank required for primary underground distribution; directional bores <= 25% of run per Sec 4.3) | 900.00 | 722.82 | $61,573.18 | $11,222.96 | $138,097.09 | $14,000.00 | $224,893.23 | $318,172.70 | $353.53 | Y |
| UEDB | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (conduit without concrete encasement not permitted for installation primary distribution) | 900.00 | 617.27 | $52,986.45 | $11,575.45 | $144,228.72 | $14,000.00 | $222,790.62 | $315,198.00 | $350.22 | N |
| DBC | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFGS 33 71 02 Sec 3.7.9 (direct-buried cable not permitted for installation primary distribution) | 900.00 | 341.83 | $29,474.99 | $6,926.40 | $73,178.39 | $14,000.00 | $123,579.78 | $174,837.25 | $194.26 | N |
| HDD | N | PCSFA-IEDS Rev 3 Sec 4.3 & UFC 3-550-01 Sec 3-11.4.1 (directional boring restricted to road/channel crossings and may not extend >50 ft beyond crossing edges) | 900.00 | 479.02 | $41,413.28 | $10,862.29 | $81,812.46 | $106,020.00 | $240,108.03 | $339,698.17 | $377.44 | N |
| OH | N | PCSFA-IEDS Rev 3 Sec 4.1 & UFC 3-550-01 Sec 3-11.1.1 (prohibited in congested industrial area AREA-CONGESTED) | 900.00 | 333.80 | $29,337.82 | $6,971.27 | $61,485.19 | $0.00 | $97,794.28 | $138,356.64 | $153.73 | N |

### Item C02 (Recommended: `CEDB`, Length: `1210.00 ft`, Design Current: `560 A`, Cable: `2 set(s) of 500 kcmil`)

| Type | Admissible | Governing Clause | Length (ft) | Labor (MH) | Labor ($) | Equipment ($) | Material ($) | Subcontract ($) | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Rec |
|---|:---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| CEDB | Y | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (concrete-encased ductbank required for primary underground distribution; directional bores <= 25% of run per Sec 4.3) | 1210.00 | 984.23 | $83,767.53 | $15,317.65 | $197,314.83 | $14,000.00 | $310,400.01 | $439,145.32 | $362.93 | Y |
| UEDB | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (conduit without concrete encasement not permitted for installation primary distribution) | 1210.00 | 840.20 | $72,050.52 | $15,798.69 | $205,684.60 | $14,000.00 | $307,533.81 | $435,090.30 | $359.58 | N |
| DBC | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFGS 33 71 02 Sec 3.7.9 (direct-buried cable not permitted for installation primary distribution) | 1210.00 | 438.88 | $37,791.67 | $9,106.83 | $96,453.28 | $14,000.00 | $157,351.78 | $222,616.94 | $183.98 | N |
| HDD | N | PCSFA-IEDS Rev 3 Sec 4.3 & UFC 3-550-01 Sec 3-11.4.1 (directional boring restricted to road/channel crossings and may not extend >50 ft beyond crossing edges) | 1210.00 | 651.71 | $56,271.79 | $14,825.45 | $120,676.06 | $144,218.00 | $335,991.30 | $475,351.16 | $392.85 | N |
| OH | N | PCSFA-IEDS Rev 3 Sec 4.1 & UFC 3-550-01 Sec 3-11.1.1 (prohibited in congested industrial area AREA-CONGESTED) | 1210.00 | 369.24 | $32,443.09 | $7,852.74 | $68,116.89 | $0.00 | $108,412.72 | $153,379.31 | $126.76 | N |

### Item C03 (Recommended: `CEDB`, Length: `505.36 ft`, Design Current: `400 A`, Cable: `1 set(s) of 350 kcmil`)

| Type | Admissible | Governing Clause | Length (ft) | Labor (MH) | Labor ($) | Equipment ($) | Material ($) | Subcontract ($) | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Rec |
|---|:---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| CEDB | Y | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (concrete-encased ductbank required for primary underground distribution; directional bores <= 25% of run per Sec 4.3) | 505.36 | 259.74 | $22,105.68 | $3,668.80 | $53,155.55 | $0.00 | $78,930.03 | $111,668.01 | $220.97 | Y |
| UEDB | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (conduit without concrete encasement not permitted for installation primary distribution) | 505.36 | 221.56 | $19,007.50 | $3,798.46 | $52,743.48 | $0.00 | $75,549.44 | $106,885.26 | $211.50 | N |
| DBC | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFGS 33 71 02 Sec 3.7.9 (direct-buried cable not permitted for installation primary distribution) | 505.36 | 108.40 | $9,370.57 | $1,974.04 | $21,039.72 | $0.00 | $32,384.33 | $45,816.46 | $90.66 | N |
| HDD | N | PCSFA-IEDS Rev 3 Sec 4.3 & UFC 3-550-01 Sec 3-11.4.1 (directional boring restricted to road/channel crossings and may not extend >50 ft beyond crossing edges) | 505.36 | 170.90 | $14,765.84 | $3,496.74 | $34,667.26 | $47,994.50 | $100,924.34 | $142,784.95 | $282.54 | N |
| OH | N | PCSFA-IEDS Rev 3 Sec 4.1 & UFC 3-550-01 Sec 3-11.1.1 (prohibited in congested industrial area AREA-CONGESTED) | 505.36 | 183.87 | $16,205.79 | $4,007.62 | $31,289.60 | $0.00 | $51,503.01 | $72,865.02 | $144.18 | N |

### Item C04 (Recommended: `CEDB`, Length: `1315.00 ft`, Design Current: `60 A`, Cable: `1 set(s) of 250 kcmil`)

| Type | Admissible | Governing Clause | Length (ft) | Labor (MH) | Labor ($) | Equipment ($) | Material ($) | Subcontract ($) | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Rec |
|---|:---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| CEDB | Y | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (concrete-encased ductbank required for primary underground distribution; directional bores <= 25% of run per Sec 4.3) | 1315.00 | 614.87 | $52,194.94 | $9,191.29 | $114,757.67 | $28,000.00 | $204,143.90 | $288,817.13 | $219.63 | Y |
| UEDB | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (conduit without concrete encasement not permitted for installation primary distribution) | 1315.00 | 523.82 | $44,797.45 | $9,455.69 | $113,577.85 | $28,000.00 | $195,830.99 | $277,056.25 | $210.69 | N |
| DBC | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFGS 33 71 02 Sec 3.7.9 (direct-buried cable not permitted for installation primary distribution) | 1315.00 | 264.41 | $22,717.20 | $5,299.53 | $45,606.85 | $28,000.00 | $101,623.58 | $143,774.22 | $109.33 | N |
| HDD | N | PCSFA-IEDS Rev 3 Sec 4.3 & UFC 3-550-01 Sec 3-11.4.1 (directional boring restricted to road/channel crossings and may not extend >50 ft beyond crossing edges) | 1315.00 | 380.01 | $32,753.18 | $8,471.84 | $68,615.15 | $112,984.00 | $222,824.17 | $315,245.46 | $239.73 | N |
| OH | Y | PCSFA-IEDS Rev 3 Sec 4.1 & UFC 3-550-01 Sec 3-10.1 (permitted east of x=1560 ft outside AREA-CONGESTED with UG exit) | 1315.00 | 560.27 | $47,995.45 | $9,542.48 | $86,828.11 | $0.00 | $144,366.04 | $204,245.06 | $155.32 | N |

### Item C05 (Recommended: `RMC`, Length: `390.00 ft`, Design Current: `200 A`, Cable: `2 set(s) of 250 kcmil`)

| Type | Admissible | Governing Clause | Length (ft) | Labor (MH) | Labor ($) | Equipment ($) | Material ($) | Subcontract ($) | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Rec |
|---|:---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| RMC | Y | PCSFA-IEDS Rev 3 Sec 5.1 & UFC 3-520-01 Table 3-1 (RGS conduit permitted for interior 13.8 kV feeder and fits 14 in ceiling space in A-501) | 390.00 | 523.37 | $53,439.91 | $2,861.32 | $88,924.91 | $0.00 | $145,226.14 | $205,461.91 | $526.83 | Y |
| EMT | N | UFGS 26 20 00 Sec 3.1.6.2.c & PCSFA-IEDS Rev 3 Sec 5.1 (EMT prohibited in equipment rooms ER-A, MR-2, MR-1 subject to severe physical damage) | 390.00 | 415.10 | $42,398.54 | $2,222.52 | $46,005.20 | $0.00 | $90,626.26 | $128,215.51 | $328.76 | N |
| TRAY-EN | N | PCSFA-IEDS Rev 3 Sec 5.1 & A-501 Rev 1 (6 in enclosed tray plus 12 in required access headroom = 18 in exceeds 14 in available space in COR-1D/COR-2 and 16 in in MR-2) | 390.00 | 421.63 | $43,064.25 | $2,261.03 | $54,437.21 | $0.00 | $99,762.49 | $141,141.21 | $361.90 | N |
| TRAY-LD | N | UFC 3-520-01 Table 3-1 Art 328 & PCSFA-IEDS Rev 3 Sec 5.1 (interior MV cable restricted to raceway or enclosed gasketed tray; open ladder tray prohibited and exceeds A-501 headroom) | 390.00 | 398.23 | $40,677.96 | $2,122.97 | $44,796.56 | $0.00 | $87,597.49 | $123,930.50 | $317.77 | N |

### Item C06 (Recommended: `OH`, Length: `1958.28 ft`, Design Current: `40 A`, Cable: `1 set(s) of 250 kcmil` + `1/0 ACSR`)

| Type | Admissible | Governing Clause | Length (ft) | Labor (MH) | Labor ($) | Equipment ($) | Material ($) | Subcontract ($) | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Rec |
|---|:---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| CEDB | Y | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (concrete-encased ductbank required for primary underground distribution; directional bores <= 25% of run per Sec 4.3) | 1958.28 | 872.86 | $74,057.48 | $13,145.84 | $168,859.40 | $28,000.00 | $284,062.72 | $401,884.06 | $205.22 | N |
| UEDB | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (conduit without concrete encasement not permitted for installation primary distribution) | 1958.28 | 736.29 | $62,974.26 | $13,609.82 | $167,388.66 | $28,000.00 | $271,972.74 | $384,779.48 | $196.49 | N |
| DBC | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFGS 33 71 02 Sec 3.7.9 (direct-buried cable not permitted for installation primary distribution) | 1958.28 | 351.71 | $30,221.63 | $7,374.16 | $64,953.32 | $28,000.00 | $130,549.11 | $184,697.27 | $94.32 | N |
| HDD | N | PCSFA-IEDS Rev 3 Sec 4.3 & UFC 3-550-01 Sec 3-11.4.1 (directional boring restricted to road/channel crossings and may not extend >50 ft beyond crossing edges) | 1958.28 | 553.51 | $47,671.31 | $12,530.21 | $101,360.20 | $165,729.41 | $327,291.13 | $463,042.42 | $236.45 | N |
| OH | Y | PCSFA-IEDS Rev 3 Sec 4.1 & UFC 3-550-01 Sec 3-10.1 (permitted south of y=300 ft outside AREA-CONGESTED with UG riser leads) | 1958.28 | 330.55 | $28,923.55 | $7,225.65 | $51,689.73 | $0.00 | $87,838.93 | $124,272.07 | $63.46 | Y |

### Item C07 (Recommended: `CEDB`, Length: `680.00 ft`, Design Current: `120 A`, Cable: `1 set(s) of 250 kcmil`)

| Type | Admissible | Governing Clause | Length (ft) | Labor (MH) | Labor ($) | Equipment ($) | Material ($) | Subcontract ($) | Direct Cost ($) | Total Project Cost ($) | Cost / LF ($/LF) | Rec |
|---|:---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|:---:|
| CEDB | Y | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (concrete-encased ductbank required for primary underground distribution; directional bores <= 25% of run per Sec 4.3) | 680.00 | 319.52 | $27,180.25 | $4,673.57 | $59,551.82 | $14,000.00 | $105,405.64 | $149,124.97 | $219.30 | Y |
| UEDB | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFC 3-550-01 Sec 3-11.2.1 (conduit without concrete encasement not permitted for installation primary distribution) | 680.00 | 271.93 | $23,317.45 | $4,835.22 | $59,037.43 | $14,000.00 | $101,190.10 | $143,160.95 | $210.53 | N |
| DBC | N | PCSFA-IEDS Rev 3 Sec 4.2 & UFGS 33 71 02 Sec 3.7.9 (direct-buried cable not permitted for installation primary distribution) | 680.00 | 139.56 | $12,044.36 | $2,685.94 | $24,198.70 | $14,000.00 | $52,929.00 | $74,882.48 | $110.12 | N |
| HDD | N | PCSFA-IEDS Rev 3 Sec 4.3 & UFC 3-550-01 Sec 3-11.4.1 (directional boring restricted to road/channel crossings and may not extend >50 ft beyond crossing edges) | 680.00 | 208.27 | $17,987.83 | $4,459.09 | $36,047.92 | $60,848.00 | $119,342.84 | $168,842.94 | $248.30 | N |
| OH | N | PCSFA-IEDS Rev 3 Sec 4.1 & UFC 3-550-01 Sec 3-11.1.1 (prohibited in AREA-CONGESTED and W-3 crane operating area AREA-CRANE) | 680.00 | 184.21 | $16,235.71 | $4,014.29 | $29,791.95 | $0.00 | $50,041.95 | $70,797.98 | $104.11 | N |

---

## 4. Government-Furnished Information (GFI) Discrepancies & Findings

| Finding ID | Document | Location | Defect | Correction Applied |
|---|---|---|---|---|
| F-01 | E-001 One-Line Diagram Rev B vs. Protective Device Settings Schedule Rev D | Feeder F1 (52-F1) | E-001 Rev B (2026-02-10) shows Feeder F1 phase overcurrent pickup (51P) as 560 A (CT 600:5), conflicting with current Protective Device Settings Schedule Rev D (2026-06-30) which sets F1 phase pickup at 640 A (CT 800:5) for MB-1 Phase 2 load. | Applied 640 A phase pickup for Item C01 per PCSFA-IEDS Rev 3 Sec 1.3(4) (protective device settings schedule governs over one-line diagram). |
| F-02 | TD-15AL-133 Cable Data Sheet Rev 3 vs. SUB-33 71 02-07 Approved Cable Submittal | Section 4.2 / Submittal Item 1 | Manufacturer catalogue sheet TD-15AL-133 Rev 3 Sec 4.2 lists maximum sidewall bearing pressure as 1,000 lb/ft, whereas Approved Submittal SUB-33 71 02-07 limits sidewall bearing pressure to 600 lb/ft for the copper-tape-shielded construction. | Applied 600 lb/ft maximum sidewall bearing pressure per PCSFA-IEDS Rev 3 Sec 1.3(3) (approved submittals govern over general catalogue data). |
| F-03 | C-101 Site Utility Plan Rev 4 vs. SUE-24-0117 Subsurface Utility Engineering Survey | Water main W-12 along x = 775 ft | C-101 Rev 4 labels existing 12-in water main W-12 with record top depth 72 in, whereas SUE-24-0117 test holes TH-1 and TH-2 measured top of pipe at 56 in below grade (-16 in shallower, bottom of 12.75 in OD pipe at 68.75 in). | Used 56 in top depth (68.75 in bottom depth) per PCSFA-IEDS Rev 3 Sec 1.3(5) and C-101 Note 2, setting MISSION-DR directional bores at 84 in cover (>=15.25 in vertical clearance below W-12). |
| F-04 | GEO-24-0117 Geotechnical Report Table 2 vs. Boring Logs B-07 and B-10 | Section 8 Table 2 (OSHA Soil Classification) | GEO-24-0117 Table 2 classifies all 12 borings B-1 through B-12 as OSHA Type B; however, boring log B-07 has poorly graded sand (SP, granular) from 3-9 ft and groundwater at 4.0 ft, and B-10 has silty sand (SM, granular) from 2-12 ft and groundwater at 3.0 ft. | Classified areas nearest B-7 and B-10 as OSHA Type C per PCSFA-IEDS Rev 3 Sec 1.3(6), Sec 4.12, and 29 CFR 1926 Subpart P Appendix A (granular/submerged soils are Type C). |
| F-05 | C-101 Site Utility Plan Rev 4 vs. TS-24-0117 Arborist Tree Survey | Layer TREES / Retained tree T-208 and TPZ radii | C-101 Rev 4 omits retained tree T-208 (14 in DBH Jacaranda at x=170, y=395) and plots tree protection circles at 0.8 ft/in DBH instead of 1.0 ft/in DBH required by PCSFA-IEDS Rev 3 Sec 4.14. | Applied TS-24-0117 tree coordinates and full 1.0 ft/in DBH protection radii (including 14 ft radius around T-208 at 170,395) per PCSFA-IEDS Rev 3 Sec 1.3(7) and C-101 Note 2A. |
| F-06 | Attachment J-3 Wage Determination CA20260022 Mod 2 vs. CA20260022 Mod 5 (2026-08-06) | ELEC0011-004 Inside Wireman / Cable Splicer | Attachment J-3 includes CA20260022 Mod 2 (2026-01-30, Journeyman Electrician $65.00 base, 3%+$35.62 fringe), whereas Modification 5 (published 2026-08-06, >10 days before 2026-10-08 sealed bid opening) updates ELEC0011-004 to $60.80 base ($63.84 splicer) and $31.59 fringe. | Applied CA20260022 Mod 5 (2026-08-06) per RFP Sec 2.1 and 29 CFR 1.6(c)(2)(ii)(A). |
| F-07 | Government_Estimate_Template_PCSFA_FY26.xlsx vs. UFS 3-701-01 & RFP Sec 3.1 | Summary Sheet Line 2 (Area Cost Factor = 1.16) | Government Estimate Template applies Area Cost Factor 1.16 (Los Angeles AFB Site #1) to bottom-up direct cost already priced with local wage determinations, local material/subcontract quotes, and Region VII equipment rates. | Set area_cost_factor_applied = 1 per RFP Sec 3.1 and UFS 3-701-01 to avoid double-counting local cost adjustments. |
