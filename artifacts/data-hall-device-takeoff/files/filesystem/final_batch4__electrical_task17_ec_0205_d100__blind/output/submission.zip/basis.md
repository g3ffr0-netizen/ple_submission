# Basis of Estimate — Electrical Device Takeoff and Priced Bill of Materials
**Project:** MERIDIAN DATA CENTER — PHASE 1, DATA HALL 1 (Owner: Northgate Colocation LLC)

## 1. Counting Conventions Applied and Governing Clauses

| Convention / Clause | Governing Document & Clause | Rule Applied |
|---|---|---|
| **C1 / E-05** (One device, one count) | `criteria/takeoff_criteria_manual.md` §1 C1, §5 E-05; `E-201`–`E-204` Note 2 | Every device is counted once and only once. Devices drawn in the shaded reference bands (`RGB 242,242,245`) beyond match lines on `E-201`–`E-204` are shown for reference only and excluded from that sheet's count. |
| **C2 / E-01, E-02** (Symbol legend authority) | `drawings/E-001_symbol_legend_and_general_notes.png` Note 1; `T-002` Note 2 | All symbols on the device plans are identified strictly against the 17 scheduled type marks on `E-001` and `E-002`. |
| **C3 / E-04, E-04b** (Unresolved symbols) | `criteria/takeoff_criteria_manual.md` §1 C3, §5 E-04, E-04b; `E-001` Note 3 | Any symbol on a plan not present in the `E-001` legend is not a scheduled device. Zero quantity is carried for it in `takeoff.csv`, `locations.csv`, and `bom.csv`, and every instance is documented in Section 4 below. |
| **C4 / E-03** (Legend mark with no instance) | `criteria/takeoff_criteria_manual.md` §1 C4, §5 E-03; `E-002` Note 5 | Scheduled type marks `R8` and `F6` appear in the `E-001`/`E-002` legend/schedule with zero instances on the plans and carry a quantity of `0`. |
| **C5 / E-06** (Keyed notes census) | `criteria/takeoff_criteria_manual.md` §1 C5, §5 E-06; `E-001` Note 8; `T-002` Note 3 | Devices required by Sheet Keynotes `1`, `2`, `3`, and `4` (`NOT SHOWN`) are counted from the geometry on `A-101`, `A-102`, and `A-601` per `UFC 3-520-01` 3-6.1.2, `UFC 3-600-01`, and `UFGS 28 31 76` 3.2.3. |
| **C6 / E-07** (Addenda & revision governance) | `addenda/ADD-02_addendum_two.md` Item 02-1; `T-002` Note 4; `E-001` Note 4 | Addendum No. 02 (`2026-08-07`) postdates the Revision 2 sheet issue (`2026-07-27`) and governs for Grid Bay `A1` on `E-201`. |
| **C7 / E-08** (Enlarged plan cross-references) | `criteria/takeoff_criteria_manual.md` §1 C7, §5 E-08; `E-001` Note 9; `E-201`–`E-204` Note 3 | The West Electrical/Entry strip (`102`/`103`) and East PDU Gallery are drawn empty on `E-201`–`E-204` and counted once from enlarged plans `E-231`, `E-232`, and `E-233`. |
| **C8 / E-10–E-14** (Condition assembly dragging) | `criteria/takeoff_criteria_manual.md` §1 C8, §2, §5 E-10–E-14; `spec/26_05_33`, `26_20_00`, `07_84_00` | Every `(type_mark, condition)` pair drags in its complete permitted assembly of device, box, plaster ring, blank cover, intumescent firestop pad, or isolated-ground conductor. |
| **C9 / E-16** (Division 23/26 scope split) | `spec/28_31_76_fire_detection_and_alarm.md` §1.3; `T-002` Note 6; `E-002` | Duct smoke detectors (`D1`) are furnished under Division 23 and installed/wired under Division 26 (`INS-DUCT-DET` only; no detector material item). |

## 2. Governing Issue and Addendum Analysis (`E-07`)

- **Base IFC Issue (`2026-07-24`) & Revision 2 / Addendum 1 (`2026-07-27`):** All drawing sheets (`A-101`, `A-102`, `E-201`–`E-204`, `E-211`, `E-231`–`E-233`) carry Revision 2 dated `2026-07-27` (`IN-ROW CRAH UNITS ADDED`).
- **Addendum No. 02 (`2026-08-07`):** Postdates the `2026-07-27` drawing revision and therefore governs where it modifies the drawings:
  - **Item 02-1 (Grid Bay `A1` on `E-201`):** Deletes the **4 duplex receptacles (`R1`)** inside the Revision 2 cloud in Grid Bay `A1` on `E-201` (at pixel coordinates `(915, 2530)`, `(1068, 2310)`, `(1068, 1836)`, and `(1068, 1458)`) serving withdrawn cabinet positions, and **adds 2 quadraplex receptacles (`R2`)** at the positions of the first and second deleted receptacles measured from the south (`(915, 2530)` and `(1068, 2310)`, both in Bay `A1`, nearest to the South `P2` wall = `DRY-MASONRY`).
  - Per Item 02-1, no other device on any sheet is deleted, added, or relocated by Addendum No. 02; the `2026-07-27` sheets govern for all other locations.

## 3. Sheet-by-Sheet Takeoff Summary (`E-01`–`E-09`)

| Type Mark | Description | E-201 | E-202 | E-203 | E-204 | E-211 | E-231 | E-232 | E-233 | Total Quantity |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `R1` | RECEPTACLE, DUPLEX, 20 A, 125 V, WALL-MOUNTED | 7 | 9 | 2 | 2 | 0 | 9 | 7 | 6 | **42** |
| `R2` | RECEPTACLE, QUADRAPLEX, 20 A, 125 V, WALL-MOUNTED | 2 | 0 | 0 | 0 | 0 | 0 | 3 | 3 | **8** |
| `R3` | RECEPTACLE, DUPLEX, GROUND-FAULT CIRCUIT INTERRUPTER, 20 A | 0 | 0 | 0 | 0 | 0 | 3 | 3 | 2 | **8** |
| `R4` | RECEPTACLE, DUPLEX, ISOLATED GROUND, 20 A, 125 V | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 2 | **5** |
| `R5` | RECEPTACLE, DUPLEX, WEATHER-RESISTANT, WITH EXTRA-DUTY WHILE-IN-USE COVER | 13 | 9 | 5 | 5 | 0 | 0 | 0 | 0 | **32** |
| `R6` | RECEPTACLE, DUPLEX, EMERGENCY BRANCH, 20 A, 125 V | 1 | 0 | 1 | 0 | 0 | 1 | 0 | 1 | **4** |
| `R7` | BOX, OUTLET, FLOOR, TWO-GANG, IN ACCESS FLOOR | 0 | 3 | 0 | 3 | 0 | 0 | 0 | 0 | **6** |
| `R8` | RECEPTACLE, SINGLE, 50 A, 250 V, WALL-MOUNTED | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | **0** |
| `J1` | BOX, JUNCTION, 100 MM SQUARE, CONCEALED | 11 | 3 | 4 | 3 | 0 | 4 | 1 | 0 | **26** |
| `P1` | BOX, PULL, 300 X 300 X 150 MM, SURFACE | 1 | 1 | 1 | 0 | 0 | 2 | 1 | 1 | **7** |
| `F1` | APPLIANCE, NOTIFICATION, VISIBLE, WALL-MOUNTED | 0 | 0 | 0 | 0 | 12 | 0 | 0 | 0 | **12** |
| `F2` | APPLIANCE, NOTIFICATION, AUDIBLE-VISIBLE, WALL-MOUNTED | 0 | 0 | 0 | 0 | 1 | 2 | 0 | 1 | **4** |
| `F3` | STATION, MANUAL, FIRE ALARM, WALL-MOUNTED | 0 | 0 | 0 | 0 | 2 | 0 | 0 | 1 | **3** |
| `F4` | DETECTOR, SMOKE, PHOTOELECTRIC, CEILING-MOUNTED | 0 | 0 | 0 | 0 | 6 | 0 | 0 | 0 | **6** |
| `F5` | DETECTOR, SMOKE, PHOTOELECTRIC, IN ACCESS FLOOR | 0 | 0 | 0 | 0 | 25 | 0 | 2 | 3 | **30** |
| `F6` | DETECTOR, SMOKE, PROJECTED BEAM, WALL-MOUNTED | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | **0** |
| `D1` | DETECTOR, SMOKE, DUCT, FURNISHED UNDER DIVISION 23 | 0 | 0 | 0 | 0 | 25 | 1 | 1 | 0 | **27** |

### Keyed Notes Breakdown (`C5`, `E-06`)
1. **Keynote `<1>` (`F1` — Visible Notification Appliance at Each Structural Column Bay on North and South Walls, Not Shown):** 3 vertical column grid lines (`1`, `2`, `3`) form **4 structural column bays** along the North wall (`D1`–`D4`) and **4 structural column bays** along the South wall (`A1`–`A4`), requiring **8 `F1`** appliances (`DRY-MASONRY` on `P2` walls), per `UFC 3-600-01` and `spec/28_31_76` §3.3.
2. **Keynote `<4>` (`F1` — Visible Notification Appliance on the Wall at Each Exit Door, Not Shown):** The Door Schedule on `A-102` schedules 5 doors: `D-01` (`IN: P-R1`, `EGRESS: YES`, Bay `A1`), `D-02` (`IN: P-R1`, `EGRESS: YES`, Bay `C1`), `D-03` (`IN: P-R1`, `EGRESS: NO`), `D-04` (`IN: W-W`, `EGRESS: YES`, Bay `A1`), and `D-05` (`IN: W-E`, `EGRESS: YES`, Bay `B4`). The **4 egress/exit doors** (`D-01`, `D-02`, `D-04`, `D-05`) require **4 `F1`** appliances: 2 in `RATED-2HR` (`D-01` and `D-02` in `P-R1` / `P3`) and 2 in `DRY-STUD` (`D-04` in West `P1` wall `W-W`, `D-05` in East `P1` wall `W-E`). Combined with Keynote `<1>`, total `F1` = **12**.
3. **Keynote `<2>` (`R5` — Weather-Resistant Duplex Receptacle with Extra-Duty While-in-Use Cover within 7.6 m of Each CRAH Unit, Not Shown):** On `A-101` (Rev 2, `2026-07-27`), there are **28 CRAH units** (`4` perimeter units `CRAH-01`–`04` + `24` in-row units `CRAH-A01`–`F04`, 4 per row across 6 rows), requiring **28 `R5`** receptacles per `UFC 3-520-01` 3-6.1.2 (plus **4 drawn `R5`** symbols in the West `DAMP` zone on `E-201` = **32 `R5`** total). Per the task convention (*'A device required by a keyed note and drawn nowhere takes the construction of the wall the note names ..., or DRY-STUD where the note names none'*), the 28 un-drawn Keynote `<2>` `R5` devices take `DRY-STUD`, while the 4 drawn `R5` devices on `E-201` take `DAMP`.
4. **Keynote `<3>` (`R7` — Two-Gang Floor Outlet Box in Access Floor at Each PDU, Not Shown):** On `A-101` and `A-601` Table 3, there are **6 PDUs** (`PDU-01` through `PDU-06` in the East Gallery, 1 per cabinet row A–F), requiring **6 `R7`** floor boxes (`ACCESS-FLOOR`).

## 4. Unresolved Symbols (`C3`, `E-04`, `E-04b`)

Every symbol on any plan that does not appear in the Symbol Legend on `E-001` is excluded from `takeoff.csv`, `locations.csv`, and `bom.csv` (quantity `0`) and documented below:

| Sheet | View / Location | Structural Grid Bay | Pixel / Tile Coordinates | Visual Description & Reason Unresolved |
|---|---|---|---|---|
| `E-232` | View 9 (`PDU GALLERY — 2 OF 7`) | `A4` | `px = 1306, py = 2895` (Tile `BQ09`) | Square with an inscribed rotated diamond inside. Not in `E-001` legend (`R7` in `E-001` is a square with an inscribed circle, not a diamond). |
| `E-233` | View 13 (`PDU GALLERY — 6 OF 7`) | `C4` | `px = 1306, py = 3138` (Tile `BQ32`) | Square with an inscribed rotated diamond inside. Not in `E-001` legend (`R7` in `E-001` has an inscribed circle). |

*(Note on `E-202` and `E-233` triangle-over-circle/bar symbols at `E-202` `(1756, 590)` [ref band `B3`], `(1693, 1436)` [`B3`], `(1756, 1814)` [`A3`], `(1756, 2287)` [`A3`] and `E-233` View 11 `(715, 1633)` / `(546, 1790)` [`B4`] and View 12 `(2973, 890)` / `(2815, 914)` [`C4`]: pixel-level template correlation confirms these 5 active instances match row 4 (`R4`, Isolated Ground Duplex Receptacle, 546 dark pixels, IoU = 0.92–0.96) of `E-001`; their exact locations and grid bays are documented here for full transparency.)*

## 5. Condition Split, Precedence Rules, and `A-102` Wall Geometry (`C8`, `E-11`, `E-14`)

1. **Precedence Order Applied:**
   - **Rule 1 (`E-002` branch/mounting & `D1` convention):** `R6` -> `EMERGENCY`; `R4` -> `IG`; `F4` and `D1` -> `CEILING`; `R7` and `F5` -> `ACCESS-FLOOR`.
   - **Rule 2 (`DAMP` hatched zones on `A-102`):** Any remaining drawn device inside Room `103 ENTRY VESTIBULE (DAMP)` (`X <= 1500 mm, Y <= 7800 mm`) or the `CRAH CONDENSATE APRON — DAMP` zones is assigned `DAMP`.
   - **Rule 3 (Nearest wall centreline on `A-102`):** Any other drawn wall-condition device takes the construction of the nearest wall on `A-102` measured to its centreline:
     - **Partition Type `P1` (`DRY-STUD`):** West wall (`W-W`, `X = -75 mm`), East wall (`W-E`, `X = 27,075 mm`), and Vestibule north partition (`Y = 7,800 mm, X in [0, 1500] mm`) — steel stud and gypsum board partition (`A-102` Note 2).
     - **Partition Type `P2` (`DRY-MASONRY`):** South wall (`Y = -100 mm`) and North wall (`Y = 23,500 mm`) — nominal 200 mm concrete masonry (`A-102` Note 3).
     - **Partition Type `P3` / `P-R1` (`RATED-2HR`):** Interior 2-hour fire-rated assembly (`X = 1,500 mm`, `A-102` Note 4). Per `spec/07_84_00` §3.1 and `UFC 3-520-01` 3-6.1 (`E-14`), every box in `P3` receives a listed intumescent firestop pad (`ACC-FIRESTOP-PAD`) and maintains a minimum **300 mm (12 inch)** horizontal separation between boxes on opposite faces of the wall.
   - **Rule 4 (Un-drawn keyed note devices):** Takes the construction of the wall named by the note (`DRY-MASONRY` for Keynote `<1>` on North/South walls; `RATED-2HR` for Exit Doors `D-01`, `D-02` in `P-R1` and `DRY-STUD` for Exit Doors `D-04`, `D-05` in `W-W`/`W-E` under Keynote `<4>`), or `DRY-STUD` where the note names no wall (Keynote `<2>` `R5`).
2. **Missing Catalogue Item Statement (`DAMP` While-in-Use Hood):**
   - `spec/26_20_00` §2.3 (`UFGS 26 20 00` 2.12.2) requires a gasketed, hinged, lockable, weather-resistant, **extra-duty rated while-in-use hood** for weather-resistant receptacles (`R5` / `DAMP`). **The project device catalogue (`product_data/device_catalogue_2026.md`) carries no while-in-use hood item; therefore, per the project instructions, this is stated here in the basis and no line item is carried for the hood in `bom.csv`.**

## 6. Mounting Heights Schedule (`E-15`)

Per `drawings/E-002_device_and_mounting_schedule.md` Note 1 and `spec/26_20_00` §3.1 (`UFGS 26 20 00` 3.1.10), all mounting heights are measured **to the centre of the device or outlet** (except `F3`, measured to the operating handle per `UFGS 28 31 76` 3.2.3):

| Type Marks | Scheduled Mounting Height | Mounting Location | Governing Clause |
|---|---|---|---|
| `R1`, `R2`, `R3`, `R4`, `R5`, `R6` | **460 mm (18 in) AFF** (to centre) | Wall | `E-002`; `spec/26_20_00` §3.1 (`UFGS 26 20 00` 3.1.10) |
| `R7` | **FLUSH IN FLOOR** | In Access Floor | `E-002`; `spec/26_05_33` §2.6 |
| `R8` | **1200 mm AFF** (to centre) | Wall | `E-002`; `spec/26_20_00` §3.1 |
| `J1`, `P1` | **2600 mm AFF** (to centre) | Wall (concealed / surface) | `E-002`; `spec/26_05_33` §2.7, §2.8 |
| `F1`, `F2`, `F6` | **2286 mm (90 in) AFF** (to centre) | Wall | `E-002`; `spec/28_31_76` §2.1 |
| `F3` | **1067 mm (42 in) AFF** (to operating handle; <= 1.5 m [5 ft] from exit door) | Wall | `E-002`; `spec/28_31_76` §3.1 (`UFGS 28 31 76` 3.2.3) |
| `F4` | **CEILING** | Ceiling | `E-002`; `spec/28_31_76` §3.2 (`NFPA 72`) |
| `F5` | **IN ACCESS FLOOR** (21 m2 [225 sq ft] coverage per detector) | In Access Floor Plenum | `E-002`; `spec/28_31_76` §3.2 (`UFGS 28 31 76` 3.2.5) |
| `D1` | **AT UNIT** (in CRAH supply duct) | In Supply Duct | `E-002`; `spec/28_31_76` §1.3 |

## 7. Chosen Catalogue Assemblies and Permitting Clauses (`E-12`–`E-17`)

| `(type_mark, condition)` Pair | Pair Count | Chosen Assembly (`line_item` x Multiplicity) | Permitting Specification & Standard Clauses |
|---|---:|---|---|
| `(D1, CEILING)` | 27 | `INS-DUCT-DET` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F1, DRY-MASONRY)` | 8 | `APP-STROBE-120` x 1 + `BOX-MAS-4KO` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F1, DRY-STUD)` | 2 | `APP-STROBE-120` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F1, RATED-2HR)` | 2 | `APP-STROBE-120` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 + `ACC-FIRESTOP-PAD` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F2, DAMP)` | 1 | `APP-HS-24` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F2, DRY-STUD)` | 1 | `APP-HS-24` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F2, RATED-2HR)` | 2 | `APP-HS-24` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 + `ACC-FIRESTOP-PAD` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F3, DRY-MASONRY)` | 1 | `APP-PULL` x 1 + `BOX-MAS-4KO` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F3, DRY-STUD)` | 1 | `APP-PULL` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F3, RATED-2HR)` | 1 | `APP-PULL` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 + `ACC-FIRESTOP-PAD` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F4, CEILING)` | 6 | `DET-PHOTO` x 1 + `BOX-4SQ-15` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(F5, ACCESS-FLOOR)` | 30 | `DET-PHOTO-UF` x 1 + `BOX-4SQ-15` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(J1, DAMP)` | 2 | `BOX-4SQ-15` x 1 + `CVR-4SQ-BLANK` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(J1, DRY-MASONRY)` | 11 | `BOX-MAS-4KO` x 1 + `CVR-4SQ-BLANK` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(J1, DRY-STUD)` | 2 | `BOX-4SQ-15` x 1 + `CVR-4SQ-BLANK` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(J1, RATED-2HR)` | 11 | `BOX-4SQ-15` x 1 + `CVR-4SQ-BLANK` x 1 + `ACC-FIRESTOP-PAD` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(P1, DAMP)` | 2 | `BOX-PULL-12` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(P1, DRY-MASONRY)` | 1 | `BOX-PULL-12` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(P1, DRY-STUD)` | 3 | `BOX-PULL-12` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(P1, RATED-2HR)` | 1 | `BOX-PULL-12` x 1 + `ACC-FIRESTOP-PAD` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R1, DAMP)` | 3 | `DEV-DUP-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R1, DRY-MASONRY)` | 14 | `DEV-DUP-20` x 1 + `BOX-MAS-4KO` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R1, DRY-STUD)` | 17 | `DEV-DUP-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R1, RATED-2HR)` | 8 | `DEV-DUP-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 + `ACC-FIRESTOP-PAD` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R2, DRY-MASONRY)` | 2 | `DEV-DUP-20` x 2 + `BOX-MAS-4KO` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R2, DRY-STUD)` | 6 | `DEV-DUP-20` x 2 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R3, DAMP)` | 1 | `DEV-GFCI-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R3, DRY-STUD)` | 7 | `DEV-GFCI-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R4, IG)` | 5 | `DEV-IG-20` x 1 + `ACC-IG-CONDUCTOR` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R5, DAMP)` | 4 | `DEV-GFCI-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R5, DRY-STUD)` | 28 | `DEV-GFCI-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R6, EMERGENCY)` | 4 | `DEV-DUP-20` x 1 + `BOX-4SQ-15` x 1 + `RING-1G-58` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |
| `(R7, ACCESS-FLOOR)` | 6 | `BOX-FLOOR-2G` x 1 | Spec 26 05 33 §2.2–2.9; Spec 26 20 00 §2.1–2.5; Spec 07 84 00 §2.1, §3.1; Spec 28 31 76 §1.3–3.2 |

## 8. Spare-Stock, Carton Rounding, and Band Pricing Method (`E-18`–`E-21`)

1. **Quantity Band Pricing (`E-20`):** For each catalogue item, the total **required work quantity** `Q_req` is summed across all attribution rows. The unit price for **both** attribution rows and the purchase row is taken from `product_data/price_list_2026Q2.md` for the item's own quantity band (`BAND 1`, `BAND 2`, or `BAND 3`) that `Q_req` falls in, before spare stock and carton rounding.
2. **Owner's 5% Spare Stock & Whole Carton Rounding (`E-18`, `E-19`):** Per `project/OPR.md` §4 and `criteria/takeoff_criteria_manual.md` §4.3, the purchased quantity on each `(PURCHASE)` / `(STOCK)` row is `ceil(ceil(1.05 * Q_req) / CARTON) * CARTON`.

| Line Item | Description | Total Required (`Q_req`) | Price Band | Unit Price ($) | Carton Size | Min w/ 5% Spare | Purchased (`Q_buy`) | Attribution Extended ($) | Purchase Extended ($) |
|---|---|---:|---|---:|---:|---:|---:|---:|---:|
| `ACC-FIRESTOP-PAD` | PAD, FIRESTOP, INTUMESCENT, OUTLET BOX | 25 | `24-199` | $94.06 | 10 | 27 | 30 | $2351.50 | $2821.80 |
| `ACC-IG-CONDUCTOR` | CONDUCTOR, INSULATED EQUIPMENT GROUNDING, PER DEVICE | 5 | `3-23` | $3.36 | 10 | 6 | 10 | $16.80 | $33.60 |
| `APP-HS-24` | APPLIANCE, NOTIFICATION, HORN-STROBE, 24 V AC | 4 | `3+` | $74.35 | 1 | 5 | 5 | $297.40 | $371.75 |
| `APP-PULL` | STATION, MANUAL, FIRE ALARM, DOUBLE ACTION | 3 | `2-11` | $81.06 | 1 | 4 | 4 | $243.18 | $324.24 |
| `APP-STROBE-120` | APPLIANCE, NOTIFICATION, STROBE, RED, 120 V AC | 12 | `4-35` | $299.44 | 1 | 13 | 13 | $3593.28 | $3892.72 |
| `BOX-4SQ-15` | BOX, OUTLET, 4 IN SQUARE, 1-1/2 IN DEEP, 1/2 IN KO | 144 | `75-749` | $1.99 | 25 | 152 | 175 | $286.56 | $348.25 |
| `BOX-FLOOR-2G` | BOX, FLOOR, RECESSED, STEEL, TWO-GANG | 6 | `3-23` | $104.36 | 1 | 7 | 7 | $626.16 | $730.52 |
| `BOX-MAS-4KO` | BOX, MASONRY, 3-1/2 IN DEEP, 4 KO | 36 | `30-249` | $22.02 | 25 | 38 | 50 | $792.72 | $1101.00 |
| `BOX-PULL-12` | BOX, PULL, 12 X 12 X 6 IN, SCREW COVER | 7 | `4-29` | $34.75 | 1 | 8 | 8 | $243.25 | $278.00 |
| `CVR-4SQ-BLANK` | COVER, 4 IN SQUARE, FLAT BLANK | 26 | `20-199` | $0.81 | 10 | 28 | 30 | $21.06 | $24.30 |
| `DET-PHOTO` | DETECTOR, SMOKE, PHOTOELECTRIC, CEILING, WITH BASE | 6 | `3-23` | $116.39 | 1 | 7 | 7 | $698.34 | $814.73 |
| `DET-PHOTO-UF` | DETECTOR, SMOKE, PHOTOELECTRIC, ACCESS FLOOR, WITH BASE | 30 | `15-119` | $133.02 | 1 | 32 | 32 | $3990.60 | $4256.64 |
| `DEV-DUP-20` | RECEPTACLE, DUPLEX, 20 A 125 V, 5-20R, SPEC GRADE | 62 | `40-399` | $5.18 | 10 | 66 | 70 | $321.16 | $362.60 |
| `DEV-GFCI-20` | RECEPTACLE, DUPLEX, GFCI, 20 A 125 V, WEATHER-RESISTANT | 40 | `20-199` | $20.03 | 10 | 42 | 50 | $801.20 | $1001.50 |
| `DEV-IG-20` | RECEPTACLE, DUPLEX, ISOLATED GROUND, 20 A 125 V, 5-20R | 5 | `3-23` | $24.25 | 10 | 6 | 10 | $121.25 | $242.50 |
| `INS-DUCT-DET` | INSTALLATION OF DUCT SMOKE DETECTOR FURNISHED UNDER DIVISION 23 | 27 | `15-119` | $98.15 | 1 | 29 | 29 | $2650.05 | $2846.35 |
| `RING-1G-58` | RING, PLASTER, 4 IN SQUARE, 5/8 IN RAISED, ONE DEVICE | 93 | `40-299` | $1.09 | 25 | 98 | 100 | $101.37 | $109.00 |

## 9. Basket Total Summary (`E-21`, `E-22`)

- **BASKET TOTAL (Sum of Attribution Rows Extended Price):** **`$17155.88`**
- **Total Purchase Expenditure (Sum of `(PURCHASE)` / `(STOCK)` Rows Extended Price):** **`$19559.50`**

## 10. Scope Exclusions
- Unresolved symbols appearing on any plan that are not defined in the symbol legend on E-001 are not scheduled devices: carry no quantity for them in takeoff.csv, locations.csv, or bom.csv, and list them in basis.md with sheet and grid bay.
- While-in-use extra-duty hood required for DAMP receptacles has no item in the device catalogue: state this in basis.md and carry no line item for the hood in bom.csv.
- Duct smoke detectors (D1) are furnished under Division 23 (HVAC) and installed/wired under Division 26/28: carry only the installation item (INS-DUCT-DET) and do not carry the detector itself as a material item.
- Devices shown in shaded match-line reference bands beyond the match line on quadrant plans E-201 through E-204 are shown for reference only and are counted on the adjacent sheet.
- Areas cross-referenced to enlarged plans E-231, E-232, and E-233 are drawn empty of devices on parent plans E-201 through E-204; devices in those areas are counted once from the enlarged plans.
- Duplex receptacles (R1) inside the Revision 2 cloud in grid bay A1 on E-201 are deleted per Addendum No. 02 (2026-08-07) Item 02-1 and replaced at the first and second positions from the south with one quadraplex receptacle (R2) each.
