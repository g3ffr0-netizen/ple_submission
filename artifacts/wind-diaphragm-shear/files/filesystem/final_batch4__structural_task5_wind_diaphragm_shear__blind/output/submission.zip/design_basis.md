# Building A2 — Lateral Package Design Basis Narrative

**Project:** Northern Divide Data Campus — Building A2 (Lewis and Clark County, Montana)  
**Permit Application:** 2026-0418  
**Engineer of Record:** Kestrel Ridge Structural Engineers, PLLC  
**Governing Structural Criteria:** `EOR-NDDC-A2-S01` Revision 2 (14 August 2026)  

---

## 1. Summary of Wind Load and Geometric Design Basis Parameters

In accordance with Specification `01 33 00` Section 1.6, Table 1 below records the governing design basis parameters, their adopted values, and the authoritative source documents from which they are derived.

| item | value | source |
| --- | --- | --- |
| Kzt | 1.19 | TS-2026-02 Clause 4; NDDC-AHJ-014 Clause 2; EOR-NDDC-A2-S01 Clause 4.3 |
| Ke | 0.8671 | EOR-NDDC-A2-S01 Clause 4.4; ALTA-2025-77 Clause 1 |
| q_h_psf | 28.75 | EOR-NDDC-A2-S01 Clause 4.2; NDDC-AHJ-014 Clause 2 |
| screen_wall_top_ft | 36.0 | SR-2026-118 Clause 5.2; A-301 Rev C; NDDC-A2_Federated_Model_2026.ifc |
| asbuilt_opening_panel | S14 | NDDC-A2_Federated_Model_2026.ifc (S14-O1); EOR-NDDC-A2-S01 Clause 5.3 |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 Clause 3.3 |
| omega_d | 2.35 | CDS-B36 Note 2; EOR-NDDC-A2-S01 Clause 7.2 |
| analysis_method | DIAPH-MT 1.0 | EOR-NDDC-A2-S01 Section 9; NDDC-AHJ-014 Clause 3 |
| mesh_level | L2 | EOR-NDDC-A2-S01 Clauses 9.1 and 9.7 |
| governing_code | 2021 IBC / ASCE 7-16 (ARM 24.301.131) | NDDC-AHJ-014 Clause 1; EOR-NDDC-A2-S01 Clause 2 |
| risk_category | III | NDDC-AHJ-014 Clause 2; EOR-NDDC-A2-S01 Clause 2; UFC 3-301-01 Table 2-2 |
| V_mph | 115 | NDDC-AHJ-014 Clause 2; EOR-NDDC-A2-S01 Clause 4.2 |
| exposure | C | NDDC-AHJ-014 Clause 2; EOR-NDDC-A2-S01 Clause 4.1 |
| Kd | 0.85 | NDDC-AHJ-014 Clause 2; EOR-NDDC-A2-S01 Clause 4.2 |
| zg_ft | 3940.0 | ALTA-2025-77 Clause 1 |
| h_ft | 28.0 | SR-2026-118 Clause 3; A-101 Rev C; NDDC-A2_Federated_Model_2026.ifc |
| Kz_h | 0.9681 | EOR-NDDC-A2-S01 Clause 4.2 |
| GCpi | +/-0.18 | EOR-NDDC-A2-S01 Clause 4.1 |
| parapet_z_typ_ft | 31.0 | SR-2026-118 Clause 4; A-301 Rev C; NDDC-A2_Federated_Model_2026.ifc |
| q_p_typ_psf | 29.37 | EOR-NDDC-A2-S01 Clauses 4.2 and 6.1 |
| screen_z_ft | 36.0 | SR-2026-118 Clause 5.2; A-301 Rev C; NDDC-A2_Federated_Model_2026.ifc |
| q_p_screen_psf | 30.31 | EOR-NDDC-A2-S01 Clauses 4.2 and 6.1 |
| roof_area_sf | 39600 | A-101 Rev C; S-201 Rev C; NDDC-A2_Federated_Model_2026.ifc |
| opening_area_sf | 1200 | A-101 Rev C; S-201 Rev C; NDDC-A2_Federated_Model_2026.ifc |

---

## 2. Governing Wind Scenario by Shear Wall Line

In accordance with Specification `01 33 00` Section 1.6, Table 2 below identifies the governing wind scenario (out of `W01` through `W12`) that produces the maximum in-plane diaphragm reaction on each exterior shear wall line.

| line | governing scenario |
| --- | --- |
| S | W07 |
| E | W10 |
| N1 | W07 |
| W | W01 |
| N2 | W03 |
| E2 | W01 |

---

## 3. Resolution of Document Conflicts and Superseded Revisions

In accordance with Specification `01 33 00` Section 1.6 and Document Transmittal `T-204`, the following conflicts between issued documents, field surveys, and archived/superseded files were identified and resolved:

1. **Risk Category and Basic Wind Speed (`NDDC-AHJ-014` & `EOR-NDDC-A2-S01` Rev 2 vs. Superseded 2024 Pre-Application Wind Note & `EOR-NDDC-A2-S01` Rev 0):**  
   The superseded 2024 pre-application wind note and archived criteria `EOR-NDDC-A2-S01` Rev 0 specified Risk Category II with an ultimate basic wind speed of `V = 105 mph`. In letter `NDDC-AHJ-014` (11 June 2026), the Lewis and Clark County Building Division classified Building A2 in **Risk Category III** (consistent with `UFC 3-301-01` Table 2-2 for mission-essential data handling facilities) with an ultimate basic wind speed of **`V = 115 mph`**, Exposure Category C, and `Kd = 0.85`. `NDDC-AHJ-014` and `EOR-NDDC-A2-S01` Rev 2 (issued 14 August 2026) govern.

2. **Topographic Wind Speedup Factor (`TS-2026-02` & `NDDC-AHJ-014` vs. Superseded `EOR-NDDC-A2-S01` Rev 0):**  
   Superseded criteria `EOR-NDDC-A2-S01` Rev 0 assumed a flat site with `Kzt = 1.00`. The site-specific topographic study `TS-2026-02` established that Building A2 occupies a valley bench rising 190 ft over 1,500 ft where the escarpment case governs, yielding **`Kzt = 1.19`** across the entire Building A2 footprint at all elevations and azimuths (`TS-2026-02` Clause 4; `NDDC-AHJ-014` Clause 2; `EOR-NDDC-A2-S01` Rev 2 Clause 4.3).

3. **As-Built Roof Footprint, Generator Yard Notch, and Mechanical Well Opening (`NDDC-A2_Federated_Model_2026.ifc`, `A-101` Rev C, & `S-201` Rev C vs. Superseded `A-101` Rev A & `EOR-NDDC-A2-S01` Rev 0):**  
   Superseded architectural plan `A-101` Rev A and `EOR-NDDC-A2-S01` Rev 0 depicted Building A2 as a clean 240 ft by 180 ft rectangle (`43,200 sf`) with no roof openings and only four exterior wall lines (`S, E, N, W`). The 2026 federated BIM model (`NDDC-A2_Federated_Model_2026.ifc`), `A-101` Rev C, and `S-201` Rev C establish that the building has a **60 ft by 40 ft re-entrant generator yard notch** at the north-east corner (`x = 180..240 ft, y = 140..180 ft`, bounded by shear wall lines `N2` at `y = 140 ft` and `E2` at `x = 180 ft`) and a **40 ft by 30 ft mechanical well roof opening** (`x = 100..140 ft, y = 100..130 ft`, `1,200 sf`), resulting in a net roof deck diaphragm area of **`39,600 sf`**. The 2026 as-built geometry governs.

4. **North Mechanical Screen Wall Elevation (`NDDC-A2_Federated_Model_2026.ifc`, `SR-2026-118`, `Roof_Line_Scan_2026-08-14.ply`, `A-301` Rev C, & `PC-S02` Rev 2 vs. `PC-S01` 2024 Schedule & Superseded `PC-S02` Rev 1):**  
   The 2024 precast fabrication schedule `PC-S01_Precast_Panel_Schedule_2024.xlsx` and superseded elevation drawing `PC-S02` Rev 1 listed a uniform panel top elevation of `31.0 ft` (`3.0 ft` parapet above the `28.0 ft` roof deck) for all 63 panels. However, the 2026 LiDAR roof line scan (`SR-2026-118` Clause 5.2 and `Roof_Line_Scan_2026-08-14.ply`), the 2026 federated model (`NDDC-A2_Federated_Model_2026.ifc`), `OBD-NDDC-A2` Clause 4.3, `A-301` Rev C, and `PC-S02` Rev 2 confirm that between `x = 96.0 ft` and `x = 168.0 ft` on wall line `N1` (panels `N108` at `96–120 ft`, `N109` at `120–144 ft`, `N110` at `144–156 ft`, and `N111` at `156–168 ft`, while `N112` at `168–180 ft` is at `31.0 ft`), the integral solid precast screen wall extends to **`screen_wall_top_ft = 36.0 ft` AFF** (`8.0 ft` cantilevering above the `28.0 ft` roof deck). Per `EOR-NDDC-A2-S01` Clause 5.3 and `T-204` Note 5, `36.0 ft` governs for `x = 96..168 ft`, increasing both the wind cantilever reaction delivered to the roof diaphragm (`q_p(36) = 30.31 psf` over an `8.0 ft` height with centroid at `z = 32.0 ft`, lever ratio `32.0 / 28.0 = 1.1429`) and the gross panel self-weight resisting overturning.

5. **Field-Cut Doorway Opening `S14-O1` in Panel `S14` and Neglect of Narrow Pier Leg (`NDDC-A2_Federated_Model_2026.ifc` & `PC-S02` Rev 2 vs. `PC-S01` 2024 Schedule & Superseded `PC-S02` Rev 1):**  
   The 2024 schedule `PC-S01` and superseded `PC-S02` Rev 1 listed panel `S14` (`x = 192.0..204.0 ft` on wall line `S`) as a solid panel (`openings = none`). The 2026 federated model (`NDDC-A2_Federated_Model_2026.ifc`, element `S14-O1`) and `PC-S02` Rev 2 Note 4 document an **8.0 ft wide by 12.0 ft high doorway field-cut after erection** from `x = 194.5 ft` to `202.5 ft`. This opening divides panel `S14` (`t = 8 in`, `h = 28.0 ft = 336 in`) into a west leg of width `194.5 - 192.0 = 2.5 ft` (`>= 2.0 ft`, valid pier with in-plane stiffness `k = 5.70 kip/in` [`5.7029 kip/in`], matching the `Piers` schedule) and an east leg of width `204.0 - 202.5 = 1.5 ft`. Per `EOR-NDDC-A2-S01` Clause 5.4, any leg narrower than `2.0 ft` is neglected and assigned zero stiffness (`k = 0`). The gross panel self-weight of `S14` is retained without deduction for openings per Clause 5.8.

6. **Diaphragm Analysis Methodology and Exclusion of Hall B Study (`NDDC-AHJ-014` Clause 3 & `EOR-NDDC-A2-S01` Rev 2 Section 9 vs. `EOR-NDDC-A2-S01` Rev 0 & `HallB_Lateral_Study_2023`):**  
   Superseded criteria `EOR-NDDC-A2-S01` Rev 0 and the archived study `HallB_Lateral_Study_2023` (which pertains to a different building, Hall B, on the campus) used a flexible-diaphragm tributary area method and omitted parapet cantilever amplification. Both `NDDC-AHJ-014` Clause 3 and `EOR-NDDC-A2-S01` Rev 2 Section 9 explicitly reject flexible or rigid distributions and mandate the **semi-rigid finite element procedure `DIAPH-MT 1.0`** together with full simple-beam parapet cantilever transfer (`R_roof = p * A * z / h`).

7. **Owner's Basis of Design Constraints (`OBD-NDDC-A2` Clauses 4.4–4.8):**  
   Per `OBD-NDDC-A2`, the roof deck is specified as primed steel deck only (acoustic deck is not required in data halls, Clause 4.5), limited to at most 4 distinct deck types across the roof (3 types used: `D22-36/4-4`, `D22-36/7-2`, `D22-36/7-4`, Clause 4.6), designed to hold diaphragm relative deflection within `0.55 in` (`0.5342 in` maximum achieved, Clause 4.4), and kept below the `$310,000` installed cost cap (`$215,683.74` total installed cost achieved, Clause 4.7). Commissioning (`OBD-NDDC-A2` Clause 4.8) is excluded from the structural package.

---

## 4. Explicit Scope Exclusions

- Flexible-diaphragm tributary distribution analysis is explicitly rejected by AHJ (NDDC-AHJ-014 Clause 3); semi-rigid diaphragm analysis per structural design criteria is required.
- Acoustic roof deck is not required in the data halls (OBD-NDDC-A2 Clause 4.5; primed deck only).
- Commissioning (OBD-NDDC-A2 Clause 4.8) is excluded from the structural package.
- 2024 clean-rectangle geometry and superseded archive files (A-101 RevA, EOR-NDDC-A2-S01 Rev0, PC-S02 Rev1, HallB_Lateral_Study_2023) are excluded in favor of 2026 federated model, roof line scan, and RevC/Rev2 documents.
