# Method of Procedure (MOP) and Engineering Design Basis — Process Cooling Water (PCW) Cleaning, Flushing, and Passivation

**Project:** Tull Creek Data Hall — Process Cooling Water (PCW) System Turnover Package
**Specification Authority:** Section 23 25 16 (Rev 3, 2026-07-14), Section 23 21 16 (Rev 3, 2026-07-14), Section 01 91 13 (Rev 2, 2026-05-28), Water-Treatment Criteria 3-230-13 (2023) (1 March 2023)

---

## 1. Design Basis & Governing Constraint per Circuit

Per Section 23 25 16 cl. 1.6 and the turnover package instructions, the governing constraint for each circuit is whichever of the five candidate constraint families leaves the smallest fractional margin `(limit - achieved) / limit` (for an upper limit) or `(achieved - limit) / limit` (for a lower limit) under the executed plan:
1. **Flushing duty against available skid head (`head`)**: `(skid_head_avail_ft - required_head_ft) / skid_head_avail_ft`
2. **Rinse endpoint (`rinse`)**: expressed either in **conductivity** `(676.5 - C_n) / 676.5` against the Water-Treatment Criteria 3-230-13 (2023) cl. 5-7.3.2.2e upper limit of `676.5 microS/cm` (`1.10 x 615 microS/cm`), or in **displacements** `(n_r - n_min) / n_min` (or `(n_r - n_min) / n_r`)
3. **Authorised programme sanitary sewer discharge volume (`discharge_volume`)**: `(500,000 - 496,283.99) / 500,000 = 0.007432` against the `500,000 gal` programme cap of `SW-03 Rev B` (`IWD-2026-0417`)
4. **Site daily construction water allocation (`daily_water_allocation`)**: minimum over all calendar days on which the circuit draws water of `(daily_limit_gal - daily_draw_gal) / daily_limit_gal`
5. **Temporary electrical power at the tie-in (`tie_in_power`)**: `(available_kW - connected_kW) / available_kW` per `SW-04` and `E-701`

### 1.1 Mandatory Governing Constraint Declarations (Section 23 25 16 cl. 1.6)

Across all eight circuits, the programme-wide sanitary sewer discharge cap of `500,000 gal` (`SW-03 Rev B`) has a fractional margin of **`0.007432`** (`3,716.01 gal` remaining out of `500,000 gal`), which is tighter than every circuit-specific hydraulic, rinse, daily water, and tie-in power margin. For complete transparency, both the binding programme discharge constraint line and the tightest circuit-specific (local) constraint are stated below:

GOVERNING CONSTRAINT C1: authorised programme discharge volume (margin 0.0074)
GOVERNING CONSTRAINT C2: authorised programme discharge volume (margin 0.0074)
GOVERNING CONSTRAINT C3: authorised programme discharge volume (margin 0.0074)
GOVERNING CONSTRAINT C4: authorised programme discharge volume (margin 0.0074)
GOVERNING CONSTRAINT C5: authorised programme discharge volume (margin 0.0074)
GOVERNING CONSTRAINT C6: authorised programme discharge volume (margin 0.0074)
GOVERNING CONSTRAINT C7: authorised programme discharge volume (margin 0.0074)
GOVERNING CONSTRAINT C8: authorised programme discharge volume (margin 0.0074)

### 1.2 Complete Candidate Margin Matrix Across All Five Families (Decimal Fractions)

| Circuit | Skid & Flow | 1. Skid Head Margin `(H_av - H_req)/H_av` | 2a. Rinse Conductivity Margin `(676.5 - C_n)/676.5` | 2b. Rinse Displacement Margin `(n_r - n_exact)/n_r` | 3. Programme Sewer Cap Margin `(500k - 496,284)/500k` | 4. Daily Water Allocation Margin (Metered `62k`) | 5. Tie-In Power Margin `(kW_lim - kW)/kW_lim` | Tightest Circuit-Local Family (Excl. Programme Sewer Cap) |
|---|---|---|---|---|---|---|---|---|
| **C1** | `FS-1200-A` @ `1200 gpm` | `0.2291` (`90.20` vs `117.00 ft`) | `0.0198` (`663.10` vs `676.5 uS/cm`) | `0.0660` (`5.604` vs `6 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.2020` | `0.5000` | `rinse endpoint (conductivity)` (`0.0198`) |
| **C2** | `FS-1200-A` @ `800 gpm` | `0.6118` (`65.47` vs `168.67 ft`) | `0.0198` (`663.10` vs `676.5 uS/cm`) | `0.0660` (`5.604` vs `6 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.3665` | `0.5000` | `rinse endpoint (conductivity)` (`0.0198`) |
| **C3** | `FS-1200-A` @ `800 gpm` | `0.6176` (`64.50` vs `168.67 ft`) | `0.0198` (`663.10` vs `676.5 uS/cm`) | `0.0660` (`5.604` vs `6 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.0876` | `0.2105` | `rinse endpoint (conductivity)` (`0.0198`) |
| **C4** | `FS-600-A` @ `400 gpm` | `0.2554` (`110.45` vs `148.33 ft`) | `0.0107` (`669.24` vs `676.5 uS/cm`) | `0.0349` (`7.721` vs `8 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.1527` | `0.6667` | `rinse endpoint (conductivity)` (`0.0107`) |
| **C5** | `FS-600-A` @ `480 gpm` | `0.0207` (`131.23` vs `134.00 ft`) | `0.0107` (`669.24` vs `676.5 uS/cm`) | `0.0349` (`7.721` vs `8 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.0876` | `0.6667` | `rinse endpoint (conductivity)` (`0.0107`) |
| **C6** | `FS-600-B` @ `400 gpm` | `0.2302` (`114.19` vs `148.33 ft`) | `0.0289` (`656.94` vs `676.5 uS/cm`) | `0.1063` (`7.149` vs `8 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.3959` | `0.6667` | `rinse endpoint (conductivity)` (`0.0289`) |
| **C7** | `FS-600-B` @ `350 gpm` | `0.2238` (`120.83` vs `155.67 ft`) | `0.0107` (`669.24` vs `676.5 uS/cm`) | `0.0349` (`7.721` vs `8 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.3959` | `0.3333` | `rinse endpoint (conductivity)` (`0.0107`) |
| **C8** | `FS-600-B` @ `200 gpm` | `0.3866` (`105.30` vs `171.67 ft`) | `0.0359` (`652.20` vs `676.5 uS/cm`) | `0.1351` (`5.189` vs `6 passes`) | **`0.0074`** (`496,283.99` vs `500,000 gal`) | `0.1527` | `0.7500` | `rinse endpoint (conductivity)` (`0.0359`) |

---

## 2. Circuit Topology, Volumes, Hydraulics, and Flushing Velocity Design Basis

Circuit line memberships were traced directly from the governing Revision C P&ID sheets (`M-PID-101 Rev C`, `M-PID-102 Rev C`, `M-PID-103 Rev C`, `M-PID-104 Rev C`) between the lockable lug butterfly tie-in valve pairs (`TI-C1-01/02` through `TI-C8-01/02`, `M-603`), and combined with pipe geometry from `M-601 Rev C`, equipment hold-up volumes from `M-602 Rev C`, and static lifts from `M-ISO-201..204 Rev C`:

| Circuit | Tie-In & Location | Lines (`M-601 Rev C`) | Equipment (`M-602`) & Bypass Status | Pipe Vol (gal) | Flush Vol `V_f` (gal) | System Vol `V_s` (gal) | Static Lift (ft) | Governing Line & ID | Min Req Vel (ft/s) | Declared Flow (gpm) & Vel (ft/s) |
|---|---|---|---|---|---|---|---|---|---|---|
| **C1** | `TI-C1-01/TI-C1-02` (`MER-1`) | `1041` (1x11.938" CS, 1830'), `1042` (1x11.938" CS, 1620'), `1043` (4x6.065" CS, 480'), `1044` (4x6.065" CS, 440') | `40-mesh (380 micron) temporary basket strainer; PMP-101 and BT-101 remain in flushed path` | `25583.40` | **`32983.40`** | **`32983.40`** | `26.0` | `1043` (`6.065"`) | `3.28` | `1200 gpm` (`3.3316 ft/s`) |
| **C2** | `TI-C2-01/TI-C2-02` (`MER-1`) | `2011` (1x7.981" CS, 900'), `2012` (1x7.981" CS, 780'), `2013` (3x4.026" CS, 620') | `40-mesh (380 micron) temporary basket strainer; temporary bypass spool fitted across HX-201A` | `5596.03` | **`5596.03`** | **`7946.03`** | `22.0` | `2011` (`7.981"`) | `4.00` | `800 gpm` (`5.1306 ft/s`) |
| **C3** | `TI-C3-01/TI-C3-02` (`MER-2`) | `2021` (1x7.981" CS, 840'), `2022` (1x7.981" CS, 750'), `2023` (2x6.065" CS, 690') | `40-mesh (380 micron) temporary basket strainer; temporary bypass spool fitted across HX-201B` | `6203.19` | **`6203.19`** | **`8553.19`** | `22.0` | `2023` (`6.065"`) | `4.00` | `800 gpm` (`4.4421 ft/s`) |
| **C4** | `TI-C4-01/TI-C4-02` (`L3-N`) | `4021` (1x6.065" CS, 960'), `4022` (1x6.065" CS, 880'), `4023` (2x4.026" CS, 1260'), `4024` (4x2.945" Cu, 1080') | `40-mesh (380 micron) temporary basket strainer; temporary bypass spools fitted across CDU-301 and CP-311` | `5956.63` | **`5956.63`** | **`8536.63`** | `48.0` | `4021` (`6.065"`) | `4.00` | `400 gpm` (`4.4421 ft/s`) |
| **C5** | `TI-C5-01/TI-C5-02` (`L3-S`) | `4031` (1x6.065" CS, 900'), `4032` (1x6.065" CS, 820'), `4033` (3x4.026" CS, 1200'), `4034` (4x2.945" Cu, 1020') | `40-mesh (380 micron) temporary basket strainer; temporary bypass spools fitted across CDU-302 and CP-321` | `6405.83` | **`6405.83`** | **`8985.83`** | `44.0` | `4033` (`4.026"`) | `4.00` | `480 gpm` (`4.0324 ft/s`) |
| **C6** | `TI-C6-01/TI-C6-02` (`L3-W`) | `4041` (1x6.065" CS, 1140'), `4042` (1x6.065" CS, 1040'), `4043` (3x2.945" Cu, 900') | `40-mesh (380 micron) temporary basket strainer; temporary bypass spool fitted across CP-331` | `4227.15` | **`4227.15`** | **`5677.15`** | `48.0` | `4041` (`6.065"`) | `4.00` | `400 gpm` (`4.4421 ft/s`) |
| **C7** | `TI-C7-01/TI-C7-02` (`ROOF`) | `5011` (1x6.065" CS, 990'), `5012` (1x6.065" CS, 900'), `5013` (4x2.465" Cu, 1260') | `40-mesh (380 micron) temporary basket strainer; temporary bypass spool fitted across CL-401` | `4085.96` | **`4085.96`** | **`6035.96`** | `72.0` | `5011` (`6.065"`) | `3.28` | `350 gpm` (`3.8868 ft/s`) |
| **C8** | `TI-C8-01/TI-C8-02` (`YARD`) | `6011` (1x4.026" Galv, 1140'), `6012` (1x4.026" Galv, 1040'), `6013` (2x3.068" Galv, 780') | `40-mesh (380 micron) temporary basket strainer; ST-601 remains in flushed path` | `2040.75` | **`5790.75`** | **`5790.75`** | `14.0` | `6013` (`3.068"`) | `3.28` | `200 gpm` (`4.3399 ft/s`) |

### 2.1 Key Hydraulic & Component Protection Verifications
- **Flushing Velocity Class (`23 25 16 cl. 3.3` & `Water-Treatment Criteria 3-230-13 (2023) cl. 5-3.7`)**: `Water-Treatment Criteria 3-230-13 (2023) cl. 5-3.7` requires a water velocity of at least **`3.28 ft/s (1 m/s)`** to keep foulants in suspension. `23 25 16 cl. 3.3` requires the greater of the Water-Treatment Criteria suspension velocity (`3.28 ft/s`) and the project class minimum (`4.0 ft/s` for circuits serving a plate HX or cold-plate device, `2.0 ft/s` otherwise). Therefore, `4.0 ft/s` governs on **C2, C3, C4, C5, C6**, and `3.28 ft/s` governs on **C1, C7, C8**.
- **In-Path Component Limits (`M-602` & `23 25 16 cl. 3.4`)**:
  - **Circuit C1 (`PMP-101` & `BT-101`)**: Full-bore casings/vessels with `dP_rated = 0 ft w.c.` at `1,200 gpm` (`M-602 Note 5`), max temp `200 degF` (actual `68 degF`), max particle size `800 micron` (protected by `40-mesh / 380 micron` strainer `VD-05`), pressure rating `300 psig`.
  - **Circuit C8 (`ST-601`)**: Remains in the flushed path (`dP_rated = 6 ft w.c.` at `120 gpm`, `Max Allowable dP = 25 ft w.c.`, max temp `140 degF`, max particle size `800 micron`, pressure rating `150 psig`). At the declared flow of `200 gpm`, the pressure drop across `ST-601` is `6 x (200 / 120)^2 = 16.67 ft w.c. <= 25.0 ft w.c.` (limiting flow is `244.95 gpm`), temperature is `68 degF <= 140 degF`, and the `380 micron` temporary basket strainer protects the `800 micron` limit.

---

## 3. Resolution of Document Conflicts, Defects Found, and Rejected Documents

### 3.1 Document Conflicts Resolved
1. **Sanitary Sewer Programme Discharge Cap (`SW-03 Rev B` vs `SW-03 Revision A` & `RFI-031`)**:
   - *Conflict*: `SW-03` Revision A (effective `2026-07-01`) and GC response `RFI-031` (`2026-07-06`) state a programme sewer cap of `540,000 gallons` at metered manhole `MH-14`. However, `SW-03 Revision B` (issued `2026-07-21` following a treatment plant capacity review) explicitly supersedes Revision A Section 2 and reduces the authorised programme total to **`500,000 gallons`** while keeping local limits and the `$9.40/1,000 gal` rate unchanged.
   - *Resolution*: `SW-03 Rev B` (`500,000 gallons`) governs as the latest revision of the permit. By executing `RETAIN_AND_TOP_UP` at turnover and cascading one rinse displacement along the 7-step volume-ordered chain `C1 -> C5 -> C3 -> C4 -> C8 -> C2 -> C6 -> C7` (saving `38,265.54 gal`), total sewer effluent is reduced from `534,549.53 gal` to **`496,283.99 gal <= 500,000 gal`**, avoiding any excess-volume tanker haulage.
2. **CDU Distribution Line `4033` Circuit Assignment (`M-PID-103 Rev C` & `M-601 Rev C` vs `M-PID-103 Revision A SUPERSEDED`)**:
   - *Conflict*: Superseded sheet `M-PID-103 Revision A` (`2026-05-12`) drew line `4033` (`4" CS, 2 legs`) inside Circuit `C4` (`CDU-301 / CP-311`). Governing sheet `M-PID-103 Rev C` (`2026-07-14`) and `M-601 Rev C` (`Note 5: Rev C supersedes Rev A of M-PID-103. Use Rev C sheets`) place line `4033` (`4" CS, L = 1,200 ft/leg, 3 parallel legs, Sum L/D = 320`) in Circuit `C5` (`CDU-302 / CP-321`) and line `4023` (`4" CS, 2 legs`) in Circuit `C4`.
   - *Resolution*: `M-PID-103 Rev C` and `M-601 Rev C` govern. `M-PID-103 Revision A` is rejected and excluded from `constraint_register.csv`.
3. **Water Treatment Criteria Edition & Tables (`Water-Treatment Criteria 3-230-13 (2023)` [2023] vs `Water-Treatment Criteria 3-240-13FN (2005 cancelled)` [2005 CANCELLED])**:
   - *Conflict*: Cancelled `Water-Treatment Criteria 3-240-13FN (2005 cancelled)` (`2005`) tabulated `10-12 days` film-formation time in its Table 4-11 and lacked the dedicated passivation tables (`Table 5-14` and `Table 5-15`) added in `Water-Treatment Criteria 3-230-13 (2023)` (`2023`, cl. `5-7.3.2.4`), which specify a **`14-21 day`** (`336-hour` minimum) film-formation hold, `40-50 ppm as SiO2` (`pH 7.5-8.5`) for polysilicate, and `10-20 ppm as TTA` (`pH 6.5-7.9`) for tolyltriazole. Additionally, `Table 6-2` lists `Polysilicate-azole` under diesel engine jackets, whereas controlling paragraph `6-2.2.5` explicitly states its use in closed process cooling water loops and aluminum systems.
   - *Resolution*: Per `23 25 16 cl. 1.2` and `cl. 3.5`, `Water-Treatment Criteria 3-240-13FN (2005 cancelled)` (`2005`) is cancelled and not used; controlling paragraph `6-2.2.5` governs over `Table 6-2`; and `Tables 5-14 & 5-15` of the current `2023` edition govern passivation dosages, intersected pH bands (`7.5 to 7.9` with TTA; `7.5 to 8.5` without TTA), and the `14-day (336 h)` hold period.
4. **Plate Heat Exchanger Pressure Drop Limit (`M-602` vs `VD-03`)**:
   - *Conflict*: Vendor bulletin `VD-03` lists `46 ft w.c.` as the rated-flow pressure drop of `PHE-450` (`HX-201A`, `HX-201B`), whereas `M-602` distinguishes `Pressure Drop at Rated Flow (46 ft w.c.)` from `Max Allowable Pressure Drop (58 ft w.c.)`.
   - *Resolution*: Per `M-602 Note 6` and `VD-03 Note 5`, `M-602` (`58 ft w.c.`) governs, and both `HX-201A` and `HX-201B` are isolated and bypassed via full-size temporary bypass spools during flushing and chemical cleaning.
5. **Site Instructions Modifying Baseline Utility & Fleet Memo (`SI-04` and `SI-05` vs `SW-01`)**:
   - *Resolution*: `SI-04` reduces metered construction water from `62,000 gal/day` to `31,000 gal/day` on Days 2 and 3 (`[48, 96)`) and `0 gal` on Day 6 (`[144, 168)`). `SI-05` delays delivery of `FS-1200-A` to `hour 48`. The schedule draws `0 gal` on Days 2, 3, and 6 and does not assign `FS-1200-A` before `hour 119.5419` (`>= 48 h`).

### 3.2 Commissioning Record Defects Found & Corrected
- **Missing Hydrostatic Test Pressure Recorder Charts (`CX-02` vs `01 91 13 cl. 1.3` & `23 21 16 cl. 3.3`)**:
  - *Defect*: `CX-02_Hydrostatic_Test_Record_partial.csv` lists `PASS` (`127.5 psig`, `120 min`) for all eight circuits `C1..C8`, citing recorder charts `TR-0412` through `TR-0419`. However, audit of the commissioning evidence file shows that only **`TR-0412` (C1)**, **`TR-0413` (C2)**, **`TR-0415` (C4)**, and **`TR-0419` (C8)** are on file; charts **`TR-0414` (C3)**, **`TR-0416` (C5)**, **`TR-0417` (C6)**, and **`TR-0418` (C7)** are missing.
  - *Corrective Action*: Per `01 91 13 cl. 1.3` (*'a result whose cited evidence is not on file is not an accepted result'*) and `23 21 16 cl. 3.3`, circuits **C3, C5, C6, and C7** are scheduled for a 2.0-hour (`120 min`) hydrostatic test (`HYDRO`) at `127.5 psig` (`1.5 x 85 psig`, within the `150 psig` temporary assembly rating) on Day 0 (`hours 0.0 to 8.0`, well before milestone `TM-1` at `hour 144`). Accepted circuits **C1, C2, C4, and C8** are not retested.

### 3.3 Reviewed and Rejected / Out-of-Scope Documents and Products
Per package instructions, rejected, superseded, cancelled, and out-of-scope documents are excluded from `constraint_register.csv` and recorded here:
- **`Water-Treatment Criteria 3-240-13FN (2005 cancelled) (2005, CANCELLED)`**: Cancelled predecessor to `Water-Treatment Criteria 3-230-13 (2023) (2023)`; prohibited by `23 25 16 cl. 1.2`.
- **`M-PID-103_Pcw_Cdu_Distribution_RevA_SUPERSEDED.dxf`**: Superseded by `M-PID-103 Rev C` (`M-601 Note 5`).
- **`SW-03 Revision A (2026-07-01)`**: Volume cap (`540,000 gal`) superseded by `SW-03 Rev B (2026-07-21)` (`500,000 gal`).
- **`Title 40 CFR Part 122 (NPDES Permit Programs)`**: Out of scope. Per `SW-03 General Condition 2` and `RFI-031`, all site sewer discharge is to a POTW (`MH-14`) regulated under `40 CFR 403`; surface-water discharge to Tull Creek or storm drains is strictly prohibited.
- **`Section 22-11-23 (Domestic Water Pumps)`**: Out of scope (`cl. 2.1 & 3.1` explicitly state domestic water piping is not part of the PCW system).
- **`Submittal VD_08 (Air-Cooled Chiller Submittal, ACC-1)`**: Out of scope (`Note 2` states `ACC-1` serves the administrative office comfort-cooling loop, not the data hall PCW loop).
- **`RFI_009 (Roof Curb Flashing at Fan-Wall Units)`**: Architectural roofing scope only; no mechanical or water-treatment content.
- **Rejected Chemical Products in `VD-06`**:
  - **`NB-700` (Nitrite-Borax-Azole blend)**: Rejected across all circuits because `SW-02` makeup water has `Chloride + Sulfate = 505 + 355 = 860 mg/L > 800 ppm`, violating `Water-Treatment Criteria 3-230-13 (2023) cl. 6-2.2.2` (`VD-06 Note 4`).
  - **`MO-500` (Sodium Molybdate) & `SA-100` (Soda Ash)**: Disqualified on `C6` (aluminium cold plates `CP-331` corrode above `pH 8.5`, `VD-04`) and `C8` (galvanized steel forms white rust above `pH 8.5`, `Water-Treatment Criteria 3-230-13 (2023) cl. 5-7.3.1`), and unselected on `C1-C5, C7` in favor of `PS-330` (`Polysilicate-Azole`), which is compatible with all circuit metallurgies (`Table 5-10`, `cl. 6-2.2.5`), requires no `SA-100` pH adjustment (`SW-02` pH `7.6` is inside `[7.5, 8.9]`), faces no local sewer limit on silica (`SW-03`), and minimizes total chemical cost.

---

## 4. Field Execution Narrative (Step-by-Step Procedure)

1. **Mobilisation, Pre-Checks & Ancillary Setup (`TM-0`, Hour 0)**:
   - Mobilise `CREW-1` and `CREW-2`, flush skids `FS-600-A` and `FS-600-B` (`hour 0`), and receive `FS-1200-A` at `hour 48` (`SI-05`). Verify calibration certificates (< 12 months old) for pressure gauges, flow meters, pH/conductivity meters, and thermometers (`CX-03 Item 2`).
   - Fit full-size temporary bypass spools (`M-602`, `CX-03 Item 1`) across `HX-201A` (C2), `HX-201B` (C3), `CDU-301` & `CP-311` (C4), `CDU-302` & `CP-321` (C5), `CP-331` (C6), and `CL-401` (C7). Leave `PMP-101` & `BT-101` (C1) and `ST-601` (C8) in the flushed path. Fit `40-mesh (380 micron)` stainless steel temporary basket strainers (`VD-05`, `CX-03 Item 3`) in each skid discharge.
   - Stage ancillary equipment required by `23 25 16 cl. 3.10f`: (a) positive-displacement hydrostatic test pump with calibrated chart recorder for `C3, C5, C6, C7`; (b) clean portable intermediate holding tank and transfer hose to hold cascaded final-rinse displacement water between tie-in locations (`MER-1`, `L3-S`, `MER-2`, `L3-N`, `YARD`, `L3-W`, `ROOF`); and (c) temporary `50-micron` slip-stream / inline cartridge polishing filter (`M-602` / `VD-04`) to polish circuit water below the `50-micron` cold-plate limit prior to removing bypass spools on `C4, C5, C6`.
2. **Hydrostatic Testing (`HYDRO`, Hours 0.0 to 8.0 <= `TM-1` Hour 144)**:
   - Fill `C3, C5, C6, C7` with construction makeup water (`V_f`), vent air at high-point vents (`AV-C3-01`, `AV-C5-01`, `AV-C6-01`, `AV-C7-01`), pressurize to **`127.5 psig`** (`1.5 x 85 psig`), and hold for **`120 minutes (2.0 h)`** with zero pressure loss and zero visible leakage, recording signed pressure charts `TR-0414`, `TR-0416`, `TR-0417`, and `TR-0418`. Drain test water (`V_f`) to `MH-14` (`SEWER`, `pH 7.6`, `68 degF`).
3. **Initial Flush (`INITIAL_FLUSH`)**:
   - Fill each circuit with `1.0 V_f` fresh makeup water and circulate/flush at the declared flow (`1,200 gpm` on C1; `800 gpm` on C2, C3; `480 gpm` on C5; `400 gpm` on C4, C6; `350 gpm` on C7; `200 gpm` on C8) verifying governing-segment velocity (`>= 4.0 ft/s` on C2–C6; `>= 3.28 ft/s` on C1, C7, C8; `CX-03 Item 4`). Drain `1.0 V_f` to `MH-14` (`SEWER`) and clean the `40-mesh` strainer basket (`VD-05 Note 2`).
4. **Chemical Cleaning (`CHEM_CLEAN`, Completed Hour 447.49 <= `TM-2` Hour 528)**:
   - Fill circuit with `1.0 V_f` makeup water and dose cleaner on `system_volume_gal (V_s)` plus `PD-45` polyacrylate dispersant at `4.0 ppm` active polymer (`Water-Treatment Criteria 3-230-13 (2023) cl. 5-3.7`): `CL-100` (`1.5 gal/1,000 gal V_s`) on `C1, C2, C3, C4, C5, C7`; `CL-210` (`2.0 gal/1,000 gal V_s`, maintaining `pH 7.5 to 8.5`) on `C6` (aluminium) and `C8` (galvanized steel).
   - Circulate continuously at the declared flushing flow for **`24.0 occupied hours`** (`Water-Treatment Criteria 3-230-13 (2023) cl. 5-7.3.2.2b`, `CX-03 Item 5`).
   - **Effluent Routing (`SW-03 Rev B` & `VD-06 Note 3`, `CX-03 Item 6`)**: Route spent cleaning solution from `C1, C2, C3` (carbon steel pipe only, `pH 8.4`, no detectable Cu or Zn) to `MH-14` (`SEWER`). Route spent cleaning solution from **`C4, C5, C6, C7`** (`Cu = 3.4 or 1.6 mg/L > 1.0 mg/L` local limit) and **`C8`** (`Zn = 5.5 mg/L > 1.0 mg/L` local limit) to vacuum tanker at the Yard pad (**`HAUL`**, `26,466.32 gal` total). Clean strainer baskets at drain.
5. **Drain & Rinse with Cascade (`DRAIN_RINSE`)**:
   - Flush each circuit with `n_r` full flush-volume (`V_f`) displacements (`6 passes` on C1, C2, C3, C8; `8 passes` on C4, C5, C6, C7). Execute the 7-step cascade chain `C1 -> C5 -> C3 -> C4 -> C8 -> C2 -> C6 -> C7`, transferring `1.0 V_f(receiver)` of verified final rinse water via the portable holding tank for the receiver's first displacement, and drawing the remaining `n_r - 1` displacements from the metered supply.
   - On the final displacement (leaving the circuit full), blend at least `15%` (`>= 14.2%`, up to `5,000 gal/day <= 5,230 gal/day` capacity of softener `SF-1`) from softened water outlet `SV-2` (`< 20 mg/L as CaCO3`, `C-101`) with construction makeup water (`288 mg/L`) so standing circuit hardness is `< 250 mg/L as CaCO3` (`Water-Treatment Criteria 3-230-13 (2023) Table 6-1`). Circulate for `30 minutes` (`Water-Treatment Criteria 3-230-13 (2023) cl. 5-7.3.2.2d`) and verify conductivity `<= 676.5 microS/cm`, `pH 7.5 to 7.9`, and clarity/TSS matching makeup (`CX-03 Item 7`).
6. **Passivation & Film-Formation Hold (`PASSIVATE` & `HOLD`, Completed Hour 785.74 <= `TM-3` Hour 1056)**:
   - Dose `PS-330` into the standing rinse water to `40.0 ppm as SiO2` (`Table 5-15`) on `V_s`, plus `TA-90` to `10.0 ppm as TTA` (`Table 5-14`) on copper-wetted circuits `C4, C5, C6, C7`. Verify pH inside `7.5 to 7.9` (`C4-C7` intersection) or `7.5 to 8.5` (`C1-C3, C8`). Circulate for `V_f / (60 Q) + 0.5 h` (`>= 30 min` recirculation before sampling), sample passivation residual (`CX-03 Item 8`), release skid and crew, and hold for **`14 days (336.0 occupied hours)`** (`Table 5-14 / 5-15`).
7. **Turnover (`FINAL_FILL`, `RETAIN_AND_TOP_UP`, Completed Hour 796.49 <= `TM-4` Hour 1128)**:
   - Polish circuit water through the `50-micron` cartridge filter before opening cold-plate manifolds (`CP-311, CP-321, CP-331`). Remove temporary bypass spools, retain the passivation charge (`RETAIN_AND_TOP_UP`), top up `V_s - V_f` with partially softened makeup water (`< 250 mg/L` hardness), and add the `PS-330` maintenance increment (`+40.0 ppm as SiO2` to reach **`80.0 ppm as SiO2`** across `V_s`, `Water-Treatment Criteria 3-230-13 (2023) cl. 6-2.2.5`) and `TA-90` (`10.0 ppm as TTA` on `C4-C7`).
   - Recirculate for `30 minutes (0.5 h)` after fill, verify `SiO2 >= 80.0 ppm`, `TTA >= 10.0 ppm` (`C4-C7`), `pH 7.5 to 8.9` (`7.5 to 8.5` on `C6, C8`), and `total aerobic bacteria <= 1,000 CFU/mL` (`Table 6-3`), remove all `40-mesh` temporary basket strainers (`VD-05`, `CX-03 Item 3`), and sign off `CX-03 Item 9`.

---

## 5. Chemical Handling Safety & Hazard Communication (`29 CFR 1910.1200` & `VD-07`)

In compliance with `29 CFR 1910.1200` (Hazard Communication Standard) and `VD-07` (`SDS Pack`, supplier Cascadia Water Technologies, emergency `1-800-555-0142`), the following chemical safety program is enforced at all tie-in handling points (`CX-03 Item 10`):

| Product Code | Chemical Name & Active Content | GHS Classification (`VD-07` Sec. 2) | Signal Word | Required PPE (`VD-07` Sec. 8) | First Aid & Emergency Facilities (`VD-07` Sec. 4) |
|---|---|---|---|---|---|
| **`CL-100`** | Alkaline pre-operational cleaner (22% active, pH 10.4) | `Skin Corr. 1B`, `Eye Dam. 1` | **DANGER** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |
| **`CL-210`** | Neutral-pH cleaner for Galv/Al (18% active, pH 8.2) | `Skin Corr. 1B`, `Eye Dam. 1` | **DANGER** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |
| **`PD-45`** | Polyacrylate dispersant (40% active polymer) | `Eye Irrit. 2A` | **WARNING** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |
| **`PS-330`** | Polysilicate liquid inhibitor (12% active SiO2) | `Eye Irrit. 2A` | **WARNING** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |
| **`TA-90`** | Tolyltriazole solution (50% active TTA) | `Eye Irrit. 2A` | **WARNING** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |
| **`MO-500`** | Sodium molybdate inhibitor (10% active Mo, not ordered) | `Eye Irrit. 2A` | **WARNING** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |
| **`NB-700`** | Nitrite-borax-azole blend (68% NO2, not ordered) | `Eye Irrit. 2A` | **WARNING** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |
| **`SA-100`** | Soda ash / Na2CO3 (99% active, not ordered) | `Skin Corr. 1B`, `Eye Dam. 1` | **DANGER** | Chemical splash goggles, full face shield, chemical-resistant gloves & apron | Flush eyes 15 min with water; emergency eyewash & quick-drench shower within **10 seconds** of handling point |

- **Written HazCom Program, Labeling & SDS Access (`29 CFR 1910.1200(e)-(g)`)**: Physical copies of the `VD-07` SDS pack and chemical inventory log are maintained at every active tie-in work zone (`MER-1`, `MER-2`, `L3-N`, `L3-S`, `L3-W`, `ROOF`, `YARD`). All primary pails/bottles and any secondary transfer containers carry legible GHS labels displaying product identifier, signal word, hazard statements, and pictograms.
- **Worker Training & Spill Containment (`29 CFR 1910.1200(h)`)**: Both commissioning crews (`CREW-1`, `CREW-2`) complete pre-task HazCom briefing prior to chemical handling. All dosing pumps and pails are staged inside secondary containment pallets with spill kits and verified `<= 10-second` unobstructed path to an ANSI-compliant emergency eyewash and quick-drench shower.
