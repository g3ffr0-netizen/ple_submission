# Building B — Delegated Lateral Design Basis

## 1. Seismic Force-Resisting System Selection

- **Selected SFRS:** **Bearing Wall System — Intermediate Precast Shear Walls** (`intermediate_precast`).
- **Design Format:** **Load and Resistance Factor Design (LRFD)** ($1.0E$ seismic load factor) applied consistently across all roof deck diaphragm zones, steel chords/collectors/drag struts, precast panel joint connectors, panel base tie-downs, foundation checks, and out-of-plane wall-to-diaphragm anchorages (`SDC-02` Rev 2 Section 9; `ASCE/SEI 7-22` Section 12.4).
- **Governing Code & Permitting Clauses:**
  - **2024 International Building Code (IBC)** as adopted by the State of Montana (**ARM 24.301.131**), **ASCE/SEI 7-22** (*Minimum Design Loads and Associated Criteria for Buildings and Other Structures*), **ACI 318-19** (*Building Code Requirements for Structural Concrete*), and **AISI S310** (*North American Standard for the Design of Profiled Steel Diaphragm Panels*) per `SDC-02` Rev 2 Section 1.
  - Under **Risk Category III** ($I_e = 1.25$) and **Site Class D** ($V_{s,100} = 905\text{ ft/s}$), the design spectral accelerations are $S_{DS} = 0.44\text{ g}$ and $S_{D1} = 0.24\text{ g}$, which assign Building B to **Seismic Design Category (SDC) D** per **ASCE 7-22 Section 11.6, Tables 11.6-1 and 11.6-2** (`SDC-02` Rev 2 Section 3).
  - Per **ASCE 7-22 Table 12.2-1 (Bearing Wall Systems)** and **UFC 3-301-01 Change 6 Table 3-1 (Footnote i)**, **Intermediate Precast Shear Walls** are permitted in **SDC D** up to a structural height limit of **$h_n \le 40\text{ ft}$** (`SDC-02` Rev 2 Section 4). Building B has a single-storey roof diaphragm height of **$h_n = 28.0\text{ ft} \le 40.0\text{ ft}$** (with a $3.0\text{ ft}$ cantilever parapet to $H = 31.0\text{ ft}$), satisfying the height limit with a $12.0\text{ ft}$ margin.
- **Design Coefficients & Factors (`ASCE 7-22` Table 12.2-1 / `UFC 3-301-01` Table 3-1):**
  - Response Modification Coefficient: **$R = 4.0$**
  - Basic System Overstrength Factor: **$\Omega_0 = 2.5$**
  - Collector & Drag-Strut Overstrength Factor: **$\Omega_{0,\text{collector}} = 2.0$** (reduced by $0.5$ from $2.5$ to $2.0$ for structures with flexible diaphragms per **ASCE 7-22 Table 12.2-1 Footnote b** and `SDC-02` Rev 2 Section 4)
  - Deflection Amplification Factor: **$C_d = 4.0$**
  - Approximate Fundamental Period: **$T_a = C_t h_n^x = 0.020 (28.0)^{0.75} = 0.2435\text{ s}$** (**ASCE 7-22 Section 12.8.2.1 Equation 12.8-8**)
  - Seismic Response Coefficient: **$C_s = \frac{S_{DS}}{R / I_e} = \frac{0.44}{4.0 / 1.25} = 0.1375$** (**ASCE 7-22 Section 12.8.1.1 Equation 12.8-2**, bounded by $C_{s,\min} = 0.044 S_{DS} I_e = 0.0242$ and $C_{s,\max} = \frac{S_{D1}}{T (R/I_e)} = 0.3079$)
  - Diaphragm Design Force Coefficient: **$F_{px} / w_{px} = C_s = 0.1375$** (**ASCE 7-22 Section 12.10.1.1 Equation 12.10-1**, within $0.2 S_{DS} I_e = 0.110$ minimum and $0.4 S_{DS} I_e = 0.220$ maximum)
- **Why `intermediate_precast` + `LRFD` Is the Cost-Efficient Choice:**
  - Selecting `intermediate_precast` carries an SFRS panel detailing premium of **$1,850/panel** ($79 \times \$1,850 = \$146,150$) and permits `JC1` (`RPC-24` welded shear plates at **$385/connector** per `RPC-CAT-2026` Rev 3 Section 2). By contrast, `special_precast` carries a **$4,120/panel** detailing premium ($79 \times \$4,120 = \$325,480$, an extra **$179,330** on panel detailing alone) and mandates `JC3` (`RPC-60D` ductile links at **$1,240/connector**), which would push the total installed cost above the **$395,000.00** capital budget cap (`PROC-114` Rev 2).
  - Selecting **LRFD** ($1.0E$, $\phi_{\text{deck}} = 0.60$, $\phi_{\text{conn}} = 0.75$) instead of **ASD** ($0.7E$, $\Omega_{\text{deck}} = 2.55$, $\Omega_{\text{conn}} = 2.00$) provides $7.1\%$ higher usable deck shear capacity ($0.60 / 1.0 = 0.600$ vs. $(1/2.55)/0.7 = 0.560$) and $5.0\%$ higher usable precast connector/anchor capacity ($0.75 / 1.0 = 0.750$ vs. $(1/2.0)/0.7 = 0.714$), enabling lighter deck fastening patterns and minimum-cost connection hardware.

---

## 2. Resolution of Document Conflicts

Every discrepancy across the project documents and archive files was identified and resolved in accordance with the authoritative project record (`T-2026-118`):

| Conflict Topic | Conflicting / Superseded Source | Governing Authoritative Source | Resolution Applied |
|---|---|---|---|
| **1. Occupancy Risk Category & Importance Factor ($I_e$)** | `A-101` Rev 3 code block note ("Risk Category II, $I_e = 1.0$"), `SM-2019-04` (Building A), and `USGS_ASCE7-22_RiskCatII_SiteClassD` JSON. | `OBD-CDDC-B` Section 1.4, `SDC-02` Rev 2 Section 2, and `USGS_ASCE7-22_RiskCatIII_SiteClassD_46.6832_-111.9756.json`. | **Risk Category III ($I_e = 1.25$)** governs per **ASCE 7-22 Section 11.5.1 & Table 1.5-2** because Building B houses a 911 emergency dispatch backup hall. |
| **2. Geotechnical Site Class & Ground Motion Standard** | `GEO-2019-118` (Parcel 4B 2019 Preliminary Report, Site Class C) and `USGS_ASCE7-16_RiskCatII_SiteClassC...PARCEL4B_2019_BASIS.json` ($S_{DS}=0.407$, SDC C). | `GEO-2026-071` Section 4 (Building B Geotech Report), `SDC-02` Rev 2 Section 3, and `USGS_ASCE7-22_RiskCatIII_SiteClassD_46.6832_-111.9756.json`. | **Site Class D** ($V_{s,100} = 905\text{ ft/s}$) and **ASCE 7-22** ground motions ($S_S=0.49\text{ g}, S_1=0.13\text{ g}, S_{DS}=0.44\text{ g}, S_{D1}=0.24\text{ g}$, **SDC D**) govern. |
| **3. As-Built Erected Wall & Pier Geometry vs. Design Drawings** | `PC-101` Rev 2 and `PC-301` Rev 2 detailed dimensions (South `D-3` = 14'-0" and `D-4`/`D-5` pier = 16'-0"; North `L-2` = 12'-0"; West `EY-1` = 40'-0"). | `RFI-041` EoR Response, `CDDC-SV-2026-041` Sections 3–4, `ERL-2026-08` Erection Log, `PCS-014` Shop Tickets (Rev B on `N-12`), `A-101` Rev 3 Note 6, and `ScanB_2026-08-07_interior.ply` (registered via `CP_control_points.csv` with RMSE $0.0079\text{ ft}$). | **As-built erected geometry** governs: South `D-3` = $15.5\text{ ft}$ ($78.0..93.5\text{ ft}$), shifting `S-P4` to $93.5..109.5\text{ ft}$ and closing `S-P5` between `D-4` and `D-5` to $14.5\text{ ft}$ ($123.5..138.0\text{ ft}$); North `L-2` (`N-SP2`) = $16.0\text{ ft}$ ($154.0..170.0\text{ ft}$); West `EY-1` = $44.0\text{ ft}$ ($66.0..110.0\text{ ft}$). |
| **4. Roof Plan Revision & Rooftop Unit (RTU) Schedule** | `90_archive/A-101_Building_B_Roof_Plan_REV1_SUPERSEDED.dxf` (4 RTUs totaling 33.0 kips; 16 psf roof dead load). | `A-101` Rev 3, `S-201` Rev 2 (18 psf roof dead load), `M-601` Rev 3 Equipment Schedule, and `OBD-CDDC-B` Section 2.2. | **18.0 psf** roof dead load ($705.60\text{ kips}$ over $39,200\text{ sq ft}$ net deck), **45.0 kips** Phase 1 RTUs (`RTU-1`..`RTU-6` in base cases `S01`–`S06`, `S11`–`S12`), plus **+16.0 kips** (`RTU-7F`, `RTU-8F` = $61.0\text{ kips}$ total in future cases `S07`–`S10`). |
| **5. Diaphragm Flexibility Idealisation** | `ASCE 7-22` Section 12.3.1.1 permissive flexible diaphragm clause vs. single-model assumption. | `PR-07` Peer Review Comment 7, `SDC-02` Rev 2 Section 10, and `DAP-2` Rev 1 Sections 6.2 & 6.3 (**ASCE 7-22 Section 12.3.1**). | Design forces (`wall_force_kips`, `diaphragm_unit_shear_plf`, segment and chord/collector forces) are the **envelope** across `flexible`, `rigid` ($10^7$ membrane stiffness), and `semi-rigid` models; deflections are taken from the `semi-rigid` model. |
| **6. Diaphragm Force Design Method** | Alternative diaphragm design provisions (**ASCE 7-22 Section 12.10.3**) or precast concrete diaphragm exception (**Section 12.10.4**). | `SDC-02` Rev 2 Section 5 (**ASCE 7-22 Sections 12.10.1 and 12.10.2**). | **ASCE 7-22 Sections 12.10.1 and 12.10.2** govern because Building B has a bare steel deck diaphragm on open-web steel joists (not a precast concrete diaphragm). |
| **7. Wind vs. Seismic Governing Lateral Load** | `90_archive/WM-2026-09_Wind_Load_Memorandum.pdf` (unfactored wind shears $49.7\text{ kips}$ N-S and $37.3\text{ kips}$ E-W). | `SDC-02` Rev 2 Section 8 and `WM-2026-09` conclusion. | **Seismic loads** ($F_{px,X} = 188.15\text{ kips}$, $F_{px,Y} = 216.47\text{ kips}$, $V = 301.41\text{ kips}$) exceed wind loads by more than $4\times$ and govern all lateral elements. |

---

## 3. Governing Checks by Wall Line (`S`, `N`, `W`, `E`)

All four exterior precast shear wall lines use **8 in normal-weight concrete panels** ($f'_c = 6,000\text{ psi}$, $E_c = 4,415.2\text{ ksi}$, $G_c = 1,839.7\text{ ksi}$, cracked $I = 0.50 I_g$ per **ACI 318-19 Table 6.6.3.1.1(a)**, cantilever height $h = 28.0\text{ ft} = 336\text{ in}$, parapet height $3.0\text{ ft}$ to $H = 31.0\text{ ft}$). Taking moments about the foundation (**FEMA P-2192-V1 Section 7.6.1 Step 1**; `SDC-02` Section 6), the tributary wall height to the roof diaphragm is $h_{\text{trib}} = \frac{31.0^2}{2 \times 28.0} = 17.1607\text{ ft}$ ($w_{\text{trib}} = 1,716.07\text{ plf}$, of which $316.07\text{ plf}$ is transferred by the cantilever parapet above the roof deck).

| Wall Line | As-Built Segments (`pier` / `spandrel`) | Total Wall Stiffness $K_{\text{wall}}$ (`JC1` $\times 1$) | Governing In-Plane Wall Force $F_x$ (`S01`–`S12` Envelope) | Max Vertical Joint Shear Demand vs. $\phi V_n$ (`JC1` $\times 1$) | Max Base Tie-Down Demand vs. $\phi T_n$ (`BA1`) | Out-of-Plane Wall Anchorage (`WA2` @ $10\text{ ft}$ o.c.) | Max Storey Drift $\Delta = \frac{C_d \delta_{\text{wall}}}{I_e}$ vs. $\Delta_a = 5.04\text{ in}$ |
|---|---|---|---|---|---|---|---|
| **South (`S`)** | 7 piers (`S-P1`: $18'$, `S-P2`: $16'$, `S-P3`: $16'$, `S-P4`: $16'$, `S-P5`: $14.5'$, `S-P6`: $44'$, `S-P7`: $40'$; 19 panels, 12 joints) | $3,245.4\text{ kip/in}$ | **$93.64\text{ kips}$** (`S07` & `S09`; $92.91\text{ kips}$ in `S01`/`S02`/`S05`) | **$2.82\text{ kips} \le 18.00\text{ kips}$** (15.7% util, `S-P6`/`S-P7`) | **$27.98\text{ kips} \le 57.00\text{ kips}$** (49.1% util, `S-P6`/`S-P7`; foundation $\le 180\text{ kips}$) | $F_p = 858.04\text{ plf}$ ($k_a = 2.0$); **$8.58\text{ kips} \le 9.60\text{ kips}$** (89.4% util) | **$0.092\text{ in} \le 5.04\text{ in}$** (1.8% util) |
| **North (`N`)** | 4 piers + 2 spandrels (`N-P1`: $24'$, `N-P2`: $32'$, `N-SP1`: $12'$, `N-P3`: $82'$, `N-SP2`: $16'$, `N-P4`: $70'$; 27 panels, 21 joints) | $5,034.3\text{ kip/in}$ | **$110.39\text{ kips}$** (`S02`; $104.87\text{ kips}$ in `S09`, $102.70\text{ kips}$ in `S01`) | **$2.15\text{ kips} \le 18.00\text{ kips}$** (11.9% util, `N-P3`) | **$21.27\text{ kips} \le 57.00\text{ kips}$** (37.3% util, `N-P2`/`N-P3`; foundation $\le 180\text{ kips}$) | $F_p = 858.04\text{ plf}$ ($k_a = 2.0$); **$8.58\text{ kips} \le 9.60\text{ kips}$** (89.4% util) | **$0.070\text{ in} \le 5.04\text{ in}$** (1.4% util) |
| **West (`W`)** | 3 piers (`W-P1`: $12'$, `W-P2`: $50'$, `W-P3`: $70'$; 14 panels, 11 joints) | $3,014.6\text{ kip/in}$ | **$111.47\text{ kips}$** (`S04`; $108.10\text{ kips}$ in `S08`/`S10`, $107.82\text{ kips}$ in `S03`) | **$3.61\text{ kips} \le 18.00\text{ kips}$** (20.1% util, `W-P2`/`W-P3`) | **$35.86\text{ kips} \le 57.00\text{ kips}$** (62.9% util, `W-P2`/`W-P3`; foundation $\le 180\text{ kips}$) | $F_p = 858.04\text{ plf}$ ($k_a = 2.0$); **$8.58\text{ kips} \le 9.60\text{ kips}$** (89.4% util) | **$0.118\text{ in} \le 5.04\text{ in}$** (2.3% util) |
| **East (`E`)** | 4 piers + 1 spandrel (`E-P1`: $72'$, `E-P2`: $22'$, `E-SP1`: $12'$, `E-P3`: $30'$, `E-P4`: $26'$; 19 panels, 14 joints) | $3,439.4\text{ kip/in}$ | **$123.29\text{ kips}$** (`S10`; $121.61\text{ kips}$ in `S06`, $117.80\text{ kips}$ in `S03`) | **$3.52\text{ kips} \le 18.00\text{ kips}$** (19.5% util, `E-P2`) | **$34.78\text{ kips} \le 57.00\text{ kips}$** (61.0% util, `E-P3`; foundation $\le 180\text{ kips}$) | $F_p = 858.04\text{ plf}$ ($k_a = 2.0$); **$8.58\text{ kips} \le 9.60\text{ kips}$** (89.4% util) | **$0.115\text{ in} \le 5.04\text{ in}$** (2.3% util) |

- **Roof Diaphragm Deflection & Panel Out-of-Plane Top Deflection Check (`SDC-02` Section 7; `OBD-CDDC-B` Section 3.1; `ASCE 7-22` Section 12.12.2):**
  - Across all 12 design load cases (`S01`–`S12`) and all held-out sign/mass/orthogonal permutations in the `semi-rigid` finite element model (`DAP-2` Section 6.2), the maximum unamplified roof + wall deflection is $\delta_{\text{top}} = 0.774\text{ in}$ (occurring under Y-direction loading with future RTUs), giving a maximum amplified panel-top deflection of:
    $$\Delta_{\text{top}} = \frac{C_d (\delta_{\text{diaphragm}} + \delta_{\text{wall}})}{I_e} = \frac{4.0 \times 0.774\text{ in}}{1.25} = 2.476\text{ in} \le 4.000\text{ in} \quad (\text{61.9\% utilization})$$
- **Subdiaphragm Proportions (`SDC-02` Section 6; `ASCE 7-22` Section 12.11.2.2.1):**
  - Each wall line uses subdiaphragms spanning $60.0\text{ ft}$ between primary roof girders (`Grid 1–2–3–4–5` / $60\text{ ft}$ bay module on `S-201` Rev 2) with a depth of $30.0\text{ ft}$, giving a span-to-depth ratio of **$60.0 / 30.0 = 2.0 : 1 \le 2.5 : 1$**.
- **Temporary Erection Bracing (`ERC-07` Rev 1 Sections 2–4; `29 CFR 1926.704(a)`):**
  - Temporary adjustable pipe braces are specified at **$12.0\text{ kip}$ capacity** (`brace_capacity_kip = 12.0 >= 12.0`) at **$20.0\text{ ft}$ maximum spacing** (`brace_spacing_ft = 20.0 <= 20.0`, two braces per $10\text{ ft}$ nominal panel). Under construction-stage seismic load cases `S11` and `S12` ($0.5\times$ design seismic load per **ASCE/SEI 37-14** with roof deck east of $X = 180\text{ ft}$ unfastened), the active diaphragm zones (`Z1`–`Z3`, `Z5`–`Z7`, `Z9`–`Z11`) and active shear walls (`S`, `N`, `W`) safely carry all construction-stage shears and torsional moments ($A_x = 1.296$ in `S11` and $A_x = 2.778$ in `S12`).

---

## 4. Rejected Alternatives

1. **Ordinary Precast Shear Walls (`ordinary_precast`) — Rejected (Code Violation):**
   - Prohibited (**Not Permitted, NP**) in **Seismic Design Category D** per **ASCE 7-22 Table 12.2-1** and **UFC 3-301-01 Change 6 Table 3-1** (`SDC-02` Section 4).
2. **Special Precast Shear Walls (`special_precast`) — Rejected (Excessive Cost / Budget Cap Violation):**
   - While permitted in SDC D ($R = 5, \Omega_0 = 2.5, C_d = 5$), `special_precast` requires `JC3` (`RPC-60D` ductile links at **$1,240/connector** per `RPC-CAT-2026` Section 2) and carries a **$4,120/panel** SFRS detailing premium (`PROC-114` Rev 2). Even with 1 connector per joint ($58 \times \$1,240 = \$71,920$) and 79 panels ($79 \times \$4,120 = \$325,480$), the panel detailing and joint connectors alone cost **$397,400**, exceeding the **$395,000** total lateral budget cap before adding base anchors, wall anchors, chords, or deck attachment.
3. **Isolated Uncoupled Piers (`JC0`) — Rejected (Non-Qualified Connector in SDC D):**
   - Per `RPC-CAT-2026` Rev 3 Section 2, `JC0` (*None — isolated piers*) is qualified only for **Ordinary Precast** shear walls and is not qualified for **Intermediate Precast** shear walls in SDC D.
4. **Heavier Joint Connectors (`JC2`), Multiple Connectors per Joint ($n \ge 2$), or Heavier Base Anchors (`BA2`, `BA3`) — Rejected (Unnecessary Cost):**
   - `JC1` (`RPC-24`, $\phi V_n = 18.0\text{ kips}$) at 1 connector per joint and `BA1` (`RPC-TD1`, $\phi T_n = 57.0\text{ kips}$) at 2 per panel satisfy all Stage A joint shear demands ($\le 3.61\text{ kips}$) and base tie-down demands ($\le 35.86\text{ kips}$) with generous margins. Upgrading to `JC2` or `BA2` would add $13,050 to $61,620 in unnecessary hardware cost.
5. **Heavier Chord/Collector Sections (`C2`, `C3`, `C4`) or Omitting Required Drag Struts (`C0`) — Rejected:**
   - All 20 lines in `collector_lines` are required by `SDC-02` Section 5 (4 perimeter chords, 8 opening chords around `RO-1` and `RO-2`, and 8 drag struts across wall openings $\ge 12\text{ ft}$ on `S`, `N`, `W`, `E`), so setting any line to `C0` would violate continuity requirements. `C1` (`L4x4x3/8`, $\phi P_n = 92.66\text{ kips}$, $\$11.40/\text{lf}$) satisfies the maximum amplified collector demand ($54.50\text{ kips}$ across the $44\text{ ft}$ `EY-1` opening on `DR-W1` / `DR-W2` with $\Omega_0 = 2.0$) with a $41.2\%$ safety margin ($58.8\%$ utilization), whereas `C2` (`L6x4x1/2`) would add $\$15,600$ for no structural benefit.
6. **Wall Anchors `WA1` @ 4 ft o.c. or `WA3` — Rejected:**
   - Out-of-plane anchorage force is $F_p = 858.04\text{ plf}$. `WA1` ($\phi T_n = 4.80\text{ kips}$) fails at $6, 8, 10\text{ ft}$ spacing and at $4\text{ ft}$ spacing costs $\$96 / 4' = \$24.00/\text{lf}$ ($\$20,160$ total). `WA2` (`RPC-A12`, $\phi T_n = 9.60\text{ kips}$) at $10\text{ ft}$ spacing carries $8.58\text{ kips} \le 9.60\text{ kips}$ at $\$172 / 10' = \$17.20/\text{lf}$ ($\$14,448$ total), saving **$5,712**.
7. **Allowable Stress Design (`ASD`) Format — Rejected:**
   - `ASD` reduces usable deck shear capacity by $7.1\%$ and usable precast connector/anchor capacity by $5.0\%$ relative to `LRFD`, which would force deck zone upgrades costing over $\$4,500$.

---

## 5. Installed Cost Against the Budget

Per `PROC-114` Rev 2 (*Lateral Scope Cost Plan*), `OBD-CDDC-B` Section 5.6, and `SDC-02` Rev 2 Section 11, the total installed cost of the delegated lateral scope is **$349,318.40**, which is **$45,681.60 (11.6%) below** the hard capital budget cap of **$395,000.00**:

| Scope Category | Selected Item(s) | Quantity Basis | Unit Rate | Subtotal (USD) |
|---|---|---|---|---|
| **1. Precast SFRS Detailing Premium** | `intermediate_precast` | 79 as-built panels (`S`: 19, `N`: 27, `W`: 14, `E`: 19) | $\$1,850.00 / \text{panel}$ | $\$146,150.00$ |
| **2. Roof Deck Diaphragm Attachment** | `P4` (`Z1, Z4, Z9, Z12`: $13,920\text{ sf}$)<br>`P3` (`Z5, Z8, Z10, Z11`: $12,720\text{ sf}$)<br>`P2` (`Z2, Z3, Z6, Z7`: $12,560\text{ sf}$) | $39,200\text{ sq ft}$ total net deck area ($43,200 - 2,400 - 1,600$) | `P4`: $\$1.93 / \text{sf}$<br>`P3`: $\$1.52 / \text{sf}$<br>`P2`: $\$1.14 / \text{sf}$ | $\$26,865.60$<br>$\$19,334.40$<br>$\$14,318.40$<br>**$\$60,518.40$** |
| **3. Chords, Collectors & Drag Struts** | `C1` (`L4x4x3/8`) on all 20 lines (`CH-*`, `DR-*`, `OP-*`) | $2,080\text{ lf}$ ($840'\text{ CH} + 840'\text{ DR} + 400'\text{ OP}$) | $\$11.40 / \text{lf}$ | $\$23,712.00$ |
| **4. Panel Vertical Joint Connectors** | `JC1` (`RPC-24` welded shear plate), $1 / \text{joint}$ | 58 vertical joints (`S`: 12, `N`: 21, `W`: 11, `E`: 14) $\times 1$ | $\$385.00 / \text{conn}$ | $\$22,330.00$ |
| **5. Panel Base Tie-Down Anchors** | `BA1` (`RPC-TD1` 1 in Gr 75 rod), $2 / \text{panel}$ | 79 panels $\times 2 = 158$ tie-downs | $\$520.00 / \text{tie-down}$ | $\$82,160.00$ |
| **6. Out-of-Plane Wall-to-Diaphragm Anchors** | `WA2` (`RPC-A12` threaded rod + angle) @ $10\text{ ft}$ o.c. | $840\text{ lf}$ perimeter / $10\text{ ft} = 84$ anchors | $\$172.00 / \text{anchor}$ | $\$14,448.00$ |
| **Total Installed Cost (As-Built 79-Panel Basis)** | | | | **$349,318.40** |
| *(Note: Shop-Ticket 81-Panel / 60-Joint Basis)* | *(If evaluated on 81 shop tickets / 60 joints)* | *(+2 panels, +4 `BA1`, +2 `JC1`)* | | *($355,868.40)* |
| **Capital Budget Cap (`PROC-114` Rev 2)** | | | | **$395,000.00** |
| **Positive Budget Margin** | | | | **+$45,681.60 (+11.6%)** |
