# Design Basis: EOR Review Corrections (Work Order 74213, BP-2 and BP-3)

```json
{
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": 2,
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 4,
      "production_days": 17,
      "delay_days": 0,
      "backcheck_window_days": 15,
      "ledger": {
        "bundles_usd": 2200,
        "sheets_usd": 19047.46,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 3120,
        "overflow_option_usd": 1760,
        "non_concurrence_usd": 2400,
        "delay_usd": 0,
        "total_usd": 41327.46
      },
      "title_block_defects": [
        {
          "sheet": "S-301",
          "defect": "CHK_EQUALS_DRW"
        },
        {
          "sheet": "E-501",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        }
      ]
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": "NONE",
      "revision_layers": [],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 0,
      "backcheck_window_days": 30,
      "ledger": {
        "bundles_usd": 1650,
        "sheets_usd": 20578.7,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 0,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 2400,
        "delay_usd": 0,
        "total_usd": 37428.7
      },
      "title_block_defects": [
        {
          "sheet": "A-501",
          "defect": "CHK_EQUALS_DES"
        },
        {
          "sheet": "M-101",
          "defect": "SEAL_DISCIPLINE_MISMATCH"
        }
      ]
    }
  },
  "governing_standards": [
    "FC 1-300-09N Navy and Marine Corps Design Procedures (17 May 2024, Change 1, 17 April 2025)",
    "ERDC/ITL SR-24-3 A/E/C Computer-Aided Design (CAD) Standard, Release 6.2 (September 2024)",
    "ERDC/ITL SR-23-1 A/E/C Graphics Standard, Release 2.2 (August 2023)",
    "ER 1165-2-217 Civil Works Review Policy (1 May 2021) - adopted by Contracting Officer memorandum for EOR design review policy",
    "ERDC/ITL SR-21-6 Record Package Guidance: Best Practices (July 2021) - adopted by Contracting Officer memorandum for markup and comment conventions",
    "ER 415-1-11 Biddability, Constructability, Operability, Environmental and Sustainability (BCOES) Reviews (1 January 2013)",
    "48 CFR Part 36 and FAR 52.236-25 Requirements for Registration of Designers"
  ],
  "rejected_standards": [
    "UFC 1-300-09N Design Procedures with Change 7 (25 May 2005, Change 7, 13 March 2009) - Cancelled and replaced by FC 1-300-09N",
    "ERDC/ITL TR-12-6 A/E/C CAD Standard, Release 6.0 (August 2012) - Superseded by Release 6.2 (ERDC/ITL SR-24-3)",
    "GSA PBS CAD Standards (October 2021) - Another agency standard (General Services Administration Public Buildings Service) not applicable to NAVFAC",
    "ER 1110-1-8159 Engineering and Design: DrChecks (10 May 2001) - Unadopted Civil Works regulation excluded by Contracting Officer memorandum"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4,
    "days_per_bundle": 3
  },
  "void_markups": [
    {
      "comment_id": "EOR-2-017",
      "reason": "Markup author G. Halvorsen is not listed on the authorized EOR reviewer roster for this project."
    },
    {
      "comment_id": "EOR-2-019",
      "reason": "Markup annotation on sheet S-501 lacks a required creation and modification timestamp."
    },
    {
      "comment_id": "EOR-2-021",
      "reason": "Markup was placed on the superseded 90 percent submittal sheet rather than the current issue of S-102."
    },
    {
      "comment_id": "EOR-2-027",
      "reason": "Markup author K. Aoyama is an unregistered construction representative not qualified to direct engineering review changes under FAR 52.236-25."
    },
    {
      "comment_id": "EOR-2-033",
      "reason": "Comment was already closed and elevated for resolution in the 60 percent review on 2026-03-27 without being reopened."
    },
    {
      "comment_id": "EOR-3-012",
      "reason": "Markup was placed on the superseded 60 percent submittal sheet rather than the current issue of T-501."
    },
    {
      "comment_id": "EOR-3-020",
      "reason": "Markup annotation on sheet S-501 lacks a required creation and modification timestamp."
    },
    {
      "comment_id": "EOR-3-022",
      "reason": "Markup author C. Ballantyne is not listed on the authorized EOR reviewer roster for this project."
    },
    {
      "comment_id": "EOR-3-036",
      "reason": "Comment was already closed and elevated for resolution in the 60 percent review on 2026-03-27 without being reopened."
    }
  ]
}
```

## (a) Resolution of Revision-Graphics Layer Conflict

An apparent conflict exists in the corpus regarding the CAD layer assignments for revision clouds and revision indicator symbols:
1. For post-construction record documents, **FC 1-300-09N** Paragraph `12-3.6.1` (*Record Drawing Preparation*, page 102) and the reference record prints from the terminated FY23 contract (`project/drawings/record_fy23/55210_FY23CUP_M-501_RECORD.pdf` and `55210_FY23CUP_S-501_RECORD.pdf`), as well as Figure 8 in **ERDC/ITL SR-21-6** (Section `3.3`, page 17), place record revision clouds and symbols on layers `Z-ANNO-REVC` and `Z-ANNO-REVS`.
2. In contrast, for contract design drawings and government-issued modifications, **ERDC/ITL SR-24-3** (*A/E/C CAD Standard, Release 6.2*), Section `2.4.1` and Appendix A (Table A3, *General Layer List*, page A3 / PDF page 50), and **ERDC/ITL SR-21-6** Section `3.1` (page 12), define **`G-ANNO-REVC`** (*Revision clouds*) and **`G-ANNO-REVS`** (*Revision symbols*) as the standard General annotation layers for drawing revisions.
3. The order of precedence that settles this conflict is fixed by **FC 1-300-09N** (*Navy and Marine Corps Design Procedures*, Change 1), Paragraph `12-3.3.4` (*CAD Standards*, page 95), together with Paragraph `7` of the Contracting Officer Memorandum dated `2026-08-26`. Specifically, `FC 1-300-09N` Paragraph `12-3.3.4` establishes the CAD standards order of precedence as the requirements of Chapter 12 (where pre-award Contract Drawings under Paragraph `12-3.3.2.2` are distinct from post-construction Record Drawings under Paragraph `12-3.6.1`), followed by the latest versions of the DoD *A/E/C CAD Standard* (`ERDC/ITL SR-24-3`, Release 6.2) and *A/E/C Graphics Standard* (`ERDC/ITL SR-23-1`, Release 2.2), and then the National CAD Standard. In addition, Paragraph `7` of the Contracting Officer Memorandum explicitly states that no record-package deliverable requirement applies to this work order.
4. Accordingly, for **BP-2** (`issue_state = "AMENDMENT"`), revision clouds and revision delta symbols are placed on **`["G-ANNO-REVC", "G-ANNO-REVS"]`** per `ERDC/ITL SR-24-3` Appendix A (Table A3) and `ERDC/ITL SR-21-6` Section `3.1`. For **BP-3** (`issue_state = "PRE_ADVERTISEMENT_REISSUE"`), corrections are incorporated into the design prior to solicitation advertisement without revision clouds or delta marks (`ERDC/ITL SR-23-1` Section `7.2` and Section `7.3`), so `revision_layers` is `[]`.

## (b) BP-3 Issue State and Backcheck Window Decision

1. **Controlling Schedule Dates:** Under the earlier schedule export (`project/contract/solicitation_schedule.csv`), BP-3 (`N40085-26-R-3018`) was certified on `2026-08-24` with an advertisement date of `2026-10-19` and a bid-opening date of `2026-12-14`. However, Paragraph `3` of the later Contracting Officer Memorandum (`2026-08-26`) sets the scheduled advertisement date for BP-3 at **`2026-11-09`**, which controls over the earlier schedule export. Production starts on **`2026-08-31`** (CO Memorandum Paragraph `5`), giving **70 calendar days** from `2026-08-31` to the controlling advertisement date (`2026-11-09`) and **105 calendar days** to the bid-opening date (`2026-12-14`).
2. **Applicable Review Regulation Windows:** In **ER 415-1-11** (*BCOES Reviews*), Paragraph `6.e.` (specifically sub-items `(2)` and `(4)` on page 4) and Paragraph `g.` (on page 5), as well as **ER 1165-2-217** Paragraphs `3.5.1.1` and `5.11.1`, specify two distinct window durations depending on the issue state:
   - **Pre-advertisement window (`30 calendar days`):** Under `ER 415-1-11` Paragraph `6.e.` sub-item `(2)` and Paragraph `g.` (and `ER 1165-2-217` Paragraph `3.5.1.1`), when comments are incorporated into the solicitation documents prior to advertisement (`PRE_ADVERTISEMENT_REISSUE`), the final review and backcheck window is **30 calendar days prior to advertisement** (`backcheck_window_days = 30`).
   - **Post-advertisement / pre-bid-opening backcheck window (`15 calendar days`):** Under `ER 415-1-11` Paragraph `6.e.` sub-item `(4)` and Paragraph `g.`, once a solicitation has been advertised (`AMENDMENT`), all comments must be resolved prior to bid opening with **15 calendar days** allowed for backchecking of comments (`backcheck_window_days = 15`; or `14` calendar days under `ER 1165-2-217` Paragraph `5.11.1`).
3. **Why `PRE_ADVERTISEMENT_REISSUE` and the 30-Day Window Bind for BP-3:** For BP-3, production of the 16 sheets (14 replacement sheets and 2 added sheets across 3 discipline-complete PDF bundles) plus 1 documented non-concurrence (`EOR-3-030`) requires `ceil(16 / 4) + 3 x 3 + 1 x 1 = 14` calendar days (finishing production on `2026-09-14`). Adding the **30-calendar-day** pre-advertisement window requires `14 + 30 = 44` calendar days from `2026-08-31` (completing on `2026-10-14`), which finishes 26 calendar days ahead of the controlling `2026-11-09` advertisement date (`delay_days = 0`, `delay_usd = $0`). Issuing BP-3 as `PRE_ADVERTISEMENT_REISSUE` rather than `AMENDMENT` avoids revision clouds and marks on all 14 revised sheets (`14 x $240 = $3,360` saved) and avoids Revision (Issue) block overflow charges on sheets `A-001`, `A-101`, and `A-301` (`$1,560` under Option 1 or `$1,760` under Option 2 saved), reducing total cost to the Government by at least **$4,920** while incurring zero schedule delay. For BP-2 (already advertised on `2026-07-06`, bid opening `2026-10-08`, 38 calendar days after `2026-08-31`), `AMENDMENT` is the only lawful state, and applying the **15-calendar-day** post-advertisement backcheck window gives `17 + 15 = 32 <= 38` calendar days (`delay_days = 0`).

## (c) BP-2 Revision (Issue) Block Overflow Decision

1. **Row Capacity and Set-Wide Application:** Under **ERDC/ITL SR-23-1** (*A/E/C Graphics Standard, Release 2.2*), Section `2.1.8` (page 12 / PDF page 24) and Section `7.3` (pages 77-78 / PDF pages 85-86), the Revision (Issue) block contains **8 rows** (`ROW_POSITION` 1 at the bottom to `ROW_POSITION` 8 at the top). When a 9th revision entry is added to a sheet whose 8 rows are already full, `ERDC/ITL SR-23-1` Section `7.3` provides two overflow options (illustrated in Figure `7-3` and Figure `7-4`) that must be applied **set-wide** across the entire drawing package rather than mixed sheet-by-sheet:
   - **Option 1 (Replace Oldest Entry):** Maintain a rolling 8-row block by displacing the oldest revision entry (`ROW_POSITION` 1) outside the plotted border for historical record (`$520` per revised sheet whose Revision block is already full, per `production_rate_schedule.xlsx`).
   - **Option 2 (Spill Above Revision Block):** Extend the Revision (Issue) block upward into the adjacent Drawing Area (`$880` per revised sheet whose Revision block is already full **and** which carries 3 or more drawing blocks; `$0` if the sheet carries fewer than 3 drawing blocks because the spill area is unoccupied, per `production_rate_schedule.xlsx`).
2. **Cost Comparison and Why Option 2 Was Selected over Option 1:** In BP-2, exactly **6** of the 13 revised existing sheets already have all 8 rows of their Revision (Issue) block filled (`A` through `F`, `1`, and `2`): `C-101` (1 drawing block), `S-101` (1 drawing block), `S-102` (1 drawing block), `S-502` (4 drawing blocks), `M-101` (1 drawing block), and `M-501` (3 drawing blocks).
   - Under **Option 1** applied set-wide, all 6 overflowed sheets incur the `$520` charge: `6 x $520 = $3,120`.
   - Under **Option 2** applied set-wide, only the **2** overflowed sheets carrying 3 or more drawing blocks (`M-501` with 3 views and `S-502` with 4 views) incur the `$880` re-layout charge, while the 4 single-view plan sheets (`C-101`, `S-101`, `S-102`, `M-101`) have an unoccupied spill zone and cost `$0`: `2 x $880 + 4 x $0 = $1,760`.
   - Therefore, **Overflow Option 2 (`overflow_option = 2`)** was selected set-wide for BP-2 and Option 1 was rejected because Option 2 saves the Government **$1,360** (`$1,760` vs. `$3,120`).

---

## Scope Exclusions
The following reference and out-of-scope materials in the project corpus are explicitly excluded from the EOR review disposition register, sheet re-issue set, and constraint register:
- `project/review/other_discipline/fire_protection_comment_log_BP-2.csv (Fire Protection review comments are for reference/coordination only and excluded from EOR disposition_register.csv and constraint_register.xlsx)`
- `project/drawings/superseded/ (Superseded 60% and 90% submittal prints; markups placed on superseded sheets rather than current issue are VOID)`
- `project/drawings/record_prints_prior_contract/ (Record prints from an earlier contract)` (filed under `project/drawings/record_fy23/`)

