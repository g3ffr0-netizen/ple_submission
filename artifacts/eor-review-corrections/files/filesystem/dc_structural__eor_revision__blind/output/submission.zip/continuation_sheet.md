# CONTINUATION SHEET - AMENDMENT 0003 AND CHANGE DOCUMENTATION

## Package BP-2: Central Utility Plant and Site Utilities
**Solicitation No.:** N40085-26-R-2041  
**eProjects Work Order No.:** 74213  
**Project Title:** Fleet Data Center Increment 2, Central Utility Plant and Site Utilities  
**Location:** Naval Support Activity Ventura Bay, California  
**Amendment No.:** 0003  

### CONTINUATION SHEET - AMENDMENT 0003

**DRAWINGS:**

On NAVFAC Drawing No. 74213-GI001 (GI-001) and in specification **00 01 15 LIST OF DRAWINGS**:

**ADD** the following drawings to the **DRAWING INDEX** (GI-001) and to specification **00 01 15 LIST OF DRAWINGS** under the corresponding discipline and drawing number. These drawings accompany this Amendment 0003:
- `S-202` (NAVFAC DWG No. `74213-S202`) `BRACED BAY FRAMING ELEVATIONS` - ADDED SHEET (accompanies Bundle `74213Amend0003dwg2of4.pdf`)
- `M-503` (NAVFAC DWG No. `74213-M503`) `CHILLER PAD ANCHORAGE DETAILS` - ADDED SHEET (accompanies Bundle `74213Amend0003dwg3of4.pdf`)

**REPLACE** the following drawings in the **DRAWING INDEX** (GI-001) and in specification **00 01 15 LIST OF DRAWINGS** under the corresponding discipline and drawing number. These drawings accompany this Amendment 0003:
- `C-101` (NAVFAC DWG No. `74213-C101`) `SITE UTILITY PLAN` - REPLACED SHEET (Bundle `74213Amend0003dwg1of4.pdf`)
- `S-101` (NAVFAC DWG No. `74213-S101`) `FOUNDATION PLAN` - REPLACED SHEET (Bundle `74213Amend0003dwg2of4.pdf`)
- `S-102` (NAVFAC DWG No. `74213-S102`) `ROOF FRAMING PLAN` - REPLACED SHEET (Bundle `74213Amend0003dwg2of4.pdf`)
- `S-301` (NAVFAC DWG No. `74213-S301`) `BUILDING SECTIONS` - REPLACED SHEET (Bundle `74213Amend0003dwg2of4.pdf`)
- `S-502` (NAVFAC DWG No. `74213-S502`) `STRUCTURAL DETAILS - FRAMING AND ANCHORAGE` - REPLACED SHEET (Bundle `74213Amend0003dwg2of4.pdf`)
- `M-101` (NAVFAC DWG No. `74213-M101`) `CHILLED WATER PLAN` - REPLACED SHEET (Bundle `74213Amend0003dwg3of4.pdf`)
- `M-301` (NAVFAC DWG No. `74213-M301`) `CENTRAL PLANT SECTIONS` - REPLACED SHEET (Bundle `74213Amend0003dwg3of4.pdf`)
- `M-401` (NAVFAC DWG No. `74213-M401`) `CHILLER BAY ENLARGED PLAN` - REPLACED SHEET (Bundle `74213Amend0003dwg3of4.pdf`)
- `M-501` (NAVFAC DWG No. `74213-M501`) `MECHANICAL DETAILS - PIPING` - REPLACED SHEET (Bundle `74213Amend0003dwg3of4.pdf`)
- `M-502` (NAVFAC DWG No. `74213-M502`) `MECHANICAL DETAILS - EQUIPMENT` - REPLACED SHEET (Bundle `74213Amend0003dwg3of4.pdf`)
- `E-001` (NAVFAC DWG No. `74213-E001`) `ELECTRICAL PANEL SCHEDULES` - REPLACED SHEET (Bundle `74213Amend0003dwg4of4.pdf`)
- `E-101` (NAVFAC DWG No. `74213-E101`) `POWER PLAN` - REPLACED SHEET (Bundle `74213Amend0003dwg4of4.pdf`)
- `E-501` (NAVFAC DWG No. `74213-E501`) `ELECTRICAL DETAILS` - REPLACED SHEET (Bundle `74213Amend0003dwg4of4.pdf`)

**SUMMARY OF DRAWING REVISIONS INCORPORATED BY REPLACEMENT AND ADDED SHEETS:**
- **On NAVFAC Drawing No. 74213-C101 (`C-101`):** View `1 / SITE UTILITY PLAN`, shifted fire water main alignment north and revised crossing callout to provide 10-foot horizontal separation from primary electrical duct bank (`EOR-2-009`).
- **On NAVFAC Drawing No. 74213-S101 (`S-101`):** View `1 / FOUNDATION PLAN`, revised column base anchor rod embedment callout from 12 inches to 18 inches (`EOR-2-001`) and added elevation callout to new sheet `S-202` (`EOR-2-025`).
- **On NAVFAC Drawing No. 74213-S202 (`S-202`):** Added structural elevations sheet carrying braced bay framing elevations (`EOR-2-025`).
- **On NAVFAC Drawing No. 74213-S502 (`S-502`):** View `A / EQUIPMENT ANCHORAGE DETAIL`, deleted cast-in headed anchor detail and replaced with post-installed adhesive anchor system (`EOR-2-004`); re-issued referencing sheets `S-102`, `S-301`, `M-101`, `M-401`, `M-501`, `M-502`, `E-101`, and `E-501`.
- **On NAVFAC Drawing No. 74213-M101 (`M-101`):** View `1 / CHILLED WATER PLAN`, revised chilled water supply main callout from 10-inch to 12-inch (`EOR-2-006`) and updated cross-references (`EOR-2-004`, `EOR-2-015`, `EOR-2-023`).
- **On NAVFAC Drawing No. 74213-M301 (`M-301`):** View `1 / PLANT SECTION A`, lowered chilled water supply header by 10 inches to clear bridge crane hook envelope (`EOR-2-015`); View `2 / PLANT SECTION B`, added phantom outline of future fourth chiller (`EOR-2-031`).
- **On NAVFAC Drawing No. 74213-M401 (`M-401`):** View `1 / CHILLER BAY ENLARGED PLAN`, added detail callout to new sheet `M-503` (`EOR-2-023`) and updated anchorage cross-references (`EOR-2-004`).
- **On NAVFAC Drawing No. 74213-M503 (`M-503`):** Added mechanical details sheet carrying chiller pad anchorage details (`EOR-2-023`).
- **On NAVFAC Drawing No. 74213-E001 (`E-001`):** View `1 / PANEL SCHEDULES`, reordered panel schedule columns so circuit breaker trip precedes pole count (`EOR-2-013`).
- **On NAVFAC Drawing No. 74213-E101 (`E-101`):** View `1 / POWER PLAN`, aligned feeder tag leaders vertically along the ductbank run (`EOR-2-029`) and updated cross-references (`EOR-2-004`, `EOR-2-023`).

--End of Amendment 0003--

---

## Package BP-3: Data Hall 210 Shell and Interiors
**Solicitation No.:** N40085-26-R-3018  
**eProjects Work Order No.:** 74213  
**Issue State:** `PRE_ADVERTISEMENT_REISSUE`  

**Statement:** The EOR review corrections for Package BP-3 (Solicitation No. `N40085-26-R-3018`) are incorporated directly into the certified design package prior to solicitation advertisement (scheduled for `2026-11-09`). Because the corrections are not issued as an amendment to an advertised solicitation, no amendment change number is assigned and no SF 30 continuation sheet is issued for BP-3. The Drawing Index (`GI-001`) and specification `00 01 15 LIST OF DRAWINGS` are updated in the pre-advertisement design set to include added sheets `A-402` and `M-502` and replacement sheets `S-101`, `S-501`, `A-001`, `A-101`, `A-102`, `A-201`, `A-301`, `A-501`, `A-502`, `M-101`, `M-301`, `E-102`, `E-501`, and `T-501`.

---

## Scope Exclusions
The following reference and out-of-scope materials in the project corpus are explicitly excluded from the EOR review disposition register, sheet re-issue set, and constraint register:
- `project/review/other_discipline/fire_protection_comment_log_BP-2.csv (Fire Protection review comments are for reference/coordination only and excluded from EOR disposition_register.csv and constraint_register.xlsx)`
- `project/drawings/superseded/ (Superseded 60% and 90% submittal prints; markups placed on superseded sheets rather than current issue are VOID)`
- `project/drawings/record_prints_prior_contract/ (Record prints from an earlier contract)` (filed under `project/drawings/record_fy23/`)
