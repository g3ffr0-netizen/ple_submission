# Roof Deck Structural Design Basis — DC-2 Helena Data Centre, Building A

**Project Number:** DC2-2026-014  
**Facility:** DC-2 Helena Data Centre - Building A  
**Location:** Lewis and Clark County, Montana (Canyon Ferry Road site; Elevation 4880.0 ft, Latitude 46.6832, Longitude -111.9756)  
**Owner:** Continental Divide Digital Infrastructure LLC  
**Structural Engineer of Record:** Sandalwood Marlow Structural Engineers, PLLC  
**Risk Category:** III  
**Record Date:** 2026-07-31 (`2026-07`)  

---

## 1. Governing Documents and Conflict Resolution

Per Document Transmittal **T-118_Document_Transmittal** and the Owner's Basis of Design (**OBD-DC2-A Sections 1, 3, 5, 9**), the following hierarchy and conflict resolutions govern the roof deck design:

1. **Structural Design Criteria (`EOR-DC-RD-01 Rev 2`, issued 31 July 2026) vs. Superseded Rev 1 of EOR-DC-RD-01:**
   - `EOR-DC-RD-01 Rev 2` supersedes the earlier revision in its entirety. Key provisions enforced from `EOR-DC-RD-01 Rev 2` include: (a) unreduced roof live load $L_r = 20.0\text{ psf}$ on the deck (Clause 4.2, citing **UFC 1-200-01 (2022 Change 4)** and **UFC 3-301-01 (2023 Change 6)** Table E-1 Item 51); (b) windward ($0.75 h_d$) and leeward ($h_d$) snow drift rules applied in all four orthogonal wind directions (Clause 5.4); (c) inclusion of 20% of the flat-roof snow load ($0.20 p_f$) in the effective seismic weight $w_{seismic}$ because $p_f = 43.66\text{ psf} > 30\text{ psf}$ (Clause 7.2); (d) LRFD diaphragm shear resistance factor $\phi_d = 0.70$, fastener pull-over resistance factor $\phi_t = 0.50$, and ASD bending safety factor $\Omega_b = 1.67$ (Clause 10.1); (e) constructability caps of $\le 2$ gages, $\le 3$ attachment patterns, $\le 12$ zones, $6\text{ ft}$ module alignment in $x$ and $y$, and $\le 14$ rectangles in total across all zones (Clause 10.2); (f) sidelap connector spacing at $\le 36\text{ in}$ centres (Clause 10.3); and (g) minimum `36/7` support pattern and $\ge 3$ sidelap connectors per span for any zone touching the roof perimeter or a framed roof opening (Clause 10.4), with framed openings left undecked per **29 CFR 1926 Subpart R** (`1926.754(e)`) and **29 CFR 1910 Subpart D** (`1910.28(b)(3)`).
2. **3D Structural Model (`DC2-A-STR_Roof_Structure_Model_RevC.ifc`) vs. 2D Drawings (`A-201_Roof_Plan_REVC.dxf`, `M-401_Roof_Equipment_Plan_REVC.dxf`, `S-101_Roof_Framing_Plan_REV3.dxf`, `S-501_Roof_Details_and_Edge_Angle_REV2.dxf`, and Superseded Rev B of A-201):**
   - Per **T-118_Document_Transmittal** Clause 3.1, `DC2-A-STR_Roof_Structure_Model_RevC.ifc` is the authoritative geometric record of the roof framing, framed openings, and rooftop obstructions.
   - Superseded Rev B of A-201 showed the north equipment screen `SCR-N` in an earlier position ($y = 158\text{ ft}$) and is withdrawn. Both `DC2-A-STR_Roof_Structure_Model_RevC.ifc` and `A-201_Roof_Plan_REVC.dxf` place `SCR-N` at $y = 164.0\text{ ft}$ ($x \in [18, 222]\text{ ft}$, $h = 6.0\text{ ft}$) and `SCR-E` at $x = 216.0\text{ ft}$ ($y \in [24, 144]\text{ ft}$, $h = 7.0\text{ ft}$).
   - While `A-201_Roof_Plan_REVC.dxf` notes the equipment enclosure `MEP-PH-1` ($x \in [60, 180]\text{ ft}$, $y \in [60, 120]\text{ ft}$, $h = 12.0\text{ ft}$) as open-topped, **EOR-DC-RD-01 Rev 2** Clauses 5.4.4, 5.4.5, and 5.5.1 explicitly require treating the enclosure as an obstruction with leeward drift fetch $l_u$ equal to its along-wind length ($120\text{ ft}$ EW, $60\text{ ft}$ NS).
3. **Site-Specific Ground Snow Study (`SNOW-2026-014`) vs. Mapped Values:**
   - Per **OBD-DC2-A** Section 9 and **EOR-DC-RD-01 Rev 2** Clause 5.1, `SNOW-2026-014` ($p_g = 63.0\text{ psf}$) governs exclusively over regional mapped values.
4. **Seismic Hazard (`USGS_ASCE7-22_RC-III_SiteClass-D_46.6832_-111.9756` vs. Preliminary 2019 ASCE 7-16 RC-II Site Class C USGS report):**
   - `USGS_ASCE7-22_RC-III_SiteClass-D_46.6832_-111.9756` ($S_{DS} = 0.44$, $S_{D1} = 0.24$, $I_e = 1.25$) governs; the preliminary report is excluded.
5. **Deck Product and Procurement (`NORDECK_B-36_Steel_Deck_Catalogue_2026`, `Deck_Stock_Availability_2026-07`, `Cost_Plan_CP-RD-2026_Roof_Deck` vs. Archive 2019 Hall A Butte deck design):**
   - The Archive 2019 Hall A Butte deck design applies to a different site and discontinued product and is excluded.
   - Per **OBD-DC2-A** Section 5, roof-deck material must be on site within **9 weeks** of release. Per `Deck_Stock_Availability_2026-07`, 22 gage (2 weeks), 20 gage (3 weeks), and 18 gage (4 weeks) are compliant, whereas **16 gage** (14 weeks lead time) violates the 9-week cap and is prohibited.

---

## 1.A Scope Exclusions and Fixed Boundary Conditions

- Thermal effects are excluded from the roof deck design (roof assembly is fully insulated above the deck and building is conditioned continuously; AHJ agreed self-straining thermal forces need not be combined with gravity, snow, wind or seismic effects).
- Roof framing (open-web steel joists at 6 ft-0 in o.c. spanning 30 ft between joist girders over 240 ft x 180 ft footprint) is fixed and not to be changed.
- Ponding instability is addressed by drainage design (internal drains with secondary overflow scuppers) and by deck stiffness requirements of the structural design criteria.

---

## 2. Gravity, Snow Drift, Uplift, and Seismic Load Basis

### 2.1 Dead Load ($D$) and Roof Live Load ($L_r$ — Scenario `S01`)
- **Collateral Dead Load (`EOR-DC-RD-01 Rev 2` Section 3):** $4.5\text{ psf}$ (roofing/insulation) $+ 6.0\text{ psf}$ (suspended MEP allowance) $= 10.5\text{ psf}$.
- **Deck Self-Weight (`NORDECK_B-36_Steel_Deck_Catalogue_2026` Table 2-1):** $1.6\text{ psf}$ for 22 gage ($D = 12.1\text{ psf}$); $2.5\text{ psf}$ for 18 gage ($D = 13.0\text{ psf}$).
- **Roof Live Load ($L_r$):** $20.0\text{ psf}$ unreduced on the roof deck (**UFC 3-301-01 (2023 Change 6)** Table E-1 Item 51, **EOR-DC-RD-01 Rev 2** Clause 4.2).

### 2.2 Balanced Snow and Snow Drifts (Scenarios `S02`, `S03`, `S04`)
- **Ground Snow Load:** $p_g = 63.0\text{ psf}$ (`SNOW-2026-014`).
- **Flat-Roof Snow Load (`EOR-DC-RD-01 Rev 2` Clause 5.1):** With $C_e = 0.90$, $C_t = 1.00$, $I_s = 1.10$ (Risk Category III):
  $$p_f = 0.7 C_e C_t I_s p_g = 0.7(0.90)(1.00)(1.10)(63.0) = 43.66\text{ psf}$$
- **Snow Density and Balanced Depth (Clauses 5.2, 5.3):**
  $$\gamma = \min(0.13 p_g + 14, 30) = 22.19\text{ pcf}, \quad h_b = \frac{p_f}{\gamma} = 1.968\text{ ft}$$
- **Drift Methodology (Clause 5.4):** For upwind fetch $l_u \ge 20\text{ ft}$, $h_d = 0.43 l_u^{1/3}(p_g + 10)^{1/4} - 1.5\text{ ft}$ (leeward) and $0.75 h_d$ (windward and parapets). Where $h_d \le h_c = h - h_b$, peak surcharge $p_d = h_d \gamma$ and width $w = 4 h_d$; where $h_d > h_c$, $p_d = h_c \gamma$ and $w = \min(4 h_d^2 / h_c, 8 h_c)$.
- **Scheduled Drifts (`Drifts` Sheet):**
  - **`MEP-PH-1` Face `W` ($x = 60.0\text{ ft}$, $h = 12.0\text{ ft}$, $h_c = 10.032\text{ ft}$):** Governed by East-wind leeward drift ($l_u = 120\text{ ft}$, $h_d = 4.700\text{ ft} < h_c$), giving $p_d = 104.28\text{ psf}$ and width $w = 18.80\text{ ft}$ ($x \in [41.20, 60.0]\text{ ft}$).
  - **`SCR-N` Face `S` ($y = 164.0\text{ ft}$, $h = 6.0\text{ ft}$, $h_c = 4.032\text{ ft}$):** Governed by South-wind windward drift ($l_u = 164.0\text{ ft}$, $0.75 h_d = 4.035\text{ ft} > h_c$), truncated at $h_c = 4.0324\text{ ft}$, giving $p_d = 89.48\text{ psf}$ and width $w = 16.15\text{ ft}$ ($y \in [147.85, 164.0]\text{ ft}$).
  - **`PARAPET` Face `N` ($y = 180.0\text{ ft}$, $h = 3.5\text{ ft}$, $h_c = 1.532\text{ ft}$):** Governed by South-wind windward drift ($l_u = 180.0\text{ ft}$, $0.75 h_d = 4.198\text{ ft} > h_c$), truncated at $h_c = 1.5324\text{ ft}$ with width $w = 8 h_c = 12.26\text{ ft}$, giving $p_d = 34.01\text{ psf}$ ($y \in [167.74, 180.0]\text{ ft}$).
  - **`RTU-1` Face `E` ($x = 36.0\text{ ft}$, $h = 7.0\text{ ft}$, $h_c = 5.032\text{ ft}$):** Governed by East-wind windward drift ($l_u = 204.0\text{ ft}$, $0.75 h_d = 4.424\text{ ft} < h_c$), giving $p_d = 98.17\text{ psf}$ and width $w = 17.70\text{ ft}$ ($x \in [36.0, 53.70]\text{ ft}$).

### 2.3 Components and Cladding Wind Uplift (Scenario `S09`)
- Velocity pressure at $h = 32\text{ ft}$: $q_h = 0.00256 (1.04)(1.0)(0.85)(1.0)(115)^2 = 29.93\text{ psf}$ (Clause 6.1).
- Edge band width $a = \min(0.1 \times 180, 0.4 \times 32) = 12.8\text{ ft}$, $2a = 25.6\text{ ft}$ (Clause 6.2.1).
- Net wind uplift demand $|q_h(GC_p - GC_{pi})|$ is $101.2\text{ psf}$ in Zone 3 (corners), $74.2\text{ psf}$ in Zone 2 (perimeter), $47.3\text{ psf}$ in Zone 1 ($a$ to $2a$), and $32.3\text{ psf}$ in Zone 1-prime (interior) per Table 6-2.
- Resisted by $0.9(4.5 + w_{self})$ plus support fastener pull-over capacity $\phi_t P_{nov} / (18/n)$ with $\phi_t = 0.50$. Corner Zone 3 ($101.2\text{ psf}$) requires 18 gage with `36/9` ($119.75 + 6.30 = 126.05\text{ psf}$ capacity).

### 2.4 Wind and Seismic Lateral Loads (Scenarios `S05`, `S06`, `S07`, `S08`, `S10`)
- **Roof-Level Wind Forces (`LAT-2026-003` Table 4-1):** $V_{wind,x} = 118.0\text{ kip}$ (`S05`), $V_{wind,y} = 152.0\text{ kip}$ (`S06`), checked for both Case 1 (100% force, balanced) and Case 2 (75% force with $\pm 0.15 L_{perp}$ torsional eccentricity).
- **Effective Seismic Weight and Force (`LAT-2026-003` Section 5 & `EOR-DC-RD-01 Rev 2` Clause 7):**
  $$w_{seismic} = 18.0 + 0.20(43.66) = 26.732\text{ psf}$$
  $$W = 26.732 \times 240 \times 180 / 1000 = 1,154.82\text{ kip}, \quad C_s = \frac{S_{DS} I_e}{R} = \frac{0.44 \times 1.25}{3.25} = 0.16923$$
  $$F_{px} = C_s W = 195.43\text{ kip}$$
  Applied with accidental torsional eccentricity $e = \pm 0.05 L_{perp}$ ($\pm 9.0\text{ ft}$ for X in `S07`/`S10`, $\pm 12.0\text{ ft}$ for Y in `S08`), and collector forces amplified by $\Omega_0 = 2.0$ in `S10`.

---

## 3. Diaphragm Analysis and Classification

The roof diaphragm was analysed using the 2D finite-element formulation defined in `LAT-2026-003` Section 6.3 and `EOR-DC-RD-01 Rev 2`:
- $40 \times 6 = 240$ pure-shear panels ($6\text{ ft} \times 30\text{ ft}$), where the five $6\text{ ft} \times 6\text{ ft}$ deck strips across each $30\text{ ft}$ girder bay act in series ($G'_{panel} = 5 / \sum (1/G'_k)$), and panels containing framed openings (`RO-1` at $[96,108]\times[48,60]$, `RO-2` at $[132,144]\times[120,132]$, `RO-3` at $[180,210]\times[60,84]$) are modelled as holes in the shear field.
- Axial bar elements along all 41 joist lines ($EA_{joist} = 87,580\text{ kip}$) and all 7 girder lines ($EA_{girder} = 221,850\text{ kip}$), augmented along the four perimeter lines by the continuous `L5x3-1/2x5/16` edge member ($EA_{edge} = 74,240\text{ kip}$) per `LAT-2026-003` Table 6-2.
- Braced frames modelled as elastic springs with half of each frame's roof-level stiffness at each of its two column nodes (`BF-X1, X2`: $55.0\text{ kip/in}$ each on Grid A; `BF-X3, X4`: $18.0\text{ kip/in}$ each on Grid G; `BF-Y1, Y2`: $22.0\text{ kip/in}$ each on Grid 1; `BF-Y3, Y4`: $68.0\text{ kip/in}$ each on Grid 9) per `LAT-2026-003` Table 3-1. Regularisation springs carry $< 0.01\%$ of the applied force (well below the $2\%$ threshold).

### 3.1 Diaphragm Classification (`SEMI-RIGID`)
Under the governing seismic lateral load ($F_{px} = 195.43\text{ kip}$), the average storey drift of the vertical braced frames is $\Delta_{ADVE,X} = 1.56\text{ in}$ (so $2.0 \Delta_{ADVE,X} = 3.12\text{ in}$) and $\Delta_{ADVE,Y} = 1.42\text{ in}$ (so $2.0 \Delta_{ADVE,Y} = 2.84\text{ in}$). The maximum computed in-plane diaphragm deflection is $0.626\text{ in}$ in X (`S07`/`S10`) and $1.079\text{ in}$ in Y (`S08`), both well below $2.0 \Delta_{ADVE}$ and below the $1.60\text{ in}$ serviceability cap of Clause 9.2. Accordingly, the diaphragm is classified as **`SEMI-RIGID`**.

### 3.2 Diaphragm Results Summary
| Scenario | Direction | Max Shear (plf) | Max Deflection (in) | Chord Force (kip) | Collector Force (kip) | Classification |
|---|---|---:|---:|---:|---:|---|
| `S05` | X | 334.7 | 0.394 | 9.62 | 14.42 | `SEMI-RIGID` |
| `S06` | Y | 726.5 | 0.845 | 27.97 | 16.37 | `SEMI-RIGID` |
| `S07` | X | 550.1 | 0.626 | 16.33 | 28.63 | `SEMI-RIGID` |
| `S08` | Y | 992.5 | 1.079 | 36.32 | 20.89 | `SEMI-RIGID` |
| `S10` | X | 550.1 | 0.626 | 16.33 | 57.25 | `SEMI-RIGID` |

Both the maximum chord force ($36.32\text{ kip} \le 38.0\text{ kip}$ splice capacity) and the overstrength-amplified collector force in `S10` ($57.25\text{ kip} \le 58.0\text{ kip}$ splice capacity) satisfy `LAT-2026-003` Table 6-1 and Clause 6.2.1.

---

## 4. Zoning Decisions and Installed Cost Summary

To satisfy all gravity snow-drift, wind uplift, diaphragm shear ($\phi_d = 0.70$ per Clause 10.1), deflection, chord/collector splice, and constructability rules at minimum installed cost, the roof is divided into **4 zones** across **14 rectangles** (covering all $42,192\text{ sq ft}$ of decked roof area, excluding the $1,008\text{ sq ft}$ of cells touched by `RO-1`, `RO-2`, and `RO-3`), using **2 deck gages** (22 gage and 18 gage) and **3 attachment patterns**:

1. **Zone `Z1` (22 gage, `36/9`, `SCREW-10`, 4 per span — 3 rectangles, $8,712\text{ sq ft}$):**
   - Covers the South ($[18,210]\times[0,24]$) and West ($[0,24]\times[24,48]$ and $[0,42]\times[48,132]$) low-drift perimeter regions where balanced snow plus parapet/equipment drift is $\le 91.41\text{ psf}$ ($D + S = 103.51\text{ psf} \le 106.0\text{ psf}$, governing scenario **`S04`** with gravity D/C $= 0.976$). The `36/9` support pattern provides $79.99\text{ psf}$ uplift resistance for Perimeter Zone 2 ($74.2\text{ psf}$, uplift D/C $= 0.928$ in `S09`) and $\phi_d S_n = 694.4\text{ plf}$ design shear capacity vs. $567.0\text{ plf}$ peak shear demand (shear D/C $= 0.817$ in `S08`).
2. **Zone `Z2` (22 gage, `36/7`, `SCREW-10`, 4 per span — 1 rectangle, $6,840\text{ sq ft}$):**
   - Covers the interior of the equipment enclosure (`[66,180]x[60,120]`), where snow drifts form outward from the enclosure walls and peak gravity demand is $84.90\text{ psf} \le 106.0\text{ psf}$ (governing scenario **`S04`** with gravity D/C $= 0.801$), uplift demand is $32.3\text{ psf} \le 63.43\text{ psf}$ (`S09` D/C $= 0.509$), and peak shear demand is $314.6\text{ plf} \le 604.8\text{ plf}$ ($\phi_d S_n = 0.70 \times 864 = 604.8\text{ plf}$, $G' = 22.0\text{ kip/in}$), satisfying Clause 10.4 at opening boundaries.
3. **Zone `Z3` (18 gage, `36/7`, `SCREW-10`, 4 per span — 7 rectangles, $12,384\text{ sq ft}$):**
   - Covers all interior snow-drift bands around `MEP-PH-1`, `RTU-1` through `RTU-12`, and the framed openings `RO-1`, `RO-2`, and `RO-3`, where peak snow load reaches $147.94\text{ psf}$ ($D + S = 160.94\text{ psf} \le 177.0\text{ psf}$, governing scenario **`S02`** with gravity D/C $= 0.909$). Shares the same attachment pattern (`36/7`, `SCREW-10`, 4) as `Z2` to avoid an extra pattern set-up charge while providing $G' = 33.8\text{ kip/in}$ and $\phi_d S_n = 905.1\text{ plf}$ vs. $624.9\text{ plf}$ peak shear demand (shear D/C $= 0.690$).
4. **Zone `Z4` (18 gage, `36/9`, `SCREW-10`, 5 per span — 3 rectangles, $14,256\text{ sq ft}$):**
   - Covers the SW corner ($[0,18]\times[0,24]$), the North band including `SCR-N` and NW corner ($[0,210]\times[132,180]$), and the East band including `SCR-E`, SE/NE corners, and the high-shear corridor east of `RO-3` along Grid 9 ($[210,240]\times[0,180]$). Peak gravity demand is $160.94\text{ psf} \le 177.0\text{ psf}$ (governing scenario **`S02`** with D/C $= 0.909$), uplift demand is $101.2\text{ psf} \le 126.05\text{ psf}$ (`S09` D/C $= 0.803$), and peak shear demand is $992.5\text{ plf} \le 1,225.7\text{ plf}$ ($\phi_d S_n = 0.70 \times 1,751 = 1,225.7\text{ plf}$, `S08` shear D/C $= 0.810$).

### 4.1 Installed Cost Breakdown (`Cost_Plan_CP-RD-2026_Roof_Deck`)
- **22 Gage Deck Area:** $15,552\text{ sf} \times \$3.05/\text{sf} = \$47,433.60$
- **18 Gage Deck Area:** $26,640\text{ sf} \times \$4.42/\text{sf} = \$117,748.80$
- **Support Fasteners:** $19,144\text{ ea} \times \$1.35/\text{ea} = \$25,844.40$
- **Sidelap Connectors (`SCREW-10`):** $10,260\text{ ea} \times \$1.15/\text{ea} = \$11,799.00$
- **Indirect Set-Up Costs:** 4 zones ($\$3,600$) + 14 rectangles ($\$3,640$) + 2 gages ($\$9,600$) + 3 patterns ($\$4,200$) $= \$21,040.00$
- **Total Installed Cost:** **$\$223,865.80$**
