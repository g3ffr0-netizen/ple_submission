```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01, DoD Building Code (1 September 2022, Change 4, 17 December 2024)",
    "precedence": "Where two criteria documents set different limits for the same requirement, the most restrictive requirement governs (EDS-26 Rev 4 Section 1.1; G-001 Note B)."
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42,
    "roof_ambient_c": 46,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "encasement_thermal_resistivity_k_m_w": 0.55,
    "solar_irradiance_w_m2": 1030
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA_daily_normals_1991-2020_USW00003145.csv (max DLY-TMAX-NORMAL 106.8 F = 41.56 C rounded up to 42 C per EDS-26 Rev 4 Clause 5.4)",
    "roof_ambient_c": "NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Clause 5.4 and M-501-C_ambient_temperature_coordination_memo.pdf Table 1 (42 C + 4 K = 46 C)",
    "earth_ambient_c": "NOAA_daily_normals_1991-2020_USW00003145.csv and NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Clause 5.3.2 (annual mean DLY-TAVG-NORMAL 76.00 F = 24.45 C + 3 K = 27.45 C)",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T_thermal_resistivity_report.pdf Clause 2.2 and NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Clause 5.3.1 (0.60 K.m/W fluidized thermal backfill; native soil 0.95 K.m/W rejected)",
    "encasement_thermal_resistivity_k_m_w": "GEO-4210-T_thermal_resistivity_report.pdf Clause 2.3 and NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Clause 5.3.1 (0.55 K.m/W concrete encasement)",
    "solar_irradiance_w_m2": "NSA-WR_EDS-26_electrical_design_standard_rev4.pdf Clause 5.4 (1030 W/m2)"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs (480Y/277 V point of government ownership)",
    "transformer_reset": false,
    "feeder_chain_pct": {
      "SE-1_to_MSB-1": 1.04,
      "SE-1_F-01_to_MCC-1": 2.58,
      "SE-1_F-02_to_DP-2": 1.41,
      "SE-1_F-02_F-06_to_K-13": 1.57,
      "SE-1_F-02_F-06_F-07_to_LP-1": 2.77,
      "SE-1_F-05_to_DP-3": 2.58,
      "SE-1_F-10_to_ATS-1": 2.78,
      "max_feeder_chain_pct": 2.78
    },
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 93402.32,
    "termination_usd": 9609.32,
    "raceway_usd": 47589.6,
    "material_usd": 96914.9,
    "labor_usd": 53686.34,
    "total_usd": 150601.24
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D5",
      "D6",
      "D9",
      "D10"
    ],
    "F-10": [
      "D4",
      "D8"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": 31.09
}
```

# Engineering Basis of Design — Low-Voltage Wire Schedule (Project P-4210, Building 4210)

## 1. Codes of Record, Adoption, and Order of Precedence
This low-voltage conductor, grounding, raceway, and duct-bank design for Building 4210 (Consolidated Support Facility) and Building 4212 at Naval Support Activity Whitmore Ridge was prepared in accordance with the project's governing criteria:
- **Adopted National Codes of Record**: **NFPA 70 (National Electrical Code), 2023 Edition** and **International Building Code (IBC), 2024 Edition**, both adopted by **UFC 1-200-01, *DoD Building Code* (1 September 2022, Change 4, 17 December 2024)** (`Clause 1-3.1` and `Clause 3-2`), as modified by **UFC 3-501-01, *Electrical Engineering* (27 November 2024)** and **UFC 3-520-01, *Interior Electrical Systems* (16 January 2025)**. Per `G-001` Note A, the solicitation date is 14 March 2025.
- **Order of Precedence**: Per **EDS-26 Rev 4** (`Clause 1.1`) and **G-001** (`General Note B`), where two documents in the project data room set different limits for the same requirement, **the most restrictive requirement governs**.
- **Superseded and Non-Governing Documents Excluded**:
  1. `NSA-WR_EDS-26_electrical_design_standard_rev2_SUPERSEDED.pdf` (EDS-26 Rev 2, 19 October 2021) is superseded by **EDS-26 Rev 4 (12 June 2026)** and is not used (its 5 ft termination allowance, 2% feeder voltage-drop limit, 20 °C earth ambient, 0.90 K·m/W default soil resistivity, and all-copper mandate are superseded).
  2. `E-601_one_line_REV_A_SUPERSEDED.pdf` (8 February 2026) is superseded by Issued-for-Construction drawing **`E-601_one_line_diagram.dxf` (12 June 2026)**.
  3. `Meridian_Cable_building_wire_datasheet.pdf` (THHN/THWN-2) is not the basis of design; per **Specification Section 26 05 19** (`Clause 2.1.A`), **Cascadia Wire and Cable XHHW-2** (`Cascadia_Wire_engineering_data_2026.pdf`) is the basis-of-design product.
  4. `E-401_fire_alarm_riser.dxf` covers power-limited fire-alarm signaling circuits under NFPA 72 and is outside the Section 26 05 19 low-voltage power scope (`EDS-26 Rev 4 Clause 1.2`).

## 2. Environmental Parameters and Provenance
All ambient temperatures and thermal properties are derived from the site climate record (`NOAA_daily_normals_1991-2020_USW00003145.csv`), geotechnical report (`GEO-4210-T_thermal_resistivity_report.pdf`), mechanical coordination memo (`M-501-C_ambient_temperature_coordination_memo.pdf`), and **EDS-26 Rev 4**:
- **Outdoor Design Dry-Bulb Temperature (`42 °C`)**: Highest daily normal maximum temperature (`DLY-TMAX-NORMAL`) in `NOAA_daily_normals_1991-2020_USW00003145.csv` is `106.8 °F` (`41.556 °C`, on July 21), rounded up to the next whole degree Celsius (`42 °C`) per `EDS-26 Rev 4 Clause 5.4`.
- **Roof Cable Tray Ambient Temperature (`46 °C`) & Solar Irradiance (`1030 W/m²`)**: Per `EDS-26 Rev 4 Clause 5.4` and `M-501-C Table 1`, sun-exposed roof ladder tray `CT-R1` uses `42 °C + 4 K = 46 °C` ambient, solar irradiance `S = 1030 W/m²`, solar absorptivity `alpha_s = 0.6`, and convection coefficient `h = 14.0 W/(m²·K)`.
- **Earth Ambient Temperature (`27.45 °C`)**: Per `EDS-26 Rev 4 Clause 5.3.2`, the undisturbed earth ambient at duct-bank depth is the annual mean of the daily average temperature normals (`DLY-TAVG-NORMAL` mean = `76.0036 °F` = `24.4464 °C` across all 366 days) plus `3 K`, giving `27.4464 °C` (`27.45 °C`). Short-term April–June borehole temperature logs (`22.1–28.4 °C` in `GEO-4210-T Clause 3`) are rejected per `EDS-26 Rev 4 Clause 5.3.2`.
- **Soil and Concrete Thermal Resistivities (`0.60 K·m/W` and `0.55 K·m/W`)**: Per `GEO-4210-T Clauses 2.2–2.3`, `E-619` Note 3, and `EDS-26 Rev 4 Clause 5.3.1`, engineered fluidized thermal backfill (`rho_e = 0.60 K·m/W`) surrounds `DB-1` and `DB-2`, and concrete encasement has `rho_c = 0.55 K·m/W`. Native sandy silt (`0.95 K·m/W`, `GEO-4210-T Clause 2.1`) was excavated and replaced and is therefore rejected.
- **Interior Space Ambient Temperatures (`45 °C` and `40 °C`)**: Per `M-501-C Table 1` and `Notes 2–3`, Mechanical Room 121 (`F-01`, `B-11`..`B-15`) and Fire Pump Room 105 (`F-03`) use `45 °C`; all other interior raceway circuits (`B-01`..`B-10`, `B-16`..`B-18`, `F-02`, `F-06`, `F-07`, `F-09`, `F-11`) pass through the unconditioned ceiling cavity (`40 °C`) or Building 4212 shop (`40 °C`) for more than 10% of their run length and therefore use `40 °C` over their entire length.

## 3. Voltage-Drop Budget Allocation, Starting Point, and Non-Reset at Low-Voltage Transformers
- **Starting Point (`T-1` Secondary Lugs)**: Per `WRPU_service_availability_letter.pdf` (`Paragraph 1`), the point of government ownership and delivery is the secondary spade terminals (`480Y/277 V`) of pad-mounted utility transformer `T-1`. Per `UFC 3-501-01 Clause 3-2.7`, voltage-drop calculations start at `T-1` secondary lugs (`SE-1`).
- **Low-Voltage Transformer Non-Reset (`transformer_reset = false`)**: Per `UFC 3-501-01 Clause 3-2.7`, voltage-drop accumulation only restarts when stepped down from a source *over* 1,000 V to below 1,000 V. Because dry-type transformer `K-13` (`480 V` to `208Y/120 V`, 225 kVA) and `DP-3`'s integral transformer (`480 V` to `208Y/120 V`, 75 kVA) have primary voltages of `480 V` (`<= 1,000 V`), **the voltage-drop count does NOT reset at `K-13` or `DP-3`**.
- **Chain Budget Allocation and Branch Circuit Inheritance**:
  - **18 branch circuits** (`B-01` through `B-18`) inherit the cumulative feeder voltage drop spent upstream of their panelboard/MCC:
    1. **LP-1 Chain (`10` branch circuits `B-01`..`B-10`)**: Inherits `SE-1 (1.04%) + F-02 (0.36%) + F-06 (0.16%) + F-07 (1.20%) = 2.77%` (`<= 3.0%` feeder limit at `LP-1`). Branch drops range from `1.62%` (`B-10`) to `2.09%` (`B-06`, `B-09`), yielding cumulative drops at the loads of `4.39%` to `4.86%` (`<= 5.0%` total limit).
    2. **MCC-1 Chain (`5` motor branch/feeder circuits `B-11`..`B-15`)**: Inherits `SE-1 (1.04%) + F-01 (1.53%) = 2.58%` (`<= 3.0%` feeder limit at `MCC-1`). Individual circuit drops are `0.30%` to `1.20%`, yielding cumulative drops of `2.88%` to `3.77%` (`<= 5.0%`).
    3. **DP-3 Chain (`3` branch circuits `B-16`..`B-18`)**: Inherits `SE-1 (1.04%) + F-05 (1.54%) = 2.58%` (`<= 3.0%` feeder limit at `DP-3`). Sizing `F-05` as `3 sets of 600 kcmil AL` (`1.54%` drop) keeps `B-17` (`#6 AWG CU`, constrained by `CMP-1`'s `#6 AWG` lug limit, `2.35%` drop) at a cumulative drop of `2.58% + 2.35% = 4.93% <= 5.0%` without requiring a terminal pigtail reduction.
  - Additionally, equipment feeders `F-08`, `F-09`, `F-13` on `DP-2` inherit `SE-1 + F-02 = 1.41%` (cumulative `2.07%` to `2.52%`), and `MSB-1` equipment feeders `F-03`, `F-04`, `F-10`, `F-11`, `F-12` inherit `SE-1 = 1.04%` (cumulative `1.34%` to `2.78%`). Fire pump `F-03` (`#1 AWG CU`) has `1.34%` cumulative running voltage drop (`<= 5.0%`) and `2.71%` cumulative locked-rotor voltage drop at `543 A` (`<= 15.0%` per `NFPA 70 Article 695` and `EDS-26 Clause 4.6.3`).

## 4. Service-Entrance `SE-1` Sizing Decision
Per `UFC 3-501-01 Clause 3-2.3.3` and `EDS-26 Rev 4 Clause 2.2`, service-entrance conductors `SE-1` must be sized to carry not less than the `2,000 A` main bus ampacity of `MSB-1` (rather than the `1,600 A` main breaker setting, and exceeding `1,732 A` connected load). Per `EDS-26 Clause 2.3` and `UFC 3-501-01 Clause 3-2.7.4.3.1`, the voltage-drop load is taken as the `1,600 A` service overcurrent device rating (`VD = 1.04%`; even if evaluated at `2,000 A`, `SE-1` VD is `1.30%`, keeping all chains compliant). `SE-1` is selected as **6 parallel sets of `500 kcmil CU`** (`I_corr = 348.73 A/set`, total `2,092.39 A >= 2,000 A`) with `#4/0 AWG CU` EGC per duct.

## 5. Underground Duct-Bank Assignment (`DB-1` and `DB-2`) and Thermal Consequence
- **Service Duct Bank `DB-1` (`12` conduits, `D1`..`D10` available; `D11`, `D12` reserved for future primary extension per `E-619` Note 4)**:
  - **10 ducts** (`D1`..`D10`) are available in `DB-1`. Eight ducts are occupied (`6` by `SE-1` and `2` by `F-10`), leaving `D3` and `D7` as unallocated spares and `D11`, `D12` reserved with zero current (`EDS-26 Clause 5.3.4`).
  - `SE-1` (`6 sets of 500 kcmil CU`, `W = 7.907 W/m` per duct at `1,732 A` connected load and `100%` load factor) is assigned to **`D1, D2, D5, D6, D9, D10`** (the two west columns of `DB-1`), while `F-10` (`2 sets of 500 kcmil AL`, `W = 7.454 W/m` per duct at `432 A`) is separated onto the east column **`D4, D8`**.
  - **Thermal Consequence**: Separating `F-10` onto the east edge (`D4, D8`) away from the `SE-1` group reduces the mutual-heating temperature rise on `F-10` to **`23.53 K`**, giving `F-10` a Neher-McGrath ampacity of **`302.78 A/set` (`605.57 A` total `>= 600 A` design current)**. The governing `SE-1` duct (`D6`) experiences a mutual-heating rise of **`31.09 K`**, yielding **`348.73 A/set` (`2,092.39 A` total `>= 2,000 A`)**.
- **East Feeder Duct Bank `DB-2` (`4` conduits, `E1`..`E3` available; `E4` reserved per `E-619` Note 4)**:
  - `F-05` (`3 sets of 600 kcmil AL`) occupies **`E1, E2, E3`**. At `281 A` connected load (`W = 1.240 W/m` per duct), the mutual-heating rise is **`1.54 K`**, yielding `I_90 = 398.99 A/set`, capped by the `75 °C` termination limit at **`336.00 A/set` (`1,008.00 A` total `>= 400 A`)**.

## 6. Material Selection and Size Standardisation
- **Material (`CU` vs `AL`)**: Conductors `#6 AWG` and smaller, and all equipment grounding conductors, are copper (`CU`) per `UFC 3-520-01 Clause 3-6.3.1` and `EDS-26 Clause 3.2`. AA-8000 aluminium (`AL`) is used on large feeders (`F-01`, `F-04`, `F-05`, `F-07`, `F-08`, `F-09`, `F-10`, `F-12`, `F-13`) and `B-15` where terminal lugs and ampacities permit, while copper (`CU`) is used on `SE-1` (required by `DB-1` thermal limit inside `6 x 600 kcmil` lug capacity), short feeders `F-02`, `F-03`, `F-06`, `F-11`, and branch circuits.
- **Roof Cable Tray `CT-R1` Single-Layer Width Check (`EDS-26 Clause 6.3.2`)**: `F-04` (`2` sets of `4/0 AL` + `#3 CU` EGC), `F-08` (`1` set of `4/0 AL` + `#6 CU` EGC), `F-12` (`2` sets of `4/0 AL` + `#3 CU` EGC), and `F-13` (`1` set of `4/0 AL` + `#6 CU` EGC) have a total outside diameter sum of **`12.206 in`** including EGCs (**`10.404 in`** for the 18 phase conductors plus `1.802 in` for the 6 EGCs), well below `90%` of the `18 in` tray width (`16.2 in`).
- **Size Standardisation (`<= 5` Sizes Larger Than `#1 AWG`)**: Per `EDS-26 Clause 3.4.2`, across all 32 circuits the design uses **5** distinct phase-conductor sizes larger than `#1 AWG`: **`4/0 AWG`, `300 kcmil`, `400 kcmil`, `500 kcmil`, and `600 kcmil`**.

## 7. Cost Ledger Summary (Material and Labour)
Total installed conductor length across all 32 circuits (including copper EGCs) is **`40,888 ft`** (`>= 38,000 ft`), qualifying the project for the **6% campus quantity discount** on conductor material and pulling labour (`Cascadia_Wire_price_list_2026.csv`).
- **Gross Conductor (Phase + EGC)**: Material `$74,897.40` + Labour `$24,466.77` = `$99,364.17`
- **Campus Quantity Discount (-6%)**: Material `$-4,493.84` + Labour `$-1,468.01` = `$-5,961.85`
- **Net Conductor (Phase + EGC)**: Material `$70,403.56` + Labour `$22,998.76` = **`$93,402.32`**
- **Terminations (`90` set-ends)**: Material `$5,105.26` + Labour `$4,504.06` = **`$9,609.32`**
- **Interior Rigid Steel Conduit (`4,257 ft`)**: Material `$21,406.08` + Labour `$26,183.52` = **`$47,589.60`**
- **Total Installed Package Cost**: Material **`$96,914.90`** + Labour **`$53,686.34`** = **`$150,601.24`**
