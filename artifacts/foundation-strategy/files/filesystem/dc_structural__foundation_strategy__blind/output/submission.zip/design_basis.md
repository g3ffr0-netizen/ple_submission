```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 265454.39,
      "improved_cost_usd": 81812.64
    },
    "CR-P2": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 262748.93,
      "improved_cost_usd": 88571.26
    },
    "CR-P3": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 32544.34,
      "improved_cost_usd": 55225.26
    },
    "CR-P4": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 81142.13,
      "improved_cost_usd": 48736.42
    },
    "CR-P5": {
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 18117.64,
      "improved_cost_usd": 36352.8
    },
    "CR-P6": {
      "governing_constraint": "BEARING",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 225580.81,
      "improved_cost_usd": 84255.12
    }
  },
  "campus": {
    "rigs_mobilised": 2,
    "mobilisation_cost_usd": 80000.0,
    "total_cost_usd": 434037.42,
    "pads_improved": [
      "CR-P1",
      "CR-P2",
      "CR-P4",
      "CR-P6"
    ]
  },
  "rejected_criteria": [
    "UFC_3-220-01N_Foundation_Design_2005_CANCELLED.pdf",
    "UFC_3-220-10N_Soil_Mechanics_2005_CANCELLED.pdf",
    "AV-CR-2604_Basis_of_Design_Structural_Rev1_SUPERSEDED.docx",
    "AV-CR-2604_Geotechnical_Addendum_1_SUPERSEDED.pdf",
    "Adjacent_Parcel_Report_Broadview_Commons_2023.pdf",
    "FHWA_GEC6_Shallow_Foundations_bridges.pdf",
    "NOAA_NCEI_AFI_return_periods_1951-1980.xls"
  ]
}
```

# Cattail Run Data Campus — Phase 1 Foundation Design Basis

## 1. Governing Criteria and Documents Reviewed and Set Aside

### 1.1 Governing Criteria, Manuals, and Project Records
The Phase 1 foundation design for Building Pads `CR-P1` through `CR-P6` is governed by:
* **Owner & AHJ Criteria**: `AV-CR-2604_Basis_of_Design_Structural_Rev3.docx` (Structural Basis of Design Rev. 3), `Loudoun_County_AHJ_amendment_letter_LC-BD-26-0774.pdf`, `AV-CR-2604_RFI_log.xlsx` (`RFI-004`, `RFI-007`, `RFI-009`, `RFI-011`, `RFI-013`, `RFI-015`, `RFI-017`, `RFI-019`, `RFI-021`), and `AV-CR-2604_BIM_parameter_standard.md` (Rev. 2).
* **Unified Facilities Criteria & Guide Specifications**: `UFC_3-220-01_Geotechnical_Engineering_2012_c3.pdf` (1 Nov 2012, Change 3, 1 Jul 2025), `UFC_3-301-01_Structural_Engineering_2023_c4.pdf`, `UFGS_03_30_00_Cast-in-Place_Concrete.pdf`, and `UFGS_31_00_00_Earthwork.pdf`.
* **Analysis & Design Manuals**: `UFC_3-220-20_Foundations_and_Earth_Structures_DM7-2_2025.pdf` (16 Jan 2025), `EM_1110-1-1905_Bearing_Capacity_of_Soils.pdf`, `EM_1110-2-2000_Concrete_for_Civil_Works_Structures.pdf`, `EM_1110-2-2104_Strength_Design_for_Reinforced_Concrete.pdf`, `EM_1110-2-2502_Retaining_and_Flood_Walls.pdf`, and `FHWA_GEC13_Vol1_Ground_Modification_Methods.pdf`.
* **Site Geotechnical, Climate, Civil, Structural, and Cost Records**: `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf`, Boring Logs `BORING_LOG_B-101A.pdf` through `BORING_LOG_B-106B.pdf`, `AV-CR-2604_laboratory_test_summary.xlsx`, `NOAA_NCEI_AFI_1981-2010_rtp_tavg_afzndx.txt` (with `NOAA_NCEI_AFI_dataset_documentation_DSI-9712D.pdf`, `NOAA_NCEI_AFI_station_inventory.txt`, and `NOAA_NCEI_Air_Freezing_Index_return_periods.pdf`), `AV-CR-2604_grading_and_groundwater_record.pdf`, `AV-CR-2604_base_reactions.csv`, `AV-CR-2604_column_grid.dxf`, `AV-CR-2604_load_combination_memo.docx`, `AV-CR-2604_bid_schedule_Rev1.xlsx`, and `Kettleridge_Ground_Systems_budget_proposal.pdf`.

### 1.2 Cancelled, Superseded, and Non-Governing Documents Set Aside
The following documents in the data room were reviewed and explicitly set aside:
1. **`UFC_3-220-01N_Foundation_Design_2005_CANCELLED.pdf`** and **`UFC_3-220-10N_Soil_Mechanics_2005_CANCELLED.pdf`**: Cancelled predecessor UFC volumes superseded by `UFC 3-220-01` (2012, c3) and `UFC 3-220-20` (DM 7.2, 2025).
2. **`AV-CR-2604_Basis_of_Design_Structural_Rev1_SUPERSEDED.docx`**: Superseded in its entirety by Revision 3 (`AV-CR-2604_Basis_of_Design_Structural_Rev3.docx`).
3. **`AV-CR-2604_Geotechnical_Addendum_1_SUPERSEDED.pdf`**: Superseded geotechnical addendum replaced by `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf`.
4. **`Adjacent_Parcel_Report_Broadview_Commons_2023.pdf`**: Off-site subsurface report for a different property (`RFI-013`); information only and not used for Cattail Run design.
5. **`FHWA_GEC6_Shallow_Foundations_bridges.pdf`**: Written for highway bridge structures, whose angular distortion limits (`1/250` for continuous-span bridges, `1/200` for simple-span bridges) do not apply to building structures.
6. **`NOAA_NCEI_AFI_return_periods_1951-1980.xls`**: Superseded 1951–1980 Air Freezing Index tables (`416` degree F-days at Lincoln, VA, station `444909`), replaced by the active `1981-2010` NOAA NCEI product (`556` degree F-days at `USC00444909`) per `Loudoun_County_AHJ_amendment_letter_LC-BD-26-0774.pdf` Amendment 3 and `RFI-007`.

## 2. Bearing Capacity, Factor of Safety, and Settlement Methodology

* **Prohibition on Presumptive Bearing Values**: Per `UFC 3-220-01` Paragraph `2-4.5.1` (`1806.1`), `Loudoun_County_AHJ_amendment_letter_LC-BD-26-0774.pdf` Amendment 2, and `RFI-009`, the preliminary `3,000 psf` presumptive bearing value in `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` Section 7 is prohibited for final sizing; all foundations are sized by site-specific bearing capacity and settlement analyses.
* **Bearing Capacity Equations (`RFI-021`)**: Net allowable bearing capacity is evaluated from the drained shear strength parameters of `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` Section 2 (Stratum I: gamma = 118 pcf, phi' = 26.0 deg, c' = 0.25 ksf; Stratum II: gamma = 126 pcf, phi' = 33.0 deg, c' = 0.00 ksf; Stratum III: gamma = 132 pcf, phi' = 38.0 deg, c' = 0.00 ksf) using the Terzaghi, Meyerhof, and Brinch Hansen equations in `UFC 3-220-20` Section `5-3.1.2` (Equation 5-15, Tables 5-2, 5-5, 5-6, 5-8) and `EM 1110-1-1905` Equation 4-1 (Tables 4-2, 4-3, 4-5), adopting the conservative minimum of the three methods: `q_allow_net = (q_ult - q_0) / FS`.
* **Groundwater Correction**: Per `UFC 3-220-20` Section `5-3.2` (Figure 5-6) and `EM 1110-1-1905` Section `4-2.b` (Equations 4-3a, 4-3b), where the stabilised piezometer depth `z_w` (`AV-CR-2604_grading_and_groundwater_record.pdf`: `CR-P1 = 8.0 ft`, `CR-P2 = 9.0 ft`, `CR-P3 = 19.0 ft`, `CR-P4 = 8.0 ft`, `CR-P5 = 21.0 ft`, `CR-P6 = 8.5 ft`) lies within `D_f + B`, effective overburden `q_0` and the failure wedge effective unit weight `gamma_eff` are corrected using `gamma' = gamma - 62.4 pcf`.
* **Bearing Factor of Safety by Pad**: Selected from `UFC 3-220-01` `Table 2-3` using the Occupancy Classification in `AV-CR-2604_Basis_of_Design_Structural_Rev3.docx` Section 2:
  * `CR-P1`, `CR-P2`, `CR-P3`, `CR-P6` (`Light Industrial, Public`): **`FS = 3.5`**
  * `CR-P4` (`Apartments, Office`): **`FS = 3.0`**
  * `CR-P5` (`Warehouse`): **`FS = 2.5`**
* **Layered Elastic Compression Settlement Methodology (`RFI-019` & `FHWA GEC 13` Equation 5-14)**:
  * Per `RFI-019`, total settlement of unimproved spread footings and lower-zone settlement beneath rammed aggregate piers are computed by subdividing the soil profile from the bearing surface (or from the bottom of the RAP treatment zone `H_uz`) to a depth of `max(4B, 40 ft)` below the bearing surface into uniform layers **`0.25 ft` thick**.
  * At the mid-height `z` of each layer below the bearing surface, the vertical stress increment is computed with the 2V:1H distribution `delta_sigma_z = P_srv / ((B + z) * (L + z))`, and layer compressions `delta_s = (delta_sigma_z * dz) / Es(z)` are summed using the pad-specific elastic moduli from `AV-CR-2604_Geotechnical_Data_Report_Rev2.pdf` Section 2 (`Stratum I / II / III`: `CR-P1 = 110 / 1500 / 3500 ksf`, `CR-P2 = 85 / 1400 / 3400 ksf`, `CR-P3 = 210 / 1700 / 3700 ksf`, `CR-P4 = 130 / 1600 / 3600 ksf`, `CR-P5 = 250 / 1800 / 3800 ksf`, `CR-P6 = 95 / 1450 / 3450 ksf`).

## 3. Tolerable Movement Criteria and Resolution of Document Conflicts

1. **Total and Differential Settlement (`UFC 3-220-01` vs. Superseded BOD Rev. 1 and `FHWA GEC 6`)**: `UFC 3-220-01` Paragraph `2-4.7.1` (`1808.2`) governs: maximum total settlement is **`1.0 in`** and maximum angular distortion between adjacent foundation units is **`1/500` (`0.002 rad`)**. Competing criteria in `FHWA GEC 6` (`1/250` and `1/200` for bridges) and superseded BOD Rev. 1 were rejected.
2. **Frost Protection Depth (`1981-2010` vs. `1951-1980` NOAA AFI Dataset)**: Under `UFC 3-220-01` Paragraph `2-4.8.4` (`1809.5`) and `Loudoun_County_AHJ_amendment_letter_LC-BD-26-0774.pdf` Amendment 3, frost depth is 30 in when the 100-year AFI <= 500 degree F-days and **42 in** when the 100-year AFI > 500 degree F-days. At the county station of record (`USC00444909`, Lincoln, VA), the superseded `1951-1980` product (`NOAA_NCEI_AFI_return_periods_1951-1980.xls`) gave `416` degree F-days, whereas the governing `1981-2010` product (`NOAA_NCEI_AFI_1981-2010_rtp_tavg_afzndx.txt`) gives **`556` degree F-days** (`RFI-007`), requiring a minimum bearing depth of **`42 in`** (`3.5 ft`).
3. **Sulfate Exposure and Concrete Durability (`EM 1110-2-2000` Table 2-2 & `UFGS 03 30 00` Section 2.5.2)**:
   * `CR-P1` (`0.14%` -> `S1`, `F1/W1/C1`): `fc_psi = 4000`, `max_wcm = 0.50`
   * `CR-P2` (`0.23%` -> `S2`, `F1/W1/C1`): `fc_psi = 4500`, `max_wcm = 0.45`
   * `CR-P3` (`0.07%` -> `S0`, `F1/W1/C1`): `fc_psi = 4000`, `max_wcm = 0.50`
   * `CR-P4` (`0.11%` -> `S1`, `F1/W1/C1`): `fc_psi = 4000`, `max_wcm = 0.50`
   * `CR-P5` (`0.05%` -> `S0`, `F3/W1/C1`): `fc_psi = 5000`, `max_wcm = 0.40`
   * `CR-P6` (`0.26%` -> `S2`, `F1/W1/C1`): `fc_psi = 4500`, `max_wcm = 0.45`
4. **Load Factors for Reinforced Concrete Design (`AV-CR-2604_load_combination_memo.docx` vs. `EM 1110-2-2104` Table 3-1)**: `UFC 3-301-01` Paragraph `2-4.3` (`1.2D + 1.6L` exported as `STRENGTH_1.2D_1.6L`) governs footing shear and flexure; hydraulic structure load factors in `EM 1110-2-2104` Table 3-1 do not apply.

## 4. Ground-Improvement Design Parameters and Campus Programme Optimisation

* **Rammed Aggregate Pier (RAP) Design Basis (`FHWA GEC 13` Chapter 5, `Kettleridge_Ground_Systems_budget_proposal.pdf` & `RFI-011`)**:
  * Installed pier diameter `d_p = 30 in` (`Kettleridge_Ground_Systems_budget_proposal.pdf` Section 2).
  * Stress concentration ratio for structure foundation support under rigid footings: **`n_s = 10`** (`FHWA GEC 13` Chapter 5 Section 4.2.1, page 5-43, and `RFI-011`; proprietary vendor ratios of 20+ rejected).
  * Minimum area replacement ratio: **`R_a >= 0.33`** (`FHWA GEC 13` Chapter 5 Section 4.2.1, page 5-43).
  * Minimum clear spacing between adjacent piers: **`1.0 ft` (`12 in`)**, corresponding to `42 in` center-to-center spacing on a square or staggered grid (`Kettleridge_Ground_Systems_budget_proposal.pdf` Section 2).
  * Treatment depth below footing soffit: **`8 ft` to `25 ft`** in whole feet (`Kettleridge_Ground_Systems_budget_proposal.pdf` Section 2).
  * Top-of-pier stress: `q_g = q * [n_s / (n_s * R_a - R_a + 1)] <= 18,000 psf` (`FHWA GEC 13` Equation 5-12 & `Kettleridge_Ground_Systems_budget_proposal.pdf` Section 2).
  * Upper-zone settlement: `s_uz = (q_g / 144) / k_g` (`FHWA GEC 13` Equation 5-13) using the pad-specific pre-production stiffness modulus test values from `Kettleridge_Ground_Systems_budget_proposal.pdf` Section 3 (`CR-P1: 165 pci`, `CR-P2: 140 pci`, `CR-P3: 210 pci`, `CR-P4: 195 pci`, `CR-P5: 230 pci`, `CR-P6: 155 pci`), added to lower-zone settlement `s_lz` (`FHWA GEC 13` Equations 5-11 & 5-14).
* **Campus Programme Reasoning**:
  * On **`CR-P3`** and **`CR-P5`**, Stratum I is relatively stiff (`Es = 210 ksf` and `250 ksf`) and thin (`5.5–7.0 ft` on `CR-P3`, `4.5–5.5 ft` on `CR-P5`) over dense Stratum II (`Es = 1700–1800 ksf`), with deep groundwater (`19.0 ft` and `21.0 ft`). Unimproved shallow spread footings (`SPREAD`) at `48 in` (`CR-P3`, `$32,544.34` vs. `$55,225.26` improved) and `42 in` (`CR-P5`, `$18,117.64` vs. `$36,352.80` improved) satisfy all bearing, settlement, and angular distortion limits at much lower cost than ground improvement.
  * On **`CR-P1`**, **`CR-P2`**, **`CR-P4`**, and **`CR-P6`**, Stratum I has low elastic modulus (`Es = 110, 85, 130, 95 ksf`) and extends to depths of `6.0–14.0 ft` with shallow groundwater (`8.0–9.0 ft`). Unimproved spread footings must be founded deeper (`57 in` on `CR-P4` and `117–129 in` below groundwater on `CR-P1`, `CR-P2`, `CR-P6`) to limit settlement in Stratum I to `<= 1.0 in`, incurring large open-cut excavation/backfill and dewatering costs (`$265,454.39`, `$262,748.93`, `$81,142.13`, and `$225,580.81`). Supporting footings at the `42 in` frost depth on rammed aggregate piers (`IMPROVED_SPREAD`) avoids all dewatering and open-cut side slopes, reducing pad costs (excluding rig mobilisation) to `$81,812.64`, `$88,571.26`, `$48,736.42`, and `$84,255.12` — saving `$183,641.75`, `$174,177.67`, `$32,405.71`, and `$141,325.69` per pad before rig mobilisation.
  * Because each mobilised rig (`$40,000` lump sum) can serve at most **2 building pads** within the Phase 1 milestone window (`Kettleridge_Ground_Systems_budget_proposal.pdf` Section 4), serving the 4 improved pads (`CR-P1`, `CR-P2`, `CR-P4`, `CR-P6`) requires exactly **`2` mobilised rigs** (`RIG-1`: `CR-P1`, `CR-P2`; `RIG-2`: `CR-P4`, `CR-P6`, total mobilisation cost `$80,000.00`), yielding the minimum compliant Phase 1 campus cost of **`$434,037.42`**.
