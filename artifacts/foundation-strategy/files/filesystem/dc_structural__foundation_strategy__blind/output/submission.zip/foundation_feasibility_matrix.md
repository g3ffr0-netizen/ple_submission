# Cattail Run Data Campus — Phase 1 Foundation Feasibility and Optimisation Matrix

## Campus Programme Cost Summary

| Pad ID | Building | Selected Strategy | Governing Constraint | Spread-Only Cost (USD) | Improved Cost Excl. Rig Mob (USD) | Selected Pad Cost (USD) |
|---|---|---|---|---:|---:|---:|
| CR-P1 | Data Hall 1 | IMPROVED_SPREAD | BEARING | $265,454.39 | $81,812.64 | $81,812.64 |
| CR-P2 | Data Hall 2 | IMPROVED_SPREAD | BEARING | $262,748.93 | $88,571.26 | $88,571.26 |
| CR-P3 | Electrical Yard Building | SPREAD | BEARING | $32,544.34 | $55,225.26 | $32,544.34 |
| CR-P4 | Administration and Operations Building | IMPROVED_SPREAD | BEARING | $81,142.13 | $48,736.42 | $48,736.42 |
| CR-P5 | Logistics and Spares Warehouse | SPREAD | BEARING | $18,117.64 | $36,352.80 | $18,117.64 |
| CR-P6 | Data Hall 3 | IMPROVED_SPREAD | BEARING | $225,580.81 | $84,255.12 | $84,255.12 |

* **Mobilised Rigs**: 2 (`RIG-1, RIG-2`) — Mobilisation Lump Sum = **$80,000.00**
* **Total Phase 1 Campus Foundation Programme Cost**: **$434,037.42**

## CR-P1 — Data Hall 1

* **Occupancy Classification**: `Light Industrial, Public` (`FS_bearing = 3.5`)
* **Concrete & Exposure**: `f'c = 4000 psi`, `max w/cm = 0.5`, Exposure Classes `F1, S1, W1, C1` (Stratum I sulfate = `0.14%` -> `S1`)
* **Shallow Spread-Only Alternative (`SPREAD`)**: Bearing depth = `129 in` (`10.75 ft`), Dewatering = `9 days`, Total Pad Cost = **$265,454.39**
* **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`)**: Bearing depth = `42 in` (`3.50 ft`), Dewatering = `0 days`, Pier stiffness modulus `kg = 165.0 pci`, Total Pad Cost (excl. rig mobilisation) = **$81,812.64** (with prorated half-rig mobilisation of $20,000: **$101,812.64**)
* **Pad Decision**: **`IMPROVED_SPREAD`** | **Pad Governing Constraint**: `BEARING`

| Tag | Element | Service P (kips) | Strength Pu (kips) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow_net (ksf) | Settlement (in) | Piers (N x d" x H') | Ra | q_g (psf) | Gov. Constraint |
|---|---|---:|---:|---|---|---|---:|---:|---:|---|---:|---:|---|
| F1 | column 24 in sq | 610.0 | 838.0 | IMPROVED_SPREAD | 132 x 132 x 27 | I | 5.041 | 5.163 | 0.612 | 9 x 30" x 8' | 0.3651 | 11762.3 | BEARING |
| F2 | column 26 in sq | 1180.0 | 1622.0 | IMPROVED_SPREAD | 177 x 177 x 39 | I | 5.424 | 5.425 | 0.762 | 15 x 30" x 8' | 0.3384 | 13405.4 | BEARING |
| F3 | column 28 in sq | 1420.0 | 1953.0 | IMPROVED_SPREAD | 195 x 195 x 42 | I | 5.378 | 5.480 | 0.795 | 18 x 30" x 8' | 0.3346 | 13405.4 | BEARING |
| F4 | column 26 in sq | 980.0 | 1348.0 | IMPROVED_SPREAD | 165 x 165 x 33 | I | 5.183 | 5.355 | 0.725 | 13 x 30" x 8' | 0.3375 | 12837.6 | BEARING |
| F5 | column 22 in sq | 520.0 | 715.0 | IMPROVED_SPREAD | 123 x 123 x 24 | I | 4.949 | 5.111 | 0.675 | 8 x 30" x 8' | 0.3738 | 11341.5 | BEARING |
| W1 | shear wall (24 ft) | 1650.0 | 2244.0 | IMPROVED_SPREAD | 162 x 300 x 30 | I | 4.889 | 4.926 | 0.730 | 23 x 30" x 9' | 0.3345 | 12189.6 | BEARING |

**Shear-Wall (`W1`) Stability Checks (`SERVICE_D_PLUS_L_PLUS_W`, `0.6D_PLUS_W`, and `UPLIFT_W`)**:
* Lateral & Uplift Demand: `D+L+W = 1650.0 kips`, `0.6D = 708.0 kips`, `Hx = 96.0 kips`, `My = 880.0 kip-ft`, Net Wind Uplift = `-260.0 kips`
* Sliding Factor of Safety (`0.6D + W`): `sliding_fs = 2.63` >= `1.50` (PASS)
* Overturning Resultant Eccentricity (`D + L + W`): `eccentricity_in = 8.15 in` <= `B/6 = 27.00 in` and `L/6 = 50.00 in` (middle third, PASS)
* Uplift Factor of Safety (`0.6D + W` / `UPLIFT_W`): `uplift_fs = 3.11` >= `1.50` (PASS)

## CR-P2 — Data Hall 2

* **Occupancy Classification**: `Light Industrial, Public` (`FS_bearing = 3.5`)
* **Concrete & Exposure**: `f'c = 4500 psi`, `max w/cm = 0.45`, Exposure Classes `F1, S2, W1, C1` (Stratum I sulfate = `0.23%` -> `S2`)
* **Shallow Spread-Only Alternative (`SPREAD`)**: Bearing depth = `123 in` (`10.25 ft`), Dewatering = `4 days`, Total Pad Cost = **$262,748.93**
* **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`)**: Bearing depth = `42 in` (`3.50 ft`), Dewatering = `0 days`, Pier stiffness modulus `kg = 140.0 pci`, Total Pad Cost (excl. rig mobilisation) = **$88,571.26** (with prorated half-rig mobilisation of $20,000: **$108,571.26**)
* **Pad Decision**: **`IMPROVED_SPREAD`** | **Pad Governing Constraint**: `BEARING`

| Tag | Element | Service P (kips) | Strength Pu (kips) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow_net (ksf) | Settlement (in) | Piers (N x d" x H') | Ra | q_g (psf) | Gov. Constraint |
|---|---|---:|---:|---|---|---|---:|---:|---:|---|---:|---:|---|
| F1 | column 24 in sq | 646.6 | 888.3 | IMPROVED_SPREAD | 135 x 135 x 27 | I | 5.109 | 5.259 | 0.946 | 9 x 30" x 9' | 0.3491 | 12335.7 | BEARING |
| F2 | column 26 in sq | 1250.8 | 1719.3 | IMPROVED_SPREAD | 183 x 183 x 39 | I | 5.378 | 5.507 | 0.868 | 16 x 30" x 9' | 0.3377 | 13314.6 | BEARING |
| F3 | column 28 in sq | 1505.2 | 2070.2 | IMPROVED_SPREAD | 201 x 201 x 42 | I | 5.365 | 5.531 | 0.915 | 19 x 30" x 8' | 0.3324 | 13439.8 | BEARING |
| F4 | column 26 in sq | 1038.8 | 1428.9 | IMPROVED_SPREAD | 168 x 168 x 33 | I | 5.300 | 5.451 | 0.824 | 14 x 30" x 8' | 0.3506 | 12753.8 | BEARING |
| F5 | column 22 in sq | 551.2 | 757.9 | IMPROVED_SPREAD | 126 x 126 x 24 | I | 5.000 | 5.207 | 0.710 | 8 x 30" x 8' | 0.3562 | 11887.5 | BEARING |
| W1 | shear wall (24 ft) | 1749.0 | 2378.6 | IMPROVED_SPREAD | 168 x 300 x 30 | I | 4.997 | 5.016 | 0.809 | 26 x 30" x 8' | 0.3646 | 11670.5 | BEARING |

**Shear-Wall (`W1`) Stability Checks (`SERVICE_D_PLUS_L_PLUS_W`, `0.6D_PLUS_W`, and `UPLIFT_W`)**:
* Lateral & Uplift Demand: `D+L+W = 1749.0 kips`, `0.6D = 750.5 kips`, `Hx = 101.8 kips`, `My = 932.8 kip-ft`, Net Wind Uplift = `-275.6 kips`
* Sliding Factor of Safety (`0.6D + W`): `sliding_fs = 2.62` >= `1.50` (PASS)
* Overturning Resultant Eccentricity (`D + L + W`): `eccentricity_in = 8.15 in` <= `B/6 = 28.00 in` and `L/6 = 50.00 in` (middle third, PASS)
* Uplift Factor of Safety (`0.6D + W` / `UPLIFT_W`): `uplift_fs = 3.10` >= `1.50` (PASS)

## CR-P3 — Electrical Yard Building

* **Occupancy Classification**: `Light Industrial, Public` (`FS_bearing = 3.5`)
* **Concrete & Exposure**: `f'c = 4000 psi`, `max w/cm = 0.5`, Exposure Classes `F1, S0, W1, C1` (Stratum I sulfate = `0.07%` -> `S0`)
* **Shallow Spread-Only Alternative (`SPREAD`)**: Bearing depth = `48 in` (`4.00 ft`), Dewatering = `0 days`, Total Pad Cost = **$32,544.34**
* **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`)**: Bearing depth = `42 in` (`3.50 ft`), Dewatering = `0 days`, Pier stiffness modulus `kg = 210.0 pci`, Total Pad Cost (excl. rig mobilisation) = **$55,225.26** (with prorated half-rig mobilisation of $20,000: **$75,225.26**)
* **Pad Decision**: **`SPREAD`** | **Pad Governing Constraint**: `BEARING`

| Tag | Element | Service P (kips) | Strength Pu (kips) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow_net (ksf) | Settlement (in) | Piers (N x d" x H') | Ra | q_g (psf) | Gov. Constraint |
|---|---|---:|---:|---|---|---|---:|---:|---:|---|---:|---:|---|
| F1 | column 24 in sq | 439.2 | 603.4 | SPREAD | 108 x 108 x 21 | I | 5.422 | 5.595 | 0.601 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| F2 | column 26 in sq | 849.6 | 1167.8 | SPREAD | 144 x 144 x 30 | I | 5.900 | 6.040 | 0.852 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| F3 | column 28 in sq | 1022.4 | 1406.2 | SPREAD | 159 x 159 x 33 | I | 5.824 | 6.173 | 0.985 | 0 x 0" x 0' | 0.0000 | 0.0 | SETTLEMENT |
| F4 | column 26 in sq | 705.6 | 970.6 | SPREAD | 132 x 132 x 27 | I | 5.831 | 5.892 | 0.963 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| F5 | column 22 in sq | 374.4 | 514.8 | SPREAD | 102 x 102 x 21 | I | 5.182 | 5.521 | 0.809 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| W1 | shear wall (24 ft) | 1188.0 | 1615.7 | SPREAD | 120 x 300 x 24 | I | 4.752 | 5.337 | 0.910 | 0 x 0" x 0' | 0.0000 | 0.0 | SETTLEMENT |

**Shear-Wall (`W1`) Stability Checks (`SERVICE_D_PLUS_L_PLUS_W`, `0.6D_PLUS_W`, and `UPLIFT_W`)**:
* Lateral & Uplift Demand: `D+L+W = 1188.0 kips`, `0.6D = 509.8 kips`, `Hx = 69.1 kips`, `My = 633.6 kip-ft`, Net Wind Uplift = `-187.2 kips`
* Sliding Factor of Safety (`0.6D + W`): `sliding_fs = 2.67` >= `1.50` (PASS)
* Overturning Resultant Eccentricity (`D + L + W`): `eccentricity_in = 7.80 in` <= `B/6 = 20.00 in` and `L/6 = 50.00 in` (middle third, PASS)
* Uplift Factor of Safety (`0.6D + W` / `UPLIFT_W`): `uplift_fs = 3.15` >= `1.50` (PASS)

## CR-P4 — Administration and Operations Building

* **Occupancy Classification**: `Apartments, Office` (`FS_bearing = 3.0`)
* **Concrete & Exposure**: `f'c = 4000 psi`, `max w/cm = 0.5`, Exposure Classes `F1, S1, W1, C1` (Stratum I sulfate = `0.11%` -> `S1`)
* **Shallow Spread-Only Alternative (`SPREAD`)**: Bearing depth = `57 in` (`4.75 ft`), Dewatering = `0 days`, Total Pad Cost = **$81,142.13**
* **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`)**: Bearing depth = `42 in` (`3.50 ft`), Dewatering = `0 days`, Pier stiffness modulus `kg = 195.0 pci`, Total Pad Cost (excl. rig mobilisation) = **$48,736.42** (with prorated half-rig mobilisation of $20,000: **$68,736.42**)
* **Pad Decision**: **`IMPROVED_SPREAD`** | **Pad Governing Constraint**: `BEARING`

| Tag | Element | Service P (kips) | Strength Pu (kips) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow_net (ksf) | Settlement (in) | Piers (N x d" x H') | Ra | q_g (psf) | Gov. Constraint |
|---|---|---:|---:|---|---|---|---:|---:|---:|---|---:|---:|---|
| F1 | column 24 in sq | 384.3 | 527.9 | IMPROVED_SPREAD | 105 x 105 x 21 | I | 5.019 | 5.840 | 0.485 | 6 x 30" x 8' | 0.3847 | 11248.9 | BEARING |
| F2 | column 26 in sq | 743.4 | 1021.9 | IMPROVED_SPREAD | 135 x 135 x 30 | I | 5.874 | 6.044 | 0.647 | 9 x 30" x 8' | 0.3491 | 14182.4 | BEARING |
| F3 | column 28 in sq | 894.6 | 1230.4 | IMPROVED_SPREAD | 147 x 147 x 30 | I | 5.962 | 6.125 | 0.666 | 11 x 30" x 8' | 0.3598 | 14065.4 | BEARING |
| F4 | column 26 in sq | 617.4 | 849.2 | IMPROVED_SPREAD | 123 x 123 x 27 | I | 5.877 | 5.962 | 0.609 | 8 x 30" x 8' | 0.3738 | 13465.9 | BEARING |
| F5 | column 22 in sq | 327.6 | 450.4 | IMPROVED_SPREAD | 105 x 105 x 21 | I | 4.279 | 5.840 | 0.420 | 6 x 30" x 8' | 0.3847 | 9589.2 | ANGULAR_DISTORTION |
| W1 | shear wall (24 ft) | 1039.5 | 1413.7 | IMPROVED_SPREAD | 96 x 300 x 21 | I | 5.197 | 5.333 | 0.534 | 16 x 30" x 10' | 0.3927 | 11462.7 | BEARING |

**Shear-Wall (`W1`) Stability Checks (`SERVICE_D_PLUS_L_PLUS_W`, `0.6D_PLUS_W`, and `UPLIFT_W`)**:
* Lateral & Uplift Demand: `D+L+W = 1039.5 kips`, `0.6D = 446.0 kips`, `Hx = 60.5 kips`, `My = 554.4 kip-ft`, Net Wind Uplift = `-163.8 kips`
* Sliding Factor of Safety (`0.6D + W`): `sliding_fs = 2.59` >= `1.50` (PASS)
* Overturning Resultant Eccentricity (`D + L + W`): `eccentricity_in = 7.62 in` <= `B/6 = 16.00 in` and `L/6 = 50.00 in` (middle third, PASS)
* Uplift Factor of Safety (`0.6D + W` / `UPLIFT_W`): `uplift_fs = 3.07` >= `1.50` (PASS)

## CR-P5 — Logistics and Spares Warehouse

* **Occupancy Classification**: `Warehouse` (`FS_bearing = 2.5`)
* **Concrete & Exposure**: `f'c = 5000 psi`, `max w/cm = 0.4`, Exposure Classes `F3, S0, W1, C1` (Stratum I sulfate = `0.05%` -> `S0`)
* **Shallow Spread-Only Alternative (`SPREAD`)**: Bearing depth = `42 in` (`3.50 ft`), Dewatering = `0 days`, Total Pad Cost = **$18,117.64**
* **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`)**: Bearing depth = `42 in` (`3.50 ft`), Dewatering = `0 days`, Pier stiffness modulus `kg = 230.0 pci`, Total Pad Cost (excl. rig mobilisation) = **$36,352.80** (with prorated half-rig mobilisation of $20,000: **$56,352.80**)
* **Pad Decision**: **`SPREAD`** | **Pad Governing Constraint**: `BEARING`

| Tag | Element | Service P (kips) | Strength Pu (kips) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow_net (ksf) | Settlement (in) | Piers (N x d" x H') | Ra | q_g (psf) | Gov. Constraint |
|---|---|---:|---:|---|---|---|---:|---:|---:|---|---:|---:|---|
| F1 | column 24 in sq | 335.5 | 460.9 | SPREAD | 84 x 84 x 18 | I | 6.847 | 7.111 | 0.499 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| F2 | column 26 in sq | 649.0 | 892.1 | SPREAD | 114 x 114 x 24 | I | 7.191 | 7.631 | 0.663 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| F3 | column 28 in sq | 781.0 | 1074.2 | SPREAD | 123 x 123 x 27 | I | 7.434 | 7.786 | 0.770 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| F4 | column 26 in sq | 539.0 | 741.4 | SPREAD | 105 x 105 x 21 | I | 7.040 | 7.475 | 0.734 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| F5 | column 22 in sq | 286.0 | 393.3 | SPREAD | 78 x 78 x 18 | I | 6.769 | 7.008 | 0.664 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |
| W1 | shear wall (24 ft) | 907.5 | 1234.2 | SPREAD | 69 x 300 x 15 | I | 6.313 | 6.345 | 0.749 | 0 x 0" x 0' | 0.0000 | 0.0 | BEARING |

**Shear-Wall (`W1`) Stability Checks (`SERVICE_D_PLUS_L_PLUS_W`, `0.6D_PLUS_W`, and `UPLIFT_W`)**:
* Lateral & Uplift Demand: `D+L+W = 907.5 kips`, `0.6D = 389.4 kips`, `Hx = 52.8 kips`, `My = 484.0 kip-ft`, Net Wind Uplift = `-143.0 kips`
* Sliding Factor of Safety (`0.6D + W`): `sliding_fs = 2.53` >= `1.50` (PASS)
* Overturning Resultant Eccentricity (`D + L + W`): `eccentricity_in = 7.27 in` <= `B/6 = 11.50 in` and `L/6 = 50.00 in` (middle third, PASS)
* Uplift Factor of Safety (`0.6D + W` / `UPLIFT_W`): `uplift_fs = 3.00` >= `1.50` (PASS)

## CR-P6 — Data Hall 3

* **Occupancy Classification**: `Light Industrial, Public` (`FS_bearing = 3.5`)
* **Concrete & Exposure**: `f'c = 4500 psi`, `max w/cm = 0.45`, Exposure Classes `F1, S2, W1, C1` (Stratum I sulfate = `0.26%` -> `S2`)
* **Shallow Spread-Only Alternative (`SPREAD`)**: Bearing depth = `117 in` (`9.75 ft`), Dewatering = `4 days`, Total Pad Cost = **$225,580.81**
* **Aggregate-Pier Improved Alternative (`IMPROVED_SPREAD`)**: Bearing depth = `42 in` (`3.50 ft`), Dewatering = `0 days`, Pier stiffness modulus `kg = 155.0 pci`, Total Pad Cost (excl. rig mobilisation) = **$84,255.12** (with prorated half-rig mobilisation of $20,000: **$104,255.12**)
* **Pad Decision**: **`IMPROVED_SPREAD`** | **Pad Governing Constraint**: `BEARING`

| Tag | Element | Service P (kips) | Strength Pu (kips) | Type | B x L x t (in) | Stratum | q_net (ksf) | q_allow_net (ksf) | Settlement (in) | Piers (N x d" x H') | Ra | q_g (psf) | Gov. Constraint |
|---|---|---:|---:|---|---|---|---:|---:|---:|---|---:|---:|---|
| F1 | column 24 in sq | 622.2 | 854.8 | IMPROVED_SPREAD | 132 x 132 x 27 | I | 5.142 | 5.202 | 0.925 | 9 x 30" x 9' | 0.3651 | 11997.5 | BEARING |
| F2 | column 26 in sq | 1203.6 | 1654.4 | IMPROVED_SPREAD | 180 x 180 x 36 | I | 5.349 | 5.482 | 0.863 | 16 x 30" x 8' | 0.3491 | 12916.1 | BEARING |
| F3 | column 28 in sq | 1448.4 | 1992.1 | IMPROVED_SPREAD | 195 x 195 x 42 | I | 5.485 | 5.501 | 0.849 | 18 x 30" x 8' | 0.3346 | 13673.5 | BEARING |
| F4 | column 26 in sq | 999.6 | 1375.0 | IMPROVED_SPREAD | 165 x 165 x 33 | I | 5.287 | 5.394 | 0.764 | 13 x 30" x 8' | 0.3375 | 13094.3 | BEARING |
| F5 | column 22 in sq | 530.4 | 729.3 | IMPROVED_SPREAD | 123 x 123 x 24 | I | 5.048 | 5.150 | 0.628 | 8 x 30" x 8' | 0.3738 | 11568.4 | BEARING |
| W1 | shear wall (24 ft) | 1683.0 | 2288.9 | IMPROVED_SPREAD | 165 x 300 x 30 | I | 4.896 | 4.971 | 0.744 | 24 x 30" x 8' | 0.3427 | 11986.9 | BEARING |

**Shear-Wall (`W1`) Stability Checks (`SERVICE_D_PLUS_L_PLUS_W`, `0.6D_PLUS_W`, and `UPLIFT_W`)**:
* Lateral & Uplift Demand: `D+L+W = 1683.0 kips`, `0.6D = 722.2 kips`, `Hx = 97.9 kips`, `My = 897.6 kip-ft`, Net Wind Uplift = `-265.2 kips`
* Sliding Factor of Safety (`0.6D + W`): `sliding_fs = 2.63` >= `1.50` (PASS)
* Overturning Resultant Eccentricity (`D + L + W`): `eccentricity_in = 8.15 in` <= `B/6 = 27.50 in` and `L/6 = 50.00 in` (middle third, PASS)
* Uplift Factor of Safety (`0.6D + W` / `UPLIFT_W`): `uplift_fs = 3.11` >= `1.50` (PASS)

